/*
* 9_igPropertyManagers.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");


$IG.CollectionsManager = function(control, collections)
{
	///<summary locid="T:J#Infragistics.Web.UI.CollectionsManager">
	/// For Internal Use Only.
	/// An object that manages all ObjectCollections of an Infragistics.Web.UI.Control.
	///</summary>
	this._control = control;
	this._collections = collections;
	this._count = collections ? collections.length : 0;
	this._itemCollections = [];
	this._clientStateManagers = [];
	this._items = [];
	this._itemCount = [];
	this._uiBehaviors = []; 
	for(var i = 0; i < this._count; i++)
	{
		this._itemCount[i] = 0;
		this._items[i] = {};
		this._clientStateManagers[i] = new $IG.CollectionClientStateManager(collections[i]);       
	}
}

$IG.CollectionsManager.prototype =
{
	get_collection: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.CollectionsManager.collection">
		/// Gets the ObjectCollection at the specified index.
		///</summary>
		///<param name="index"> collection index </param>
		///<returns type="Infragistics.Web.UI.ObjectCollection"> the collection </returns>    
		return this._collections ? this._collections[index] : null;
	},

	get_count: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.CollectionsManager.count">
		/// Gets the amount of Collections that belong to the control.
		///</summary>
		///<returns type="Integer"> number of collections </returns>    
		return this._count;
	},

	get_allTransactionLists: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.CollectionsManager.allTransactionLists">
		/// Returns all json Transaction Lists of all collections in a server friendly format.
		///</summary>    
		///<returns type="Array" elementType="Object"> an array of transaction lists </returns>
		var state = [];
		for (var i = 0; i < this._count; i++)
			state[i] = this.get_transactionList(i);
		return state;
	},

	get_transactionList: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.CollectionsManager.transactionList">
		/// Returns the json Transaction List of the collection at the specified index.
		///</summary>    
		///<param name="index"> index in the collections list </param>
		///<returns type="Object"> transaction list </returns>
		return this._clientStateManagers[index].get_transactionList()
	},

	register_collection: function(index, collectionType, noBehavior)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.register_collection">
		/// Registers a collection with the CollectionManager.
		///</summary>    
		///<param name="index"> index </param>
		///<param name="collectionType" type="Type"> the type of the collection </param>
		var collection = this._itemCollections[index] = new collectionType(this._control, this._clientStateManagers[index], index, this);
		return collection;
	},

	registerUIBehaviors: function(collection)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.registerUIBehaviors">
		/// Creates a UIBehaviors object for the specified collection. 
		///</summary>    
		///<param name="collection" type="Object"> the collection for which to register UI behaviors </param>
		var index = collection._index;
		this._uiBehaviors[index] = new $IG.UIBehaviorsObject(this._control, collection)
	},

    registerUIBehaviorsEx: function(collection, behavior)
	{
		///<summary>
		/// Registers a specified behavior for the specified collection.
		///</summary>    
		///<param name="collection" type="Object"> the collection for which to register UI behaviors </param>
        ///<param name="behavior" type="Object"> the behavior that should be assigned to the supplied collection </param>
		var index = collection._index;
		this._uiBehaviors[index] = behavior;
	},

	getItemCount: function(index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.getItemCount">
		/// Retunrs the number of items in the collection at the specified index. 
		///</summary>    
		///<param name="index" type="Integer"> the index of the collection in the list of collections </param>
		///<returns type="Integer"> the number of items in the specified collection </returns>
		return this._itemCount[index];
	},

	getUIBehaviorsObj: function(index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.getUIBehaviorsObj">
		/// Returns the UIBehaviors object of the collection at the specified index.
		///</summary>    
		///<param name="index"> the index of the collection in the list of collections </param>
		///<returns type="Infragistics.Web.UIBehaviorsObject"> the UI Behaviors object </returns>
		return this._uiBehaviors[index];
	},

	addObject: function(index, adr, object)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.addObject">
		/// Adds the specified item to the collection at the specified index.
		///</summary>    
		///<param type="Integer" name="index"> index at which to add the object </param>
		///<param type="String" name="adr"> address of the object </param>
		///<param type="Object" name="object"> the object instance </param>
		this._items[index][adr] = object;
		var uiBehaviorObj = this._uiBehaviors[index];
		if (uiBehaviorObj)
		{
			if (object._getFlags().getSelected())
				uiBehaviorObj.select(object);
		}
		this._itemCount[index]++;
	},
	
	removeObject: function(index, adr)
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.removeObject">
	    /// Removes the item at specified address from the collection at the specified index.
	    ///</summary>
	    ///<param type="Integer" name="index"> Index at which to remove the object </param>
	    ///<param type="String" name="adr"> address of the object </param>
	    if(!$util.isNullOrUndefined(this._items[index]) &&
	       !$util.isNullOrUndefined(this._items[index][adr]))
	    {
	        delete this._items[index][adr];
	        this._itemCount[index]--;
	    }
	},

	getObject: function(index, adr)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.getObject">
		/// Returns the item at the specified address from the collection at the specified index.
		///</summary>    
		///<param type="Integer" name="index"> index at which to add the object </param>
		///<param type="String" name="adr"> address of the object </param>
		///<returns type="Object"> the item at the specified index/address </returns>
		return this._items[index][adr];
	},

	getServerCollection: function(vse)
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.getServerCollection">
		/// Returns a server friendly array of all ClientState for all collections.
		///</summary>    
		if (vse)
		{
			var collections = [];
			var index = this._collections ? this._collections.length : 0;
			while (index-- > 0)
			{
				collections[index] = {};
				var csm = this._clientStateManagers[index];
				for (var adr in this._collections[index])
					collections[index][adr] = csm.get_serverProps(adr);
			}
			return collections;
		}
		return null;
	},

	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.CollectionsManager.dispose">
		/// Disposes of all objects created by the Collection manager.
		///</summary>
		if (!this._itemCollections)
			return;
		var count = this._itemCollections.length;
		for (var i = 0; i < count; i++)
		{
			if (this._uiBehaviors[i])
				this._uiBehaviors[i].dispose();
			this._itemCollections[i].dispose();
			var item = this._items[i]
			for (var adr in item)
			{
				
				
				
				var obj = item[adr];
				if (obj && obj.dispose)
					obj.dispose();
			}
		}
		this._control = null;
		this._collections = null;
		this._itemCollections = null;
		this._clientStateManagers = null;
		this._items = null;
		this._itemCount = null;
		this._uiBehaviors = null;
	}
};

$IG.CollectionsManager.registerClass('Infragistics.Web.UI.CollectionsManager');






$IG.MSAjaxCollectionsManager = function(control, collections, bindings, parentBinding)
{
	///<summary locid="T:J#Infragistics.Web.UI.MSAjaxCollectionsManager">
	/// For Internal Use Only.
	/// An object that manages all ObjectCollections of an Infragistics.Web.UI.Control.
	///</summary>
	var collections = [collections];
	// A.T. we need the bindings since we won't be looking up anything by index any more
	this._bindings = bindings;
	//A.T. this is the binding for the property in the JSON that holds the child items/nodes
	// for example for WebDataTree, this is called "Nodes" by default, in the JSON. 
	// Most important thing to note here is that we are dealing with hierarchical JSON one, not flat one as before, denoted only by address
	this._parentBinding = parentBinding;
	
	this._control = control;
	this._collections = collections;
	this._count = collections ? collections.length : 0;
	this._itemCollections = [];
	this._clientStateManagers = [];
	this._items = [];
	this._itemCount = [];
	this._uiBehaviors = []; 
	for(var i = 0; i < this._count; i++)
	{
		this._itemCount[i] = 0;
		this._items[i] = {};
		this._clientStateManagers[i] = new $IG.MSAjaxCollectionClientStateManager(collections[i], bindings, parentBinding);       
	}
}

$IG.MSAjaxCollectionsManager.prototype =
{
	get_collection: function(index) {
		///<summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionsManager.collection">
		/// Gets the ObjectCollection at the specified index.
		///</summary>    
		return this._collections ? this._collections[index] : null;
	},

	get_count: function() {
		///<summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionsManager.count">
		/// Gets the amount of Collections that belong to the control.
		///</summary>    
		return this._count;
	},

	get_allTransactionLists: function() {
		///<summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionsManager.allTransactionLists">
		/// Returns all json Transaction Lists of all collections in a server friendly format.
		///</summary>    
		var state = [];
		for (var i = 0; i < this._count; i++)
			state[i] = this.get_transactionList(i);
		return state;
	},

	get_transactionList: function(index) {
		///<summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionsManager.transactionList">
		/// Returns the json Transaction List of the collection at the specified index.
		///</summary>    
		return this._clientStateManagers[index].get_transactionList()
	},

	register_collection: function(index, collectionType, noBehavior) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.register_collection">
		/// Registers a collection with the CollectionManager.
		///</summary>    
		var collection = this._itemCollections[index] = new collectionType(this._control, this._clientStateManagers[index], index, this);
		return collection;
	},

	registerUIBehaviors: function(collection) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.registerUIBehaviors">
		/// Creates a UIBehaviors object for the specified collection. 
		///</summary>    
		var index = collection._index;
		this._uiBehaviors[index] = new $IG.UIBehaviorsObject(this._control, collection)
	},

    registerUIBehaviorsEx: function(collection, behavior)
    {
	    ///<summary>
	    /// Registers a specified behavior for the specified collection.
	    ///</summary>    
	    ///<param name="collection" type="Object"> the collection for which to register UI behaviors </param>
        ///<param name="behavior" type="Object"> the behavior that should be assigned to the supplied collection </param>
	    var index = collection._index;
	    this._uiBehaviors[index] = behavior;
    },

	getItemCount: function(index) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.getItemCount">
		/// Retunrs the number of items in the collection at the specified index. 
		///</summary>    
		return this._itemCount[index];
	},

	getUIBehaviorsObj: function(index) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.getUIBehaviorsObj">
		/// Returns the UIBehaviors object of the collection at the specified index.
		///</summary>    
		return this._uiBehaviors[index];
	},

	addObject: function(index, adr, object) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.addObject">
		/// Adds the specified item to the collection at the specified index.
		///</summary>    
		this._items[index][adr] = object;
		var uiBehaviorObj = this._uiBehaviors[index];
		if (uiBehaviorObj) {
			if (object._getFlags().getSelected())
				uiBehaviorObj.select(object);
		}
		this._itemCount[index]++;
	},

	getObject: function(index, adr) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.getObject">
		/// Returns the item at the specified address from the collection at the specified index.
		///</summary>    
		return this._items[index][adr];
	},

	getServerCollection: function(vse) {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.getServerCollection">
		/// Returns a server friendly array of all ClientState for all collections.
		///</summary>    
		if (vse) {
			var collections = [];
			var index = this._collections ? this._collections.length : 0;
			while (index-- > 0) {
				collections[index] = {};
				var csm = this._clientStateManagers[index];
				// A.T.
				//for (var adr in this._collections[index])
				//	collections[index][adr] = csm.get_serverProps(adr);
				collections[index] = csm._items;
			}
			return collections;
		}
		return null;
	},

	dispose: function() {
		///<summary locid="M:J#Infragistics.Web.UI.MSAjaxCollectionsManager.dispose">
		/// Disposes of all objects created by the Collection manager.
		///</summary>
		if (!this._itemCollections)
			return;
		var count = this._itemCollections.length;
		for (var i = 0; i < count; i++) {
			if (this._uiBehaviors[i])
				this._uiBehaviors[i].dispose();
			this._itemCollections[i].dispose();
			var item = this._items[i]
			for (var adr in item) {
				
				
				
				var obj = item[adr];
				if (obj && obj.dispose)
					obj.dispose();
			}
		}
		this._control = null;
		this._collections = null;
		this._itemCollections = null;
		this._clientStateManagers = null;
		this._items = null;
		this._itemCount = null;
		this._uiBehaviors = null;
	}
};

$IG.MSAjaxCollectionsManager.registerClass('Infragistics.Web.UI.MSAjaxCollectionsManager', $IG.CollectionsManager);








$IG.ObjectsManager = function(control, objects)
{
    ///<summary locid="T:J#Infragistics.Web.UI.ObjectsManager">
    /// Manages all objects for a control. 
    ///</summary>    
	this._objects = objects;
	this._control = control;
	this._clientStateManagers = [];
	this._objectCollection = [];
	this._count = objects ? objects.length : 0;
}

$IG.ObjectsManager.prototype =
{
	get_objectProps: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.objectProps">
		/// Returns the json ClientState from the server of the object at the specified index.
		///</summary>    
		//<param name="index"> the index in the collection of objects </param>
		///<returns type="Object"> json ClientState for object at the specified index</returns>
		return this._objects ? this._objects[index] : null;
	},

	get_count: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.count">
		/// Returns the amount of objects on the control. 
		///</summary>    
		///<returns type="Integer"> number of objects </returns>
		return this._count;
	},

	register_object: function(index, object)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ObjectsManager.register_object">
		/// Registers the object at the specified index with the ObjectManager.
		///</summary>  
		///<param name="index" type="Integer"> index at the object collection </param>
		///<param name="object" type="Object">the object to register in the collection </param>  
		var objects = this._objects;
		if (!objects || !object)
			return;
		this._clientStateManagers[index] = object._csm;
		this._objectCollection[index] = (object);
		var objectProps = objects[index];

		objectProps.objectsManager = new $IG.ObjectsManager(object, objectProps[1]);
		objectProps.collectionsManager = new $IG.CollectionsManager(object, objectProps[2]);
		objectProps.registered = true;

		object._createObjects(objectProps.objectsManager);
		object._createCollections(objectProps.collectionsManager);
	},

	get_object: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.object">
		/// Returns the object at the specifeid index.
		///</summary>    
		///<param name="index"> index in the object collection</param>
		///<returns type="Object"></returns>
		return this._objectCollection[index];
	},

	get_allTransactionLists: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.allTransactionLists">
		/// Returns all json Transaction Lists in a Server Friendly format for all objects in the object manager.
		///</summary>    
		///<returns type="Array" elementType="Object"> an array of transaction lists </returns>
		var state = [];
		for (var i = 0; i < this._count; i++)
			state[i] = this.get_transactionList(i);
		return state;
	},

	get_csm: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.csm">
		/// Returns the ClientStateManager for the object at the specified index. 
		///</summary>   
		///<param name="index"> index in the collection of client state managers </param> 
		///<returns type="Infragistics.Web.UI.ClientStateManager"> the client state manager instance </returns>
		return this._clientStateManagers[index];
	},

	getServerObjects: function(vse)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ObjectsManager.getServerObjects">
		/// Returns the ClientState for all objects in a Server friendly format.
		///</summary>    
		var objects = [], index = this._objects ? this._objects.length : 0;
		while (index-- > 0)
		{
			var object = this._objects[index];
			if (object.registered)
			{
				var csm = this._clientStateManagers[index];
				var state = [[csm.get_serverProps(vse), object.objectsManager.getServerObjects(vse), object.collectionsManager.getServerCollection(vse)]];
				state[1] = [csm.get_transactionList(), object.collectionsManager.get_allTransactionLists()];
				state[2] = this._objectCollection[index]._saveAdditionalClientState();
				objects[index] = state;
			}
			else
			{
				





				
				objects[index] = this._getUnRegisteredServerObjects(object);
			}
		}
		return objects;
	},

	_getUnRegisteredServerObjects: function(obj)
	{
		var returnObjects = [];
		var objs = obj[1];
		for (var i = 0; objs && i < objs.length; i++)
		{
			returnObjects.push(this._getUnRegisteredServerObjects(objs[i]));
		}

		

		var rawProps = obj[0];
		var props = [];
		props.push(rawProps[0]);
		if (rawProps[1] != null && rawProps[1]["o"] != null)
			props.push(rawProps[1]["o"]);

		return [[props, returnObjects, obj[2]], [null, null], [null]];
	},

	get_transactionList: function(index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ObjectsManager.transactionList">
		/// Returns the json TransactionList for the Object at the specified index.
		///</summary>    
		///<param name="index"> index in the collections list </param>
		///<returns type="Object"> transaction list </returns>
		var csm = this._clientStateManagers[index];
		if (csm)
			return csm.get_transactionList();
		return null;
	},

	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.ObjectsManager.dispose">
		/// Disposes of all objects created by the ObjectManager.
		///</summary>
		var items = this._objectCollection;
		if (!items)
			return;
		var i = items.length;
		while (i-- > 0)
		{
			if (items[i] && (!Sys.Component.isInstanceOfType(items[i]) || !Sys.Application._disposing))
				items[i].dispose();
		}
		this._control = null;
		this._objects = null;
		this._clientStateManagers = null;
		this._objectCollection = null;
	}

};

$IG.ObjectsManager.registerClass('Infragistics.Web.UI.ObjectsManager');

/*
* igWebDataGrid.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");

$IG.WebDataGrid = function (element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebDataGrid">
	/// Creates WebDataGrid client-side object.
	/// </summary>
	/// <param name="element" domElement="true">Grid's HTML element.</param>

	$IG.WebDataGrid.initializeBase(this, [element]);

	$IG.WebDataGrid.find = $find;
	$IG.WebDataGrid.from = $IG._from;
}

$IG.WebDataGrid.prototype =
{
	_thisType: "webDataGrid",

	initialize: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataGrid.initialize">
		///Initializes the WebDataGrid object.
		///</summary>

		this._auxRowsBottom = [];
		this._auxRowsTop = [];

		$IG.WebDataGrid.callBaseMethod(this, "initialize");

		this._gridUtil = new $IG.GridUtility(this); 		

		this._initializeBehaviors = $IG.IGridBehaviorContainer.prototype._initializeBehaviors;

		
		
		this._scrollMinus = 0;

		this._eventHandlerHash = new Object();
		this._eventHandlerHash.length = 0;
		this._eventHandlerHash.handlers = {};

		this._isWidthEmpty = this._get_clientOnlyValue("we") == "true";
		if (this._isWidthEmpty)
		{
			var width = $util.getPropFromCss(this._element, "width");
			this._hasWidth = (width != "" && width != "auto");
		}
		else
			this._hasWidth = true;
		this._enableAjax = this._get_clientOnlyValue("ea") == "true";
		this._enabled = this._get_clientOnlyValue("en") == "true";

		var pool = this._editorProvidersPool = document.getElementById(this._element.id + "_eppool");

		var cont = this._container = this._elements["container"];
		
		
		if (pool && cont)
		{
			pool = this._poolHolder = document.createElement('DIV');
			pool.style.position = 'absolute';
			cont.parentNode.insertBefore(pool, cont);
			this._ensureEditorProvidersPool(pool);
		}

		this._actionList = new $IG.GridActionTransactionList();

		this._initializeObjects();

		if (this._get_clientOnlyValue('sv') == '1')
		{
			this._element.style.visibility = 'visible';
			if (this._elements.hdn)
			{
				if (this._elements.hdn.length)
				{
					for (var i = 0; i < this._elements.hdn.length; i++)
					{
						this._elements.hdn[i].style.visibility = "visible";
					}
				}
				else
					this._elements.hdn.style.visibility = "visible";
			}
		}

		this._initializeMargins();

		this._adjustGridLayout();

		if (this._thisType == "webDataGrid")
			this._raiseClientEvent('Initialize');

		
		if (this._get_clientOnlyValue("ti") >= 0)
			this._element.tabIndex = this._get_clientOnlyValue("ti");

		this.__handleClientEvents();

		this.__handleOnSelectstart(); // this has to go last since we don't want to cancel somebody's mousedown
		
		this._marginTop = 0;
	},


	_rows: null,
	get_rows: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataGrid.rows">
		///Returns the grid's rows collection.
		///</summary>
		///<returns type="Infragistics.Web.UI.GridRowCollection" mayBeNull="true" />

		return this._rows;
	},

	get_enableClientRendering: function ()
	{
		return this._get_clientOnlyValue("ecr");
	},

	_get_dateDataKeyIndeces: function ()
	{
		return this._get_clientOnlyValue("ddkf");
	},

	_createBehaviorObject: function (objName, i, objProps, control, parentCollection)
	{
		/// <summary>
		/// Gets the child behavior collection.
		/// </summary>
		return new $IG[objName]((objName + i), objProps, control, parentCollection);
	},
	__handleClientEvents: function ()
	{
		this._onKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
		$addHandler(this._element, 'keydown', this._onKeyDownHandler);

		this._onKeyPressHandler = Function.createDelegate(this, this._onKeyPress);
		$addHandler(this._element, 'keypress', this._onKeyPressHandler);

		this._onKeyUpHandler = Function.createDelegate(this, this._onKeyUp);
		$addHandler(this._element, 'keyup', this._onKeyUpHandler);

		this._onTouchStartHandler = Function.createDelegate(this, this._onTouchStart);
		$addHandler(this._container, "touchstart", this._onTouchStartHandler);
		this._onTouchMoveHandler = Function.createDelegate(this, this._onTouchMove);
		$addHandler(this._container, "touchmove", this._onTouchMoveHandler);
		this._onTouchEndHandler = Function.createDelegate(this, this._onTouchEnd);
		$addHandler(this._container, "touchend", this._onTouchEndHandler);

		if (this._clientEvents["MouseOver"])
		{
			this._onMouseOverHandler = Function.createDelegate(this, this._onMouseOver);
			$addHandler(this._element, 'mouseover', this._onMouseOverHandler);
		}

		if (this._clientEvents["MouseOut"])
		{
			this._onMouseOutHandler = Function.createDelegate(this, this._onMouseOut);
			$addHandler(this._element, 'mouseout', this._onMouseOutHandler);
		}

		if (this._clientEvents["MouseMove"])
		{
			this._onMouseMoveHandler = Function.createDelegate(this, this._onMouseMove);
			$addHandler(this._element, 'mousemove', this._onMouseMoveHandler);
		}

		if (this._clientEvents["MouseDown"])
		{
			this._onMouseDownHandler = Function.createDelegate(this, this._onMouseDown);
			$addHandler(this._element, 'mousedown', this._onMouseDownHandler);
		}

		if (this._clientEvents["MouseUp"])
		{
			this._onMouseUpHandler = Function.createDelegate(this, this._onMouseUp);
			$addHandler(this._element, 'mouseup', this._onMouseUpHandler);
		}

		if (this._clientEvents["ContextMenu"])
		{
			this._onContextMenuHandler = Function.createDelegate(this, this._onContextMenu);
			$addHandler(this._element, 'contextmenu', this._onContextMenuHandler);
		}

		if (this._clientEvents["Click"])
		{
			this._onClickHandler = Function.createDelegate(this, this._onClick);
			$addHandler(this._element, 'click', this._onClickHandler);
		}

		if (this._clientEvents["DoubleClick"])
		{
			this._onDblClickHandler = Function.createDelegate(this, this._onDblClick);
			$addHandler(this._element, 'dblclick', this._onDblClickHandler);
		}

	},

	_onKeyDown: function (event)
	{
		var eventArgs = new $IG.BrowserEventArgs(event);
		if (this._clientEvents["KeyDown"])
			this._raiseSenderClientEventStart(this, this._clientEvents["KeyDown"], eventArgs);
		if (eventArgs.get_cancel() || this._gridUtil._fireEvent(this, "KeyDown", event))
		{
			$util.cancelEvent(event);
			if ($util.IsOpera)
				this._cancelKeyDownOpera = true;
			return;
		}
		return;
		








		var key = event.keyCode;
		if (key == 39 || key == 37)
		{
			$util.cancelEvent(event);
			return;
		}
		var top = this._container.scrollTop;
		var height = this._container.offsetHeight - 20, max = this._vScrBar ? this._vScrBar.scrollHeight : 0;
		if (height + 21 > max)
			return;
		if (key == 33)
			top -= height;
		else if (key == 34)
			top += height;
		else if (key == 36)
			top = 0;
		else if (key == 35)
			top = max;
		else if (key == 38)
			top -= 20;
		else if (key == 40)
			top += 20;
		else
			return;
		$util.cancelEvent(event);
		this._container.scrollTop = (top < 0) ? 0 : top;
	},
	_onKeyPress: function (event)
	{
		if (this._cancelKeyDownOpera)
		{
			$util.cancelEvent(event);
			this._cancelKeyDownOpera = false;
			return;
		}
		var eventArgs = new $IG.BrowserEventArgs(event);
		if (this._clientEvents["KeyPress"])
			this._raiseSenderClientEventStart(this, this._clientEvents["KeyPress"], eventArgs);
		if (eventArgs.get_cancel() || this._gridUtil._fireEvent(this, "KeyPress", event))
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onKeyUp: function (event)
	{
		var eventArgs = new $IG.BrowserEventArgs(event);
		if (this._clientEvents["KeyUp"])
			this._raiseSenderClientEventStart(this, this._clientEvents["KeyUp"], eventArgs);
		if (eventArgs.get_cancel() || this._gridUtil._fireEvent(this, "KeyUp", event))
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onMouseOver: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["MouseOver"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onMouseOut: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["MouseOut"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onMouseMove: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["MouseMove"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onMouseDown: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["MouseDown"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	


	_dragableElemMouseDown: function (behavior, evntArgs)
	{
		this._gridUtil._fireEvent(this, "DragableElemMouseDown", evntArgs);
	},
	_onMouseUp: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["MouseUp"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onContextMenu: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["ContextMenu"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onClick: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["Click"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_onDblClick: function (event)
	{
		var eventArgs = new $IG.ItemEventArgs(event, this);

		this._raiseSenderClientEventStart(this, this._clientEvents["DoubleClick"], eventArgs);

		if (eventArgs.get_cancel())
		{
			$util.cancelEvent(event);
			return;
		}
	},
	_adjustGridLayout: function ()
	{
		if (this._element.offsetHeight > 0)
		{
			var startHeight = null;
			if (!this._oncePainted)
			{
				startHeight = this._element.clientHeight;
				if (this._elements.outerTbl)
					this._elements.outerTbl.style.display = '';
				this._oncePainted = true;
			}
			if (this._adjustTimerId)
			{
				clearInterval(this._adjustTimerId);
				this._adjustTimerId = null;
			}
			this._gridUtil._fireEvent(this, "InitializingLayout");
			
			
			
			
			
			
			
			
			
			var tblWidth = (this._elements.dataTbl) ? this._elements.dataTbl.offsetWidth : -1;

			this._initializeScrollbar();
			this._onResize({ "clientHeight": startHeight ? startHeight : this._element.clientHeight }, true);

			if (this._isWidthEmpty && tblWidth > 1)
			{
				var dataTblHeight = this._elements.dataTbl.offsetHeight;
				this._element.style.width = (tblWidth + (this._vScrBar ? this._vScrBar.offsetWidth : 0)) + "px";
				this._gridUtil._fireEvent(this, "GridWidthChanged", this._element.style.width);
				this.__setHScrBarVisibility();
				

				if ($util.IsIE8 && dataTblHeight != this._elements.dataTbl.offsetHeight)
				{
					var elementStyleHeight = $util.getPropFromCss(this._element, "height");
					var dtaHeight = this._elements.dataTbl.offsetHeight;
					if (dtaHeight > 0 && (elementStyleHeight == "" || elementStyleHeight == "auto"))
						this._container.style.height = dtaHeight + "px";

				}
			}
			//this._element.style.width = this._element.firstChild.offsetWidth + "px";

			

			if (this._elements.dataTbl)
				this._notifyBehaviorTData = new $IG.NotifySizeChangedBehavior(this._elements.dataTbl, Function.createDelegate(this, this._onDataTblResize));

			this._notifyBehavior = new $IG.NotifySizeChangedBehavior(this._element, Function.createDelegate(this, this._onResize), null, true);

			
			if ($util.IsIEStandards)
				this._notifyBehaviorZeroDimen = new $IG.NotifySizeChangedFromZeroBehavior(this._element, Function.createDelegate(this, this._restoreScroll));

			this._gridUtil._fireEvent(this, "InitializedLayout");
		}
		else
		{
			if (this._adjustTimerId == null)
				this._adjustTimerId = setInterval(Function.createDelegate(this, this._adjustGridLayout), 100);
		}
	},

	_restoreScroll: function ()
	{
		if (this._hScrBar && this._hScrBar.scrollLeft != this.get_scrollLeft())
		{
			this._ignoreCScroll = true;
			this._hScrBar.scrollLeft = this.get_scrollLeft();
			delete this._ignoreCScroll;
		}

		if (this._vScrBar && this._vScrBar.scrollTop != this.get_scrollTop())
		{
			this._ignoreCScroll = true;
			this._vScrBar.scrollTop = this.get_scrollTop();
			delete this._ignoreCScroll;
		}
	},

	_isIgnoreScroll: function ()
	{
		
		
		return $util._ignoreResiseTime && (new Date().getTime()) - $util._ignoreResiseTime < 100;
	},

	_onResize: function (e, init)
	{
		
		if (this._isIgnoreScroll())
			return;
		
		if (!init)
			this._restoreScroll();

		var height = e.clientHeight;
		this._adjustTable();

		

		this.alignCaptions();

		var elementStyle = $util.getRuntimeStyle(this._element);
		//if (this._element.style.height == "" || this._element.style.height == "auto")
		if (elementStyle.height == "" || elementStyle.height == "auto")
		{
			

			height = this._element.clientHeight;
		}

		

		








		if (this._elements.beforeContent)
			height -= this._elements.beforeContent.offsetHeight;
		if (this._elements.afterContent)
			height -= this._elements.afterContent.offsetHeight;

		var hscrVis = (this._hScrBar && this._elements.hScrHeight.style.display != "none");
		if (height > 0 && this._vScrBar)
			this._vScrBar.style.height = height - (hscrVis ? this._scrollBarWidth : 0) + "px";

		var elementStyleHeight = $util.getPropFromCss(this._element, "height");
		if (this._elements.dataTbl.offsetHeight > 0 && (elementStyleHeight == "" || elementStyleHeight == "auto"))
		{
			var dtaHeight = this._elements.dataTbl.offsetHeight;
			//var hscrVis = (this._hScrBar && this._elements.hScrHeight.style.display != "none");
			this._container.style.height = dtaHeight  + "px";
		}
		else
		{
			if (this._headingArea)
				height -= this._headingArea.offsetHeight;
			if (this._footingArea)
				height -= this._footingArea.offsetHeight;

			if (height > 0)
				this._container.style.height = height - (hscrVis ? this._scrollBarWidth : 0) + "px";
		}

		this._initVScrBar();
		this._initHScrBar();


		if (!init)
			this._gridUtil._fireEvent(this, "Resize");
	},

	_onDataTblResize: function (e, timer)
	{
		
		if (this._isIgnoreScroll())
			return;
		


		if (this._isWidthEmpty)
		{
			this._element.style.width = "100%";
			this._gridUtil._fireEvent(this, "GridWidthChanged", this._element.style.width);
		}

		var height = e.clientHeight;
		this._adjustTable();

		

		this.alignCaptions();


		

		








		



		








		var elementStyleHeight = $util.getPropFromCss(this._element, "height");
		if (this._elements.dataTbl.offsetHeight > 0 && (elementStyleHeight == "" || elementStyleHeight == "auto"))
		{
			var dtaHeight = this._elements.dataTbl.offsetHeight;
			var hscrVis = (this._hScrBar && this._elements.hScrHeight.style.display != "none");
			this._container.style.height = dtaHeight  + "px";

			if (this._headingArea)
				dtaHeight += this._headingArea.offsetHeight;
			if (this._footingArea)
				dtaHeight += this._footingArea.offsetHeight;

			if (this._vScrBar)
				this._vScrBar.style.height = dtaHeight - (hscrVis ? this._scrollBarWidth : 0) + "px";
		}

		this._initVScrBar();
		this._initHScrBar();

		

		var tblWidth = this._elements.dataTbl.offsetWidth;
		if (this._isWidthEmpty && tblWidth > 1)
		{
			this._element.style.width = (tblWidth + (this._vScrBar ? this._vScrBar.offsetWidth : 0)) + "px";
			this._gridUtil._fireEvent(this, "GridWidthChanged", this._element.style.width);
		}

	},

	

	




























	_refreshCellHeight: function (cell, height)
	{
		cell.style.height = height;
	},

	_setupCollections: function ()
	{
		this._columns = this._collectionsManager.register_collection(0, $IG.ColumnCollection);
		var providers = this._editorProviders = this._collectionsManager.register_collection(1, $IG.ObjectCollection);
		var items = this._collectionsManager._collections[1];
		for (var i in items)
		{
			var item = items[i];
			providers._addObject(eval(item[1]["c"]["coc"]), document.getElementById(this._id + "_" + item[0][0]), i);
			
			var editor = providers._getObjectByAdr(i);
			if (editor)
				editor._props = item[0];
		}
		










	},

	_initializeMargins: function ()
	{
		this._headingArea = this._elements["headingArea"];
		this._header = this._elements["header"];
		if (this._header)
			this._headerContainer = this._header.firstChild.firstChild;
		this._footingArea = this._elements["footingArea"];
		this._footer = this._elements["footer"];
		if (this._footer)
			this._footerContainer = this._footer.firstChild.firstChild;
		this._columnHeaderRow = this._elements["columnHeaderRow"];
	},

	_get_marginHeight: function ()
	{
		if (typeof (this._marginHeight) == "undefined" || !this._marginHeight)
		{
			this._marginHeight = 0;
			if (this._headingArea)
				this._marginHeight += this._headingArea.offsetHeight;
			if (this._footingArea)
				this._marginHeight += this._headingArea.offsetHeight;
			

		}
		return this._marginHeight;
	},

	_initializeScrollbar: function ()
	{
		// init scrollbars
		

		var vsbElem = this._elements["vsb"];
		if (vsbElem)
		{
			for (var i = 0; i < vsbElem.length; i++)
			{
				if (vsbElem[i].getAttribute("sub"))
					this["_" + vsbElem[i].getAttribute("sub")] = vsbElem[i];
			}
		}
		this._vScrBar = this._elements["vScrBar"];
		this._hScrBar = this._elements["hScrBar"];

		//this._vScrWidth = this._elements["vScrWidth"];
		//this._hScrHeight = this._elements["hScrHeight"];

		if ((this._vScrBar || this._hScrBar) )
		{
			this._scrollBarWidth = this._determineScrollbarWidth();

			if (this._vScrBar)
			{
				this._vScrBar.style.width = this._scrollBarWidth + 1 + "px";
				if (this._vScrWidth)
					this._vScrWidth.style.width = this._vScrBar.style.width;
			}
			if (this._hScrBar)
			{
				







				this._hScrBar.style.height = this._scrollBarWidth + 1 + "px";
				if (this._hScrHeight)
					this._hScrHeight.style.height = this._hScrBar.style.height;
			}
		}

		if (this._vScrBar)
		{
			this._initVScrBar(true);
			if (this._enabled)
				$addHandler(this._vScrBar, "scroll", Function.createDelegate(this, this._onVScrollHandler));
			if (Sys.Browser.agent == Sys.Browser.Firefox)
				$addHandler(this._container, "DOMMouseScroll", Function.createDelegate(this, this._onMouseWheel));
			else
				$addHandler(this._container, "mousewheel", Function.createDelegate(this, this._onMouseWheel));
		}
		if (this._hScrBar)
		{
			this._initHScrBar();
			if (this._enabled)
				$addHandler(this._hScrBar, "scroll", Function.createDelegate(this, this._onHScrollHandler));
		}

		if ((this._vScrBar || this._hScrBar) && this._enabled)
			$addHandler(this._container, "scroll", Function.createDelegate(this, this._onCScrollHandler));
		

















	},

	_initVScrBar: function (init)
	{
		if (this._vScrBar)
		{
			var scrollBarInitHandled = this._gridUtil._fireEvent(this, "VerticalScrollBarHeightInit", this._vScrBar);
			if (!scrollBarInitHandled)
			{
				

				
				if ($util.IsIE && !$util.IsIEStandards)
				{
					
					this._skipSetScrollTop = true;
					this._container.scrollTop = this._vScrBar.scrollTop = this.get_scrollTop();
					delete this._skipSetScrollTop;
				}
			}
			var show = this._container.scrollHeight > this._container.offsetHeight;
			var shown = this._elements.vsb[0].style.display == "";
			
			for (var i = 1; i < this._elements.vsb.length && shown; i++)
				shown &= this._elements.vsb[i].style.display == "";
			if (show ? !shown : shown)
			{
				for (var i = 0; i < this._elements.vsb.length; i++)
					this._elements.vsb[i].style.display = (show ? "" : "none");
				
				if (!init)
				{
					

					this._onResize({ "clientHeight": this._element.clientHeight }, false);
				}
			}
			
			
			





			
			
			var td = this._vScrBar.parentNode, width = this._vScrBar.offsetWidth;
			if (width > 5 && td.offsetWidth < 5)
				this._vScrBar.style.marginLeft = -width + 'px';

			if (!scrollBarInitHandled)
			{
				this._vScrBar.firstChild.style.height = (show ? this._vScrBar.offsetHeight + this._container.scrollHeight - this._container.offsetHeight + "px" : "");
				this._container.scrollTop = this._vScrBar.scrollTop = this.get_scrollTop();
			}
		}
	},

	_initHScrBar: function ()
	{
		if (this._hScrBar)
		{
			if (!this._gridUtil._fireEvent(this, "HorizontalScrollBarWidthInit", this._hScrBar))
			{
				
				var scrollContainer;
				if (this._rows.get_length() < 1 && (this._elements["headerContent"] || this._elements["footerContent"]))
					scrollContainer = this._elements["headerContent"] ? this._elements["headerContent"] : this._elements["footerContent"];
				else
					scrollContainer = this._container;
				

				if ($util.IsIE)
					scrollContainer.scrollLeft = this._hScrBar.scrollLeft = this.get_scrollLeft();
				this._hScrBar.firstChild.style.width = scrollContainer.scrollWidth + "px";
				scrollContainer.scrollLeft = this._hScrBar.scrollLeft = this.get_scrollLeft();
				

				this._onHScrollHandler();
			}
		}
	},

	_determineScrollbarWidth: function ()
	{
		
		var testDiv = document.createElement("DIV");
		document.body.insertBefore(testDiv, document.body.firstChild);
		testDiv.style.visibility = "hidden";
		testDiv.style.position = "absolute";
		testDiv.style.overflow = "auto";
		testDiv.style.width = "100px";
		testDiv.style.height = "100px";
		var testChildDiv = document.createElement("DIV");
		testDiv.appendChild(testChildDiv);
		testChildDiv.style.width = "200px";
		testChildDiv.style.height = "200px";

		var wdth = testDiv.offsetWidth - testDiv.clientWidth;

		
		testDiv.removeChild(testChildDiv);
		if ($util.IsIE)
			testChildDiv.removeNode();
		testChildDiv = null;
		document.body.removeChild(testDiv);
		if ($util.IsIE)
			testDiv.removeNode();
		testDiv = null;
		return wdth;
	},

	_HScrollWithDelta: function (delta)
	{
		var scrLeft = this.get_scrollLeft() + delta;

		// A.Y. 18.4.2011 - we need to programmatically constrain the minimum and maximum value of scrLeft
		// because if the scrolling is done with touch events there is no scrollbar to do that for us
		var maxScrLeft = this._hScrBar.scrollWidth - this._hScrBar.clientWidth;
		if (scrLeft < 0)
			scrLeft = 0;
		if (scrLeft > maxScrLeft)
			scrLeft = maxScrLeft;

		this._container.scrollLeft = scrLeft;

		var margin = "-" + scrLeft + "px";
		var div = this._headerContainer;
		if (div)
		{
			div.firstChild.style.marginLeft = margin;
			
			if (div.scrollLeft != 0)
				div.scrollLeft = 0;
		}
		if (div = this._footerContainer)
		{
			div.firstChild.style.marginLeft = margin;
			
			if (div.scrollLeft != 0)
				div.scrollLeft = 0;
		}
		if (div = this._poolHolder)
		{
			div.style.marginLeft = margin;
			
			if (div.scrollLeft != 0)
				div.scrollLeft = 0;
		}

		
		
		this.set_scrollLeft(scrLeft);
	},

	_VScrollWithDelta: function (delta)
	{
		
		
		if (this._container.scrollHeight <= this._container.clientHeight || (this._container.scrollTop === 0 && delta < 0) || (this._container.scrollTop + this._container.clientHeight >= this._container.scrollHeight && delta > 0))
			return false;
		if (this._get_isAjaxCallInProgress())
			return false;
		if (this._enabled)
		{
			this._container.scrollTop += delta;
		}
		return true;
	},

	_onHScrollHandler: function (evnt)
	{
		if (this._gridUtil._fireEvent(this, "ScrollLeftChange"))
			return;
		this._ignoreCScroll = true;

		var delta = 0;
		


		if (this._hScrBar.offsetHeight > 0)
		{
			delta = this._hScrBar.scrollLeft - this.get_scrollLeft();
		}
		this._HScrollWithDelta(delta);

		
		this._gridUtil._fireEvent(this, "ScrollLeftChanged");
		delete this._ignoreCScroll;
	},

	_onVScrollHandler: function (evnt)
	{
		if (this._gridUtil._fireEvent(this, "ScrollTopChange"))
			return;
		this.set_scrollTop(this._vScrBar.scrollTop);
		this._adjustScrollTop();
	},

	_adjustScrollTop: function ()
	{
		this._ignoreCScroll = true;
		
		
		this._container.scrollTop = this._vScrBar.scrollTop - this._scrollMinus;
		delete this._ignoreCScroll;
	},

	_onMouseWheel: function (evnt)
	{
		var evt = evnt ? evnt.rawEvent : null;
		if (!evt)
			return;

		var delta = evt.wheelDelta;
		if (delta)
			delta /= -3;
		else if (delta = evt.detail)
			delta *= 13;
		if (!delta)
			return;

		
		if (this._VScrollWithDelta(delta))
		{
			$util.cancelEvent(evnt);
		}
		this._gridUtil._fireEvent(this, "MouseWheel");
	},

	_onTouchStart: function (evnt)
	{
		this._lastTouchCoords = $util._getTouchCoords(evnt.rawEvent);
		this._lastTouchTime = (new Date()).getTime();
		this._velocity = new Object();
		this._velocity.vx = 0;
		this._velocity.vy = 0;
		this._count = 0;
		if (this._GridScrollInertiaId != null)
			this._GridScrollInertiaId = clearInterval(this._GridScrollInertiaId);
	},

	_onTouchMove: function (evnt)
	{
		if (this._lastTouchCoords == null)
		{
			evnt.preventDefault();
			return;
		}
		var touchCoords = $util._getTouchCoords(evnt.rawEvent);
		var moveTime = (new Date()).getTime();
		var touchDeltaX = touchCoords.x - this._lastTouchCoords.x;
		var touchDeltaY = touchCoords.y - this._lastTouchCoords.y;
		this._velocity.vx = touchDeltaX / (moveTime - this._lastTouchTime) * 1000;
		this._velocity.vy = touchDeltaY / (moveTime - this._lastTouchTime) * 1000;
		this._lastTouchCoords = touchCoords;
		this._lastTouchTime = moveTime;

		if (touchDeltaY != 0)
			this._touchScrollTop(-touchDeltaY);

		if (touchDeltaX != 0)
			this._touchScrollLeft(-touchDeltaX);

		evnt.preventDefault();
	},

	_onTouchEnd: function (evnt)
	{
		if (this._velocity.vx != 0 || this._velocity.vy != 0)
			this._GridScrollInertiaId = setInterval(Function.createDelegate(this, this._keepScrolling), 100);
	},

	_keepScrolling: function ()
	{
		if (this._count < 10)
		{
			var x = ((-Math.pow(this._count * 100, 2) * (0 - this._velocity.vx)) / Math.pow(1000, 2)) + ((2 * this._count * 100 * (0 - this._velocity.vx)) / 1000) + this._velocity.vx;
			var y = ((-Math.pow(this._count * 100, 2) * (0 - this._velocity.vy)) / Math.pow(1000, 2)) + ((2 * this._count * 100 * (0 - this._velocity.vy)) / 1000) + this._velocity.vy;
			this._touchScrollLeft(-x / 10);
			this._touchScrollTop(-y / 10);
			this._count++;
		}
		else
			this._GridScrollInertiaId = clearInterval(this._GridScrollInertiaId);
	},

	_touchScrollTop: function (deltaTop)
	{
		this._VScrollWithDelta(deltaTop);

		this._gridUtil._fireEvent(this, "TouchScrolledTop");
	},

	_touchScrollLeft: function (deltaLeft)
	{
		if (!this._gridUtil._fireEvent(this, "TouchScrollingLeft", { deltaScrollLeft: deltaLeft }))
		{
			this._HScrollWithDelta(deltaLeft);
		}
	},

	_onCScrollHandler: function (evnt)
	{
		var util = this._gridUtil;
		if (!util || this._ignoreCScroll)
			return false;
		if (this._vScrBar)
		
		
			this._vScrBar.scrollTop = this._container.scrollTop + this._scrollMinus;
		if (this._hScrBar)
		{
			
			
			
			
			var time = util._noScrollTime, noLeft = util._noScrollLeft, left = this._container.scrollLeft;
			if (time && time + 1000 > (new Date()).getTime()) if ((noLeft = Math.max(0, noLeft)) != left)
			
				this._container.scrollLeft = left = noLeft;
			if (this._hScrBar.scrollLeft == left)
				return;
			
			var evntArgs = { event: evnt, containerScrollLeft: left };
			if (util._fireEvent(this, "CScrollLeftChange", evntArgs))
				return;
			this._hScrBar.scrollLeft = evntArgs.containerScrollLeft;
		}
	},

	__handleOnSelectstart: function ()
	{
		var selectStart = ($util.IsIE ? "selectstart" : "mousedown");
		$addHandler(this._element, selectStart, Function.createDelegate(this, this._onSelectstartContainer));
		if (this._columnHeaderRow)
		{
			if (this._columnHeaderRow.length)
			{
				for (var i = 0; i < this._columnHeaderRow.length; i++)
					$addHandler(this._columnHeaderRow[i], selectStart, Function.createDelegate(this, this._onSelectstartHeader));
			}
			else
				$addHandler(this._columnHeaderRow, selectStart, Function.createDelegate(this, this._onSelectstartHeader));
		}
	},

	__removeOnSelectstart: function ()
	{
		




		if (this._element)
			$clearHandlers(this._element);
		if (this._columnHeaderRow)
		{
			if (this._columnHeaderRow.length)
			{
				for (var i = 0; i < this._columnHeaderRow.length; i++)
					$clearHandlers(this._columnHeaderRow[i]);
			}
			else
				$clearHandlers(this._columnHeaderRow);
		}
	},

	_onSelectstartContainer: function (evnt)
	{
		this._gridUtil._fireEvent(this, "SelectStartContainer", evnt);
	},

	_onSelectstartHeader: function (evnt)
	{
		$util.cancelEvent(evnt);
	},

	_createItem: function (element, adr, itemCount)
	{
		//this._itemCollection.addObject($IG.GridRow, element, adr);
	},

	//////////////////////// AUX ROWS /////////////////////////////

	_get_auxRows: function (alignment)
	{
		if (alignment == $IG.GridAuxRows.Top)
			return this._auxRowsTop;
		if (alignment == $IG.GridAuxRows.Bottom)
			return this._auxRowsBottom;
		return this._auxRowsTop.concat(this._auxRowsBottom);
	},

	_isAuxRow: function (row, alignment)
	{
		if (typeof (alignment) == "undefined")
			return this._isAuxRow(row, $IG.GridAuxRows.Top) || this._isAuxRow(row, $IG.GridAuxRows.Bottom);

		var auxRows = this._get_auxRows(alignment);
		for (var i = 0; i < auxRows.length; i++)
			if (auxRows[i] == row)
				return true;
		return false;
	},

	_get_auxRowIndex: function (row, alignment)
	{
		if (typeof (alignment) == "undefined")
			throw "Must indicate alignment of the aux rows";
		var auxRows = this._get_auxRows(alignment);
		for (var i = 0; i < auxRows.length; i++)
			if (auxRows[i] == row)
				return i;
		return -1;
	},

	_registerAuxRow: function (row, alignment)
	{
		if (typeof (alignment) == "undefined")
			throw "Must indicate alignment of the aux rows";
		var auxRows = this._get_auxRows(alignment);
		auxRows[auxRows.length] = row;
		row._element.setAttribute("auxRow", alignment);
		row._element.setAttribute("adr", auxRows.length - 1);
	},

	//////////////////////// END AUX ROWS /////////////////////////////

	_columns: null,

	get_columns: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataGrid.columns">Returns column collection of the grid.</summary>
		///<value type="Infragistics.Web.UI.ColumnCollection">Column collection of the grid.</value>
		return this._columns;
	},

	get_defaultColumnWidth: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.defualtColumnWidth">
		/// Gets the defualt width of the columns.
		/// </summary>
		/// <value type="String" />
		return this._get_clientOnlyValue("dcwidth");
	},
	_initializeObjects: function ()
	{
		var rawColumns = this._columns._manager._collections[0];
		for (var index in rawColumns)
		{

			if (!isNaN(parseInt(index)))
			{
				var column = this._columns._addObject($IG.GridColumn, null, index);
				column._parentCollection = this._columns;
			}

		}

		if (this.get_enableClientRendering())
		{
			//A.T. also initialize the binding classes
			this.__loadClientBindingObjects();
			this.applyClientBinding();
		}

		this._rows = new $IG.GridRowCollection(this._elements["rows"], [this._get_value($IG.WebDataGridProps.RowCount)], this);

		if (this._enabled)
		{
			// initialize behavior container
			
			this._initializeBehaviors(this._objectsManager._objects, this, this.get_behaviors(), this._objectsManager._objects.length - 1, 1);
			// initialize behavior collection and notify all behaviors about initializeComplete
			this.get_behaviors()._initializeBehaviors();

			this._initializeBehaviorComplete(this.get_behaviors());
		}

		if (this.get_enableClientRendering())
		{
			if (this._rows.get_length() > 0)
				this._adjustFirstRowHTML(this._rows.get_row(0));
			if (this._enabled)
			{
				

				this._gridUtil._fireEvent(this, "DataBound", { init: true });
			}
		}
	},

	_initializeBehaviorComplete: function (behaviors)
	{
		var editing = this.get_behaviors().get_editingCore();
		if (editing)
		{
			var cols = this.get_columns();
			var colCount = cols.get_length();
			for (var x = 0; x < colCount; ++x)
			{
				var col = cols.get_column(x);
				if (col._isCheck)
				{
					col._editableCheckbox = editing != null;
					if (editing != null)
					{
						var cellEditing = editing.get_behaviors().get_cellEditing();
						if (cellEditing != null)
						{
							var colSet = cellEditing.get_columnSettingFromKey(col._key);
							if (colSet && colSet.get_readOnly())
								col._editableCheckbox = false;
						}
					}
				}
			}
		}
		for (var i = 0; i < behaviors._behaviors.length; i++)
		{
			var behavior = behaviors._behaviors[i];
			if (behavior)
			{
				behavior._initializeComplete();
				if ($IG.IGridBehaviorContainer.isInstanceOfType(behavior))
				{
					var subBehCollection = behavior.get_behaviors();
					if (subBehCollection)
						this._initializeBehaviorComplete(subBehCollection);
				}
			}
		}
	},

	_behaviors: null,
	get_behaviors: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataGrid.behaviors">
		///Returns the grid's behavior collection.
		///All of the grid behaviors are contained by this collection.
		///</summary>
		///<value type="Infragistics.Web.UI.GridBehaviorCollection">Behavior collection of the grid.</value>
		if (this._behaviors == null)
			this._behaviors = new $IG.GridBehaviorCollection(this);
		return this._behaviors;
	},

	_saveAdditionalClientState: function ()
	{
		this._fixPool();
		return this._actionList.get_list();
	},

	
	_fixPool: function ()
	{
		
		var pool = this._editorProvidersPool;
		pool = pool ? pool.childNodes : null;
		var i = pool ? pool.length : 0;
		while (i-- > 0)
			this._oldParent_IEBug(pool[i]);
	},
	
	
	
	
	
	_oldParent_IEBug: function (elem)
	{
		
		if (!elem || !elem._oldParent_IEBug)
			return;
		elem._oldParent_IEBug = null;
		
		var old = elem._oldParent, parent = elem.parentNode;
		if (old && old != parent) try
		{
			parent.removeChild(elem);
			old.appendChild(elem);
		}
		catch (old) { }
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataGrid.dispose">
		///Disposes of the grid object.
		///</summary>
		if (this._adjustTimerId)
		{
			clearInterval(this._adjustTimerId);
			this._adjustTimerId = null;
		}
		if (this._notifyBehavior)
			this._notifyBehavior.dispose();
		if (this._notifyBehaviorTData)
			this._notifyBehaviorTData.dispose();
		this.__removeOnSelectstart();
		if (this.get_element())
			$clearHandlers(this.get_element());
		if (this._container)
			$clearHandlers(this._container);
		var rows = this.get_rows();
		if (rows)
			rows.dispose();
		if (this._headingArea)
			$clearHandlers(this._headingArea);
		if (this._footingArea)
			$clearHandlers(this._footingArea);
		if (this._vScrBar)
			$clearHandlers(this._vScrBar);
		if (this._hScrBar)
			$clearHandlers(this._hScrBar);
		this._auxRowsTop = null;
		this._auxRowsBottom = null;
		this._poolHolder = null;

		if (this._container)
			$clearHandlers(this._container);
		delete this._onKeyDownHandler;
		delete this._onKeyPressHandler;
		delete this._onKeyUpHandler;
		delete this._onTouchStartHandler;
		delete this._onTouchMoveHandler;
		delete this._onTouchEndHandler;
		if (this["_onMouseOverHandler"])
			delete this._onMouseOverHandler;
		if (this["_onMouseOutHandler"])
			delete this._onMouseOutHandler;
		if (this["_onMouseMoveHandler"])
			delete this._onMouseMoveHandler;
		if (this["_onMouseDownHandler"])
			delete this._onMouselickHandler;
		if (this["_onMouseUpHandler"])
			delete this._onMouseUpHandler;
		if (this["_onContextMenuHandler"])
			delete this._onContextMenuHandler;
		if (this["_onClickHandler"])
			delete this._onClickHandler;
		if (this["_onDblClickHandler"])
			delete this._onDblClickHandler;

		
		if(this._onHideColumnCssCreatedClientRenderingHandler)
		{
			this._gridUtil._unregisterEventListener(this, "HideColumnCssCreated", this._onHideColumnCssCreatedClientRenderingHandler);
			this._onHideColumnCssCreatedClientRenderingHandler = null;
		}

		if (this._actionList)
			this._actionList.dispose();

		if (this._gridUtil)
			this._gridUtil.dispose();
		this._fixPool();
		this._editorProvidersPool = null;
		this._container = null;
		this._headingArea = null;
		this._header = null;
		this._headerContainer = null;
		this._footingArea = null;
		this._footer = null;
		this._footerContainer = null;
		this._columnHeaderRow = null;
		this._vScrBar = null;
		this._hScrBar = null;
		this._vScrWidth = null;
		this._hScrHeight = null;
		this._lastTouchCoords = null;
		this._velocity = null;
		this._count = null;

		if (this._behaviors)
		{
			this._behaviors.dispose();
			this._behaviors = null;
		}

		var ele = this._element;
		$IG.WebDataGrid.callBaseMethod(this, "dispose");

		
		//this.__detectAttachedHandlers(ele);
		//this.__detectAttachedElements(this);
		//this.__detectCircularRefs(this, "grid", new Array());
		//this.__detectDOMRefs(ele, ele.tagName + " " + ele.id);
		//this.__detectInternalEventHandlers();
		
	},

	































































































































































	alignCaptions: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataGrid.alignCaptions">
		///Aligns the captions with the data columns of the grid. The method can be
		///called if you're using the grid in an unusual environment and the 
		///cells are getting misaligned from the headers.
		///</summary>
		this._adjustTable();

		if (this._header)
			this._alignStatCaption("headerContent");
		if (this._footer)
			this._alignStatCaption("footerContent");
		if (this._rows.get_length() < 1)
			this._alignFooter();
	},
	_adjustTableWidth: function ()
	{
		//debugger;
		var tables = [this._elements["headerContent"], this._elements["dataTbl"], this._elements["footerContent"]];
		for (var i = 0; i < tables.length; i++)
		{
			var table = tables[i];
			if (table && table.rows.length > 0)
			{
				var tableWidth = table.style.width;
				if (tableWidth && (tableWidth + "").indexOf("px") != -1)
				{
					var row = table.rows[0];
					tableWidth = 0;
					for (var j = 0; j < row.cells.length; j++)
					{
						var cell = row.cells[j];
						if (!$util.IsIEStandards || $util.getPropFromCss(cell, "display") != "none")
							tableWidth += cell.offsetWidth;
					}
					if (tableWidth > 0)
						table.style.width = tableWidth + "px";
				}
				






			}
		}
	},
	




	_adjustTable: function ()
	{
		this.__setHScrBarVisibility();
		if (this._elements.vsb)
		{
			var show = this._container.scrollHeight > this._container.offsetHeight;
			for (var i = 0; i < this._elements.vsb.length; i++)
				this._elements.vsb[i].style.display = (show ? "" : "none");
		}
	},
	__setHScrBarVisibility: function ()
	{
		if (this._elements.hScrHeight)
		{
			

			var scrollContainer;
			var container = null;
			if (this._rows.get_length() < 1 && (this._elements["headerContent"] || this._elements["footerContent"]))
			{
				scrollContainer = this._elements["headerContent"] ? this._elements["headerContent"] : this._elements["footerContent"];
				
				if ($util.IsIE && !$util.IsIEStandards && this._isWidthEmpty)
					container = scrollContainer;
			}
			else
				scrollContainer = this._elements.dataTbl;

			if (!this._gridUtil._fireEvent(this, "ShowHorizontalScrollBar", { "scrollBar": this._elements.hScrHeight, "scrollContainer": scrollContainer, "container": this._container }))
				this._elements.hScrHeight.style.display = (scrollContainer.offsetWidth > (container == null ? this._container.offsetWidth : container.offsetWidth) ? "" : "none"); 
		}
	},
	_alignStatCaption: function (captionProperty)
	{
		

		var eventArgs = { "captionProperty": captionProperty, "alignPixels": false };
		if (this._gridUtil._fireEvent(this, "AlignStatCaption", eventArgs))
			return;

		var capElem = this._elements[captionProperty];
		capElem.style.width = "";
		capElem.style.tableLayout = "fixed";

		var row = this._rows.get_row(0);
		if (row)
		{
			var rowElem = this.__getResizeRowElement(row);

			for (var i = 0; i < rowElem.childNodes.length; i++)
			{
				var cell = rowElem.childNodes[i];
				var rows = $util.getRows(capElem);
				var caption = rows && rows.length ? rows[0].childNodes[i] : null;

				if (caption)
				{
					caption.style.width = "";
				}
			}

			if (this._isWidthEmpty)
			{
				
				capElem.style.tableLayout = "auto";
				

				if (this._elements.dataTbl.clientWidth == 0 && this.get_rows().get_length() == 0)
					capElem.style.width = this._element.style.width ? this._element.style.width : "";
				else
					capElem.style.width = this._elements.dataTbl.clientWidth + "px";
				capElem.style.tableLayout = "fixed";
			}
			else if (!$util.IsWebKit)
				capElem.style.width = this._elements.dataTbl.clientWidth + "px";

			for (var i = 0; i < rowElem.childNodes.length; i++)
			{
				var cell = rowElem.childNodes[i];
				var rows = $util.getRows(capElem);
				var caption = rows && rows.length ? rows[0].childNodes[i] : null;

				if (caption)
				{
					


					if (eventArgs.alignPixels || $util.IsWebKit || this._isWidthEmpty || cell.style.width.indexOf("px") > 0 || $util.IsIE && cell.currentStyle.width.indexOf("px") > 0)
					{
						if ($util.IsWebKit && this._isWidthEmpty)
							caption.style.width = cell.offsetWidth + "px";
						else
							$util.setAbsoluteWidth(caption, cell.offsetWidth);
					}
					else
						caption.style.width = cell.style.width;
				}
			}
		}
		else
		{
			
			capElem.style.tableLayout = "auto";
			

			if (this._elements.dataTbl.clientWidth == 0 && this.get_rows().get_length() == 0)
				capElem.style.width = this._element.style.width ? this._element.style.width : "";
			else
				capElem.style.width = this._elements.dataTbl.clientWidth + "px";
			capElem.style.tableLayout = "fixed";
		}
	},

	__getResizeRowElement: function (row)
	{
		return row.get_element();
	},

	

	_alignFooter: function ()
	{
		if (this._gridUtil._fireEvent(this, "AlignFooter"))
			return;
		var headerRows = $util.getRows(this._elements["headerContent"]);
		var headerRow = (headerRows && headerRows.length) ? headerRows[0] : null;
		var footerRows = $util.getRows(this._elements["footerContent"]);

		if (headerRow && footerRows && footerRows.length)
		{
			for (var i = 0; i < headerRow.childNodes.length; i++)
			{
				var headerCell = headerRow.childNodes[i];
				if (headerCell.offsetWidth > 0)
				{
					var footerCell = footerRows[0].childNodes[i];
					
					
					if (footerCell)
						$util.setAbsoluteWidth(footerCell, headerCell.offsetWidth );
				}
			}
		}
	},
	_responseComplete: function (callbackObject, responseObject, browserResponseObject)
	{
		//

		
		

		var grid = this;
		var responseOptions = Sys.Serialization.JavaScriptSerializer.deserialize(responseObject.context[0]);

		if (responseOptions.fullRender)
		{
			
			this._parkEditorProvidersPool();
			grid._gridUtil._fireEvent(grid, "BeforeAsyncRender");
			grid = this._renderOnAsyncResponse(responseObject.context[1], responseObject.context[2]);
		}
		else
		{
			grid._gridUtil._fireEvent(grid, "BeforeAsyncRender");
			var behaviorName = callbackObject.serverContext["behavior"];
			if (behaviorName)
			{
				var behavior = this.get_behaviors().getBehaviorByName(behaviorName);
				behavior._responseComplete(callbackObject, responseOptions);
			}
		}
		grid._gridUtil._appendCssClasses(responseOptions.cssClasses);
		this._set_isAjaxCallInProgress(false);

		grid._raiseClientEvent("AJAXResponse", "GridAJAXResponse", browserResponseObject, this._customResponse(responseObject));
	},
	_responseCompleteError: function (callbackObject, browserResponseObject, timedOut, message)
	{
		this._actionList.clear();
		this._gridUtil._fireEvent(this, "PostBackFailed");
		this._set_isAjaxCallInProgress(false);
		
		$IG.WebDataGrid.callBaseMethod(this, '_responseCompleteError', [callbackObject, browserResponseObject, timedOut, message]);
	},
	_renderOnAsyncResponse: function (props, html)
	{
		//
		var props = eval(props);

		var div = document.createElement("DIV");
		div.innerHTML = html;
		var id = this.get_id();
		var name = this.get_name();
		var element = this._element;

		// Have to extract table and put it in the same place.
		// If we don't do so the WebResizingExtender disappears after asynch call
		var newElement = div.firstChild;
		while (newElement)
		{
			if (newElement.id == id)
				break;
			newElement = newElement.nextSibling;
		}

		this._gridUtil._fireEvent(this, "AsyncRendering", { newElement: newElement, gridElement: element, tableElement: this._elements.outerTbl });
		newElement = newElement.firstChild;
		while (newElement)
		{
			if (newElement.tagName == "TABLE" && newElement.id.indexOf("outerTbl"))
				break;
			newElement = newElement.nextSibling;
		}

		var parent = newElement.parentNode;
		parent.removeChild(newElement);

		var tableElement = this._elements.outerTbl;

		this.dispose();

		var tableNextSibling = tableElement.nextSibling;
		element.removeChild(tableElement);
		if ($util.IsIE)
			tableElement.removeNode();

		if (tableNextSibling)
			element.insertBefore(newElement, tableNextSibling);
		else
			element.appendChild(newElement);

		if ($util.IsIE)
			div.removeNode();

		return $create($IG.WebDataGrid, { "id": id, "name": name, "props": props }, null, null, $get(id));
	},
	_cell_index_offset: 0,
	_get_cellIndexOffset: function ()
	{
		return this._cell_index_offset;
	},
	_incrementCellIndexOffset: function ()
	{
		this._cell_index_offset++;
	},
	_decrementCellIndexOffset: function ()
	{
		if (this._cell_index_offset == 0)
			return;
		this._cell_index_offset--;
	},
	_notifyPost: function (eventArgs, postBack)
	{
		var cancel = false;
		if (postBack == 2)
			cancel = this._gridUtil._fireEvent(this, "AjaxPostBackStart");
		if (!cancel && (postBack == 1 || postBack == 2))
			cancel = this._gridUtil._fireEvent(this, "PostBackStart");
		if (cancel)
		{
			if (typeof (eventArgs.set_cancel) != "undefined")
				eventArgs.set_cancel(true);
		}
		return cancel;
	},
	_raiseSenderClientEventStart: function (sender, clientEvent, eventArgs)
	{
		if (!this._notifyPost(eventArgs, clientEvent.postBack))
			eventArgs = $IG.WebDataGrid.callBaseMethod(this, '_raiseSenderClientEventStart', [sender, clientEvent, eventArgs]);
		return eventArgs;
	},
	_raiseClientEventStart: function (eventArgs)
	{
		if (!this._notifyPost(eventArgs, eventArgs._props ? eventArgs._props[1] : 0))
			eventArgs = $IG.WebDataGrid.callBaseMethod(this, '_raiseClientEventStart', [eventArgs]);
		return eventArgs;
	},
	_raiseClientEventEnd: function (eventArgs)
	{
		if (!this._get_isAjaxCallInProgress())
		{
			if (eventArgs._props && eventArgs._props[1] == 2)
			{
				this._set_isAjaxCallInProgress(true);
				this._asyncPostStart();
			}
			eventArgs = $IG.WebDataGrid.callBaseMethod(this, '_raiseClientEventEnd', [eventArgs]);
		}
		return eventArgs;
	},
	_get_isAjaxCallInProgress: function ()
	{
		return this._isAjaxCallInProgress;
	},
	_set_isAjaxCallInProgress: function (value)
	{
		this._isAjaxCallInProgress = value;
	},
	_asyncPostStart: function ()
	{
		
		
	},

	_ensureEditorProvidersPool: function (container)
	{
		var epp = this._editorProvidersPool;
		
		






		if (!epp || container.firstChild == epp)
			return;
		if (epp.parentNode)
			epp.parentNode.removeChild(epp);
		container.insertBefore(epp, container.firstChild);
		epp.style.display = "";
	},

	_parkEditorProvidersPool: function ()
	{
		var pool = this._poolHolder, elem = this._element;
		if (!pool || !elem)
			return;
		pool.parentNode.removeChild(pool);
		elem.parentNode.insertBefore(pool, elem);
		for (var ep in this._editorProviders._items)
		{
			if (!isNaN(parseInt(ep)))
				this._editorProviders._items[ep]._editor = null;
		}
	},

	_addElementEventHandler: function (element, eventType, handler)
	{
		///<summary>
		///Adds an element event handler to the behavior collection hash.
		///</summary>
		///<returns>
		///Boolean. Indicates whether the handler was successfully added.
		///</returns>

		var key = this.__resolveKey(element, eventType);

		var resolvedHashItem = this._eventHandlerHash[key];
		if (!resolvedHashItem)
		{
			resolvedHashItem = this._eventHandlerHash[key] = [];
			this._eventHandlerHash.length++;
		}

		for (var i = 0; i < resolvedHashItem.length; i++)
		{
			if (resolvedHashItem[i] == handler)
				return false;
		}

		if (resolvedHashItem.length == 0)
		{
			var internalHandler = this._eventHandlerHash.handlers[key] = Function.createDelegate(resolvedHashItem, this._elementEventHandler);
			$addHandler(element, eventType, internalHandler);
		}

		resolvedHashItem[resolvedHashItem.length] = handler;

		return true;
	},

	_removeElementEventHandler: function (element, eventType, handler)
	{
		///<summary>
		///Removes an element event handler from the behavior collection hash.
		///</summary>
		///<returns>
		///Boolean. Indicates whether the handler was successfully removed.
		///</returns>

		var key = this.__resolveKey(element, eventType);

		var resolvedHashItem = this._eventHandlerHash[key];
		if (!resolvedHashItem)
			return false;

		for (var i = 0; i < resolvedHashItem.length; i++)
		{
			if (resolvedHashItem[i] == handler)
			{
				resolvedHashItem.splice(i, 1);
				if (resolvedHashItem.length == 0)
				{
					try
					{
						$removeHandler(element, eventType, this._eventHandlerHash.handlers[key]);
					} catch (e) { };
					delete this._eventHandlerHash[key];
					delete this._eventHandlerHash.handlers[key];
					//Could decrease the length but that will potentially introduce the ehh_id collision
					//this._eventHandlerHash.length--;
				}
				return true;
			}
		}
		return false;
	},

	__resolveKey: function (element, eventType)
	{
		if (!element)
			return null;
		var ehh_id = element.id;
		if (element.getAttribute)
		{
			if (!ehh_id)
				ehh_id = element.getAttribute("_ehh_id_" + eventType);
			if (!ehh_id)
			{
				ehh_id = "_ehh_id_" + this._eventHandlerHash.length;
				element.setAttribute("_ehh_id_" + eventType, ehh_id);
			}
		}
		else
		{
			ehh_id = element._ehh_id;
			if (!ehh_id)
				ehh_id = element._ehh_id = "_ehh_id_" + this._eventHandlerHash.length;
		}

		return ehh_id + "_" + eventType;
	},
	
	
	_getTopGrid: function ()
	{
		return null;
	},

	_elementEventHandler: function (evnt)
	{
		$util._browser_evt = evnt;
		var resolvedHashItem = this;
		for (var i = 0; i < resolvedHashItem.length; i++)
			resolvedHashItem[i](evnt);
		$util._browser_evt = null;
	},
	get_scrollTop: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.scrollTop">
		/// Keeps server side value of the scroll top position of the data.
		/// </summary>
		/// <value type="Number" integer="true" />
		return this._get_value($IG.WebDataGridProps.ScrollTop);
	},
	set_scrollTop: function (value)
	{
		
		if (!this._skipSetScrollTop)
			this._set_value($IG.WebDataGridProps.ScrollTop, value);
	},
	get_scrollLeft: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.scrollLeft">
		/// Keeps server side value of the scroll left position of the data.
		/// </summary>
		/// <value type="Number" integer="true"/>
		return this._get_value($IG.WebDataGridProps.ScrollLeft);
	},
	set_scrollLeft: function (value)
	{
		this._set_value($IG.WebDataGridProps.ScrollLeft, value);
	},

	get_dataSource: function ()
	{
		/// <summary>
		/// Gets the data source that the WebDataGrid is displaying data for.
		/// The returned result is a json array.
		/// </summary>
		return this._dataStore[this._dataStore.length - 1];
	},


	set_dataSource: function (value)
	{
		/// <summary>
		/// Sets the data source that the WebDataGrid is displaying data for
		/// when client-side data binding is going to be performed.
		/// The value parameter can accepts json array only, generated at the 
		/// client or retrieved as a result from Ajax anabled web service call.
		/// </summary>
		this._dataStore[this._dataStore.length - 1] = value;
	}
}

$IG.WebDataGrid.registerClass('Infragistics.Web.UI.WebDataGrid', $IG.NavControl, $IG.IGridBehaviorContainer);



$IG.WebDataGrid.find = function (clientID)
{
	///<summary>Finds WebDataGrid by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDataGrid">Reference to the WebDataGrid control object that corresponds to specified client ID.</returns>
};

$IG.WebDataGrid.from = function (obj)
{
	///<summary>Casts passed in object to the WebDataGrid type.</summary>
	///<param name="obj">Object to convert to the WebDataGrid type.</param>
	///<returns type="Infragistics.Web.UI.WebDataGrid">Reference to the same object that is passed in, only type converted to the WebDataGrid type.</returns>
};

$IG.GridAuxRows = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.GridAuxRows">Auxilary rows (such as filer row and add new row) collection location.</summary>
	///<field name="Top" type="Number" integer="true" static="true">Auxilary rows are on the top of the grid.</field>
	///<field name="Bottom" type="Number" integer="true" static="true">Auxilary rows are on the bottom of the grid.</field>
};
$IG.GridAuxRows.prototype =
{
	Top: 0,
	Bottom: 1
};

$IG.GridAuxRows.registerEnum("Infragistics.Web.UI.GridAuxRows");


$IG.WebDataGridProps = new function ()
{
	var propCount = $IG.ControlMainProps.Count;
	this.RowCount = [propCount++, 0];
	this.ScrollTop = [propCount++, 0];
	this.ScrollLeft = [propCount++, 0];	
	this.Count = propCount;
};



$IG.GridBehaviorCollection = function (control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridBehaviorCollection">
	/// Grid behavior collections. Contains helper properties for explicit access to the behaviors.
	/// </summary>
	/// <param name="control" type="Infragistics.Web.UI.WebDataGrid">Reference to the owner control.</param>
	$IG.GridBehaviorCollection.initializeBase(this, [control]);
}

$IG.GridBehaviorCollection.prototype =
{
	_paging: null,
	get_paging: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.paging">
		/// Returns reference to the paging behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Paging"></returns>
		return this._paging;
	},

	_selection: null,
	get_selection: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.selection">
		/// Returns reference to the selection behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Selection"></returns>
		return this._selection;
	},

	_activation: null,
	get_activation: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.activation">
		/// Returns reference to the activation behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Activation"></returns>
		return this._activation;
	},

	_rowSelectors: null,
	get_rowSelectors: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.rowSelectors">
		/// Returns reference to the row selectors behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.RowSelectors"></returns>
		return this._rowSelectors;
	},

	_columnResizing: null,
	get_columnResizing: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.columnResizing">
		/// Returns reference to the column resizing behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.ColumnResizing"></returns>
		return this._columnResizing;
	},

	_columnMoving: null,
	get_columnMoving: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.columnMoving">
		/// Returns reference to the column moving behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.ColumnMoving"></returns>
		return this._columnMoving;
	},

	_editingCore: null,
	get_editingCore: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.editingCore">
		/// Returns reference to the editing core behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.EditingCore"></returns>
		return this._editingCore;
	},

	_sorting: null,
	get_sorting: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.sorting">
		/// Returns reference to the sorting behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Sorting"></returns>
		return this._sorting;
	},

	_filtering: null,
	get_filtering: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.filtering">
		/// Returns reference to the filtering behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Filtering"></returns>
		return this._filtering;
	},

	_virtualScrolling: null,
	get_virtualScrolling: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.virtualScrolling">
		/// Returns reference to the virtual scrolling behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.VirtualScrolling"></returns>
		return this._virtualScrolling;
	},

	_columnFixing: null,
	get_columnFixing: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.columnFixing">
		/// Returns reference to the column fixing behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.ColumnFixing"></returns>
		return this._columnFixing;
	},

	_summaryRow: null,
	get_summaryRow: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorCollection.summaryRow">
		/// Returns reference to the summary row behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.SummaryRow"></returns>
		return this._summaryRow;
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridBehaviorCollection.dispose">
		///Disposes of the behaviors object.
		///</summary>
		this._paging = null;
		this._selection = null;
		this._activation = null;
		this._rowSelectors = null;
		this._columnResizing = null;
		this._editingCore = null;
		this._sorting = null;
		this._filtering = null;
		this._virtualScrolling = null;
		this._columnFixing = null;
		this._summaryRow = null;
		$IG.GridBehaviorCollection.callBaseMethod(this, "dispose");
	}
}

$IG.GridBehaviorCollection.registerClass('Infragistics.Web.UI.GridBehaviorCollection', $IG.BehaviorCollectionBase);



$IG.ColumnCollection = function (control, clientStateManager, index, manager)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnCollection">
	/// Column collection object. Contains the grid's columns.
	/// </summary>

	$IG.ColumnCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.ColumnCollection.prototype =
{
	





	


























	get_column: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnCollection.column">
		/// Gets a column from the collection by its index.
		/// </summary>
		/// <param name="index" type="Number" integer="true">Index of the column in the collection.</param>
		/// <returns type="Infragistics.Web.UI.GridColumn"></returns>
		return this._items[index];
	},
	get_columnFromKey: function (key)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnCollection.columnFromKey">
		/// Gets a column from the collection by its key.
		/// </summary>
		/// <param name="key" type="String">Key of the column in the collection.</param>
		/// <returns type="Infragistics.Web.UI.GridColumn"></returns>
		for (var i = 0; i < this._items.length; i++)
		{
			var column = this.get_column(i);
			if (column.get_key() == key)
				return column;
		}
		return null;
	},

	get_columnFromIDPair: function (idPair)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnCollection.columnFromIDPair">
		/// Gets a column from the collection by its ID pair.
		/// </summary>
		/// <param name="idPair" type="Infragistics.Web.UI.IDPair">ID pair of the column in the collection.</param>
		/// <returns type="Infragistics.Web.UI.GridColumn"></returns>
		var column = null;
		if (idPair.key && idPair.key.length)
			column = this.get_columnFromKey(idPair.key[0]);
		if (!column)
			column = this.get_column(idPair.index);
		return column;
	}

};

$IG.ColumnCollection.registerClass('Infragistics.Web.UI.ColumnCollection', $IG.ObjectCollection);



$IG.GridColumn = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridColumn">
	/// Grid column object.
	/// </summary>

	$IG.GridColumn.initializeBase(this, [adr, element, props, owner, csm]);
	//
	this._key = this._get_clientOnlyValue("key");
	this._visibleIndex = this._get_clientOnlyValue("vIndex");
	this._headerElement = this._findHeaderElement(owner._elements["header"], this._key, this._visibleIndex);
	this._footerElement = this._findHeaderElement(owner._elements["footer"], this._key, this._visibleIndex);
	this._type = this._get_clientOnlyValue("type");
	this._nullable = this._get_clientOnlyValue("nullable");
	
	this._htmlEncode = this._get_clientOnlyValue("htmlEnc");
	this._dataFieldName = this._get_clientOnlyValue("dfn");
	if (this.get_isCheckbox())
	{
		this._isCheck = true;
		if (!this._owner._cellsMouseDownHandler)
		{
			this._owner._cellsMouseDownHandler = Function.createDelegate(this, this._cellsMouseDown);
			owner._addElementEventHandler(owner._elements["container"], "mousedown", this._owner._cellsMouseDownHandler);
		}
		this._checkedUrl = this._get_clientOnlyValue("chkcu");
		this._uncheckedUrl = this._get_clientOnlyValue("chkuu");
		this._partialUrl = this._get_clientOnlyValue("chkpu");
		this._checkedAlt = this._get_clientOnlyValue("chkca");
		this._uncheckedAlt = this._get_clientOnlyValue("chkua");
		this._partialAlt = this._get_clientOnlyValue("chkpa");
		this._defaultTrue = Sys.Serialization.JavaScriptSerializer.deserialize(this._get_clientOnlyValue("chkdt"));
		this._defaultFalse = Sys.Serialization.JavaScriptSerializer.deserialize(this._get_clientOnlyValue("chkdf"));

		var childNodes = this._headerElement != null ? this._headerElement.childNodes : [];
		var childCount = childNodes.length;
		for (var x = 0; x < childCount; ++x)
		{
			var child = childNodes[x];
			if (child.getAttribute && child.getAttribute('chkState') != null)
			{
				this._headerCheckbox = child;
				break;
			}
		}
		if (this._headerCheckbox)
		{
			this._isTri = this._get_clientOnlyValue("tri");
			this._headerCheckboxMouseDownHandler = Function.createDelegate(this, this._headerCheckMouseDown);
			owner._addElementEventHandler(this._headerCheckbox, "mousedown", this._headerCheckboxMouseDownHandler);
		}
	}
}

$IG.GridColumn.prototype =
{
	get_key: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.key">
		/// Gets the key of the column.
		/// </summary>
		/// <value type="String" />
		return this._key;
	},

	get_isTemplated: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.isTemplated">
		/// Gets a boolean value that indicates true if the column is a templated column.  Returns false otherwise.
		/// </summary>
		/// <value type="Boolean" />
		var tmpl = this._get_clientOnlyValue("tmpl");
		return tmpl == "1" ? true : false;
	},

	get_isCheckbox: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.get_isCheckbox">
		/// Gets a boolean value that indicates true if the column is a checkbox column.  Returns false otherwise.
		/// </summary>
		/// <value type="Boolean" />
		var chk = this._get_clientOnlyValue("chk");
		return chk == "1" ? true : false;
	},

	get_type: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.type">
		/// Gets the type of the column. Supported types are: "string", "number", "date", "boolean".
		/// </summary>
		/// <value type="String" />
		return this._type;
	},

	get_nullable: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.nullable">
		/// Indicates whether the column's type is nullable.
		/// </summary>
		/// <value type="Boolean" />
		return this._nullable;
	},

	get_nullText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.nullText">
		/// Returns null text for the column.
		/// </summary>
		/// <value type="String" />
		return "";
	},

	_parentCollection: null,
	get_index: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.index">
		/// Gets the index of the column inside of its container collection.
		/// </summary>
		/// <value type="Number" integer="true"/>
		if (this._parentCollection == null)
			return -1;
		return this._parentCollection.get_indexOf(this);
	},

	get_header: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridColumn.header">Gets reference to the header object.</summary>
		///<value type="Infragistics.Web.UI.GridColumnCaption" />
		if (!this._headerElement)
			return null;

		if (!this["_header"])
			this._header = new $IG.GridColumnCaption(this, "header");

		return this._header;
	},

	get_footer: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridColumn.footer">Gets reference to the footer object.</summary>
		///<value type="Infragistics.Web.UI.GridColumnCaption" />
		if (!this._footerElement)
			return null;

		if (!this["_footer"])
			this._footer = new $IG.GridColumnCaption(this, "footer");

		return this._footer;
	},

	get_headerElement: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.headerElement">
		/// Returns the element assoicated with the column header. 
		/// </summary>
		/// <returns domElement="true"></returns>
		return this._headerElement;
	},

	get_footerElement: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.footerElement">
		/// Returns the element assoicated with the column footer. 
		/// </summary>
		/// <returns domElement="true"></returns>
		return this._footerElement;
	},

	get_headerText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.headerText">
		/// Text of the column header.
		/// </summary>		
		/// <value type="String" />
		return this._get_clientOnlyValue("headTxt");
	},

	get_footerText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.footerText">
		/// Text of the column footer.
		/// </summary>		
		/// <value type="String" />
		return this._get_clientOnlyValue("footTxt");
	},

	get_dataType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.dataType">Data type of the column. Returns an integer value defined in the Infragistics.Web.UI.GridDataType enum.</summary>
		/// <value type="Infragistics.Web.UI.GridDataType" />
		return this._get_clientOnlyValue("type2");
	},

	get_hidden: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.hidden">
		/// Indicates whether the column is hidden from view.
		/// </summary>
		/// <value type="Boolean" />
		var dbHidden = this._get_value($IG.ColumnProps.Hidden, 0);
		return dbHidden == 1; // it's a defaultable boolean on the server
	},

	set_hidden: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.hidden">
		/// Hides/unhides the column from view.
		/// </summary>
		/// <param name="value" type="Boolean">Whether the column should be hidden.</param>
		var oldValue = this.get_hidden();
		if (oldValue == value)
			return;

		var args = { column: this, cancel: false };
		this._owner._gridUtil._fireEvent(this._owner, "HidingColumn", args);
		if (args.cancel)
			return;

		var style = this._get_hiddenStyleSheet();

		style.display = value ? "none" : "";

		this._set_value($IG.ColumnProps.Hidden, value ? 1 : 2); // it's a defaultable boolean on the server

		this._owner._adjustTableWidth();
		if ($util.IsIEStandards)
			this._owner._onDataTblResize({ "clientHeight": this._owner._elements.dataTbl.clientHeight }, null);
		this._owner._onResize({ "clientHeight": this._owner._element.clientHeight }, false);

		args = { column: this };
		this._owner._gridUtil._fireEvent(this._owner, "HideColumn", args);
	},

	_get_hiddenCss: function ()
	{
		return this._get_value($IG.ColumnProps.HiddenCssClass);
	},

	_set_hiddenCss: function (value)
	{
		this._set_value($IG.ColumnProps.HiddenCssClass, value);
	},

	_get_hiddenStyleSheet: function ()
	{
		var css = this._get_hiddenCss();

		if (!css)// To avoid going through all of the cells, the Hidden property should be assigned on the server to generate a css class for it
		{
			css = this._owner.get_id() + "_col" + this.get_index() + "_hidden";
			var lastSS = document.styleSheets[document.styleSheets.length - 1];
			
			if (typeof (lastSS.addRule) != "undefined" && !$util.IsIE9Plus)
				lastSS.addRule("." + css);
			else
				lastSS.insertRule("." + css + "{}", lastSS.length);

			if (this._headerElement)
				this._headerElement.className += (this._headerElement.className ? " " : "") + css;

			var rows = this._owner.get_rows();
			for (var i = 0; i < rows.get_length(); i++)
			{
				var cell = rows.get_row(i).get_cellByColumn(this);
				var elem = cell.get_element();
				if (elem)
					elem.className += (elem.className ? " " : "") + css;
			}

			rows = this._owner._get_auxRows();
			for (var i = 0; i < rows.length; i++)
			{
				var cell = rows[i].get_cellByColumn(this);
				var elem = cell.get_element();
				if (elem)
					elem.className += (elem.className ? " " : "") + css;
			}

			if (this._footerElement)
				this._footerElement.className += (this._headerElement.className ? " " : "") + css;

			var args = { column: this, css: css };
			this._owner._gridUtil._fireEvent(this._owner, "HideColumnCssCreated", args);

			this._set_hiddenCss(css);
		}

		return $util.getStyleSheet(css);
	},

	_findHeaderElement: function (element, key, index)
	{
		if (!element || typeof (element.getAttribute) == "undefined")
			return null;
		var idx = element.getAttribute("idx");
		var hKey = element.getAttribute("key");
		if (hKey)
		{
			var hKeyEsc = unescape(hKey);
			if (hKey != hKeyEsc)
			{
				element.setAttribute("key", hKeyEsc);
				hKey = hKeyEsc;
			}
			if (hKey == key)
				return element;
			return null;
		}
		else if (idx)
		{
			if (idx == index)
				return element;
			return null;
		}
		for (var i = 0; i < element.childNodes.length; i++)
		{
			var hdr = this._findHeaderElement(element.childNodes[i], key, index);
			if (hdr)
				return hdr;
		}
		return null;
	},
	get_idPair: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.idPair">
		/// Gets the ID pair of the column.
		/// </summary>
		/// <value type="Infragistics.Web.UI.IDPair" />
		if (!this._idPair)
			this._idPair = new $IG.IDPair(this.get_index(), this.get_key());
		return this._idPair;
	},
	




	get_width: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.width">
		/// Gets the width of the Column
		/// </summary>
		/// <value type="String" />
		return this._get_value($IG.ColumnProps.Width, "");
	},
	set_width: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.width">
		/// Sets the width of the column.
		/// </summary>
		/// <param name="value" type="String">
		/// Unit based value that the column width should be set to.
		/// </param>
		var oldValue = this.get_width();
		this._set_value($IG.ColumnProps.Width, value);

		var args = { column: this, width: value, cancel: false, delayResize: false };
		this._owner._gridUtil._fireEvent(this._owner, "SetColumnWidth", args);

		if (!args.cancel)
		{
			// need to set it on the header, the footer and on the row object that defines width
			if (this._headerElement)
				this._headerElement.style.width = value;
			if (this._footerElement)
				this._footerElement.style.width = value;
			
			if (this._owner.get_rows().get_length() > 0)
			{
				var sizingRowElem = this._owner.__getResizeRowElement(this._owner.get_rows().get_row(0));
				var sizingRow = new $IG.GridRow(null, sizingRowElem, [], this._owner, null);
				sizingRow.get_cellByColumn(this).get_element().style.width = value;

			}

			



			if (value && (value + "").indexOf("px") != -1)
			{
				var dataTblStyle = this._owner._elements.dataTbl.style;
				var existingTableWidth = dataTblStyle.width;
				if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
				{
					if (oldValue && (oldValue + "").indexOf("px") != -1)
					{
						dataTblStyle.width = (parseInt(existingTableWidth) + parseInt(value) - parseInt(oldValue)) + "px";

						//					this._owner._initHScrBar();
						//					this._owner.alignCaptions();

						




						if (!args.delayResize)
							this._owner._onResize({ "clientHeight": this._owner._element.clientHeight }, false);
					}
				}
				else
				{
					

					if (!args.delayResize)
						this._owner._onResize({ "clientHeight": this._owner._element.clientHeight }, false);
				}
			}
		}
	},
	_get_dataFormatString: function ()
	{
		var format = this._get_clientOnlyValue("cf");
		




		if (!format && this.get_type() == "date")
			format = this._defaultDateFormat;
		return format;
	},
	_formatMethod: null,
	get_formatMethod: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridColumn.formatMethod">
		///Holds a reference to a custom formatting method. The method must accept a single parameter
		///through which the raw value is going to be passed. The return value must be a formatted string.
		///</summary>
		///<value type="Function" />
		return this._formatMethod;
	},
	set_formatMethod: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridColumn.formatMethod">Sets custom formatting method for the column</summary>
		///<param name="value" type="Function">Reference to the custom formatting method.</param>
		this._formatMethod = value;
	},
	_defaultDateFormat: "{0:d}",
	_formatValue: function (value)
	{
		if (value == null && this.get_nullable())
			return this.get_nullText();
		if (this._formatMethod != null)
			return this._formatMethod(value);
		var format = this._get_dataFormatString();
		if (format)
		{
			

			

			

			if (this.get_type() === "date" && value)
			{
				//debugger;
				if (value == null)
					return "";
				if (typeof (value) == "string")
					return String.localeFormat(format, Date.parseLocale(value));
				else if (typeof (value) == "object" && typeof (value.getMonth) != "undefined")
					return String.localeFormat(format, value);
				else
					return String.localeFormat(format, new Date(value));
			}
			else
				return String.localeFormat(format, value);
		}
		
		


		else if (typeof value == 'number')
		{
			
			var num = '' + value, val = String.localeFormat('{0:d}', value);
			if (num == 'NaN')
				return '';
			
			
			if (num == val && val.indexOf('.') > 0) try
			{
				var sep = Sys.CultureInfo.CurrentCulture.numberFormat.NumberDecimalSeparator;
				if (sep && sep.length == 1 && val.indexOf(sep) < 0)
					val = val.replace('.', sep);
			}
			catch (num) { }
			return val;
		}


		

		if (value == null)
			value = "";
		return value.toString();
	},

	get_visibleIndex: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridColumn.visibleIndex">Index of the column in which it appears in the HTML.</summary>
		///<value type="Number" integer="true" />

		return this._visibleIndex;
	},
	_set_visibleIndex: function (value)
	{
		

		this._visibleIndex = value;
		this._headerElement.setAttribute("idx", value);
	},
	_cellsMouseDown: function (evnt)
	{
		var target = evnt.target;
		if (target.tagName != "IMG")
			return;
		var cell = target.parentNode ? this._owner._gridUtil.getCellFromElem(target.parentNode) : null;
		var column = cell ? cell._column : null;
		if (cell && column._editableCheckbox)
		{
			var checkbox = cell._get_ImgCheckbox();
			if (checkbox)
			{
				var checked = parseInt(checkbox.getAttribute("chkState"));
				var newValue = checked != $IG.CheckBoxState.Unchecked ? column._defaultFalse : column._defaultTrue;
				var newCheckedValue = checked != $IG.CheckBoxState.Unchecked ? 0 : 1;
				cell.set_value(newValue, newCheckedValue);
			}
		}
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridColumn.dispose">Disposes of the column object.</summary>

		this._headerElement = null;
		this._footerElement = null;
		this._parentCollection = null;
		if (this._isCheck)
		{
			delete this._checkedUrl;
			delete this._uncheckedUrl;
			delete this._partialUrl;
			delete this._checkedAlt;
			delete this._uncheckedAlt;
			delete this._partialAlt;
			delete this._defaultTrue;
			delete this._defaultFalse;

			if (this._owner_cellsMouseDownHandler)
				this._owner._removeElementEventHandler(this._container, "mousedown", this._owner._cellsMouseDownHandler);

			if (this._headerCheckbox)
			{
				this._owner._removeElementEventHandler(this._headerCheckbox, "mousedown", this._owner._headerCheckMouseDown);
				delete this._headerCheckbox;
				delete this._isTri;
			}
		}
		$IG.GridColumn.callBaseMethod(this, "dispose");
	},

	// unbound checkbox
	get_headerChecked: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.HeaderChecked">
		/// Gets whether the header checkbox is checked or not
		/// </summary>
		/// <value type="Boolean" />
		//return this._get_value($IG.ColumnProps.HeaderChecked, "");
		return this._get_value($IG.ColumnProps.HeaderChecked, "") == $IG.DefaultableBoolean.True;
	},
	set_headerChecked: function (newChecked)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.HeaderChecked">
		/// Sets whether the header checkbox is checked or not
		/// </summary>
		/// <param name="newChecked" type="Boolean">The new checked status of the header</param>
		if (this._editableCheckbox)
		{
			this._toggleCheckbox(newChecked ? "1" : "0");
		}
	},
	get_checkedCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.CheckedCount">
		/// Returns the number of checked rows in this column.
		/// </summary>
		/// <value type="Number" />
		return parseInt(this._get_value($IG.ColumnProps.CheckedCount, ""));
	},
	_set_checkedCount: function (newCount)
	{
		this._set_value($IG.ColumnProps.CheckedCount, newCount);
	},


	get_partialCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumn.PartialCount">
		/// Returns the number of partially checked rows in this column.
		/// </summary>
		/// <value type="Number" />
		return parseInt(this._get_value($IG.ColumnProps.PartialCount, ""));
	},
	_set_partialCount: function (newCount)
	{
		this._set_value($IG.ColumnProps.PartialCount, newCount);
	},

	_get_headerCheckBoxState: function ()
	{
		return this._get_value($IG.ColumnProps.HeaderCheckBoxState, "");
	},
	_set_headerCheckBoxState: function (newCheckState)
	{
		this._set_value($IG.ColumnProps.HeaderCheckBoxState, newCheckState);
	},
	_get_totalRowCount: function ()
	{
		return parseInt(this._get_clientOnlyValue("tr"));
	},
	_headerCheckMouseDown: function (evnt)
	{
		$util.cancelEvent(evnt);

		if (this._editableCheckbox)
		{
			var eventArgs = new $IG.CancelHeaderCheckBoxEventArgs(this, this._get_headerCheckBoxState(), this._get_headerCheckBoxState() == $IG.CheckBoxState.Unchecked ? true : false);
			if (this._owner._clientEvents["HeaderCheckBoxClicking"])
				this._owner._raiseSenderClientEventStart(this._owner, this._owner._clientEvents["HeaderCheckBoxClicking"], eventArgs);
			if (!eventArgs.get_cancel())
			{
				var newState = this._toggleCheckbox(eventArgs.get_nextHeaderChecked() ? "0" : "1");
				var onClient = this._owner._clientEvents["HeaderCheckBoxClicked"] == null || this._owner._clientEvents["HeaderCheckBoxClicked"].postBack == 0;
				if (onClient)
				{
					this._isHeaderClicking = true;
					var rows = this._owner._rows;
					var rowCount = rows.get_length();
					for (var x = 0; x < rowCount; ++x)
					{
						var row = rows.get_row(x);
						var cell = row.get_cellByColumn(this);
						if (cell.get_value() != newState)
							cell._set_value_internal(newState);
					}
					this._isHeaderClicking = null;
					this._set_checkedCount(newState ? this._get_totalRowCount() : 0);
					this._set_partialCount(0);
				}
				eventArgs = new $IG.HeaderCheckBoxEventArgs(this, this._get_headerCheckBoxState());
				if (this._owner._clientEvents["HeaderCheckBoxClicked"])
					this._owner._raiseSenderClientEvent(this._owner, this._owner._clientEvents["HeaderCheckBoxClicked"], eventArgs);
			}
		}
	},
	_toggleCheckbox: function (chkState)
	{
		if (!chkState)
			chkState = this._headerCheckbox.getAttribute('chkState');
		var checked;
		var params = new Object();
		params.prevCheckState = this._get_headerCheckBoxState();
		if (chkState == '1' || chkState == '2')
		{
			this._headerCheckbox.setAttribute('src', this._uncheckedUrl);
			var alt = this._uncheckedAlt.replace("{0}", "false");
			this._headerCheckbox.setAttribute('alt', alt);
			this._headerCheckbox.setAttribute('title', alt);
			this._headerCheckbox.setAttribute('chkState', '0');
			this._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.False);
			this._set_headerCheckBoxState(0);
			checked = "0";
		}
		else
		{
			var alt = this._checkedAlt.replace("{0}", "true");
			this._headerCheckbox.setAttribute('src', this._checkedUrl);
			this._headerCheckbox.setAttribute('alt', alt);
			this._headerCheckbox.setAttribute('title', alt);
			this._headerCheckbox.setAttribute('chkState', '1');
			this._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.True);
			this._set_headerCheckBoxState(1);
			checked = "1";
		}
		params.checked = checked;
		this._owner._actionList.add_transaction(new $IG.GridAction("Check", "grid", this._owner, this._key, params));
		return checked == "1";
	}
}
$IG.GridColumn.registerClass('Infragistics.Web.UI.GridColumn', $IG.UIObject);

$IG.GridColumnCaption = function (column, type)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridColumnCaption">
	/// Grid column caption (header or footer) object.
	/// </summary>
	///<param name="column" type="Infragistics.Web.UI.GridColumn">Column to which the caption belongs.</param>
	///<param name="type" type="String">Type of the caption: "header" or "footer".</param>

	this._column = column;
	this._type = type;
}

$IG.GridColumnCaption.prototype =
{
	get_column: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumnCaption.column">Reference to the owner column.</summary>
		/// <value type="Infragistics.Web.UI.GridColumn" />

		return this._column;
	},
	get_type: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumnCaption.type">Type of the caption: "header" or "footer".</summary>
		/// <value type="String" />

		return this._type;
	},
	get_text: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumnCaption.text">Caption text.</summary>
		/// <value type="String" />

		return this._column["get_" + this._type + "Text"]();
	},
	get_element: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridColumnCaption.element">DOM element of the caption.</summary>
		/// <returns domElement="true"></returns>

		return this._column["get_" + this._type + "Element"]();
	}
}
$IG.GridColumnCaption.registerClass('Infragistics.Web.UI.GridColumnCaption');



$IG.ColumnProps = new function ()
{
	var count = $IG.ObjectBaseProps.Count;
	this.Hidden = [count++, false];
	this.HiddenCssClass = [count++, ""];
	this.Width = [count++, ""];
	this.HeaderCheckBoxState = [count++, $IG.CheckBoxState.Unchecked];
	//this.HeaderChecked = [count++, false];
	this.HeaderChecked = [count++, $IG.DefaultableBoolean.NotSet];
	this.CheckedCount = [count++, 0];
	this.PartialCount = [count++, 0];
	this.Count = count;
};




$IG.GridRowCollection = function (element, props, owner)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridRowCollection">
	/// Row collection object. Contains the grid's rows.
	/// </summary>
	this._rows = [];

	


	// this._keyIndexTree = {};
	this._keyIndexTree = new $IG.HashTree();

	$IG.GridRowCollection.initializeBase(this, [null, element, props, owner, null]);

	//	$addHandler(this.get_element(), "mouseover", Function.createDelegate(this, this._onMouseOver));

	$addHandler(this._owner._element, "mouseover", Function.createDelegate(this, this._onMouseOver));
}

$IG.GridRowCollection.prototype =
{
	initialize: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRowCollection.initialize">
		/// Initializes the collection. The method is called automatically by the framework.
		/// </summary>
		$IG.GridRowCollection.callBaseMethod(this, 'initialize');
	},
	_disposeEachRow: function ()
	{
		for (var rowIndex in this._rows)
		{
			if (!isNaN(parseInt(rowIndex)))
			{
				var row = this._rows[rowIndex];
				if (row)
				{
					row.dispose();
					delete this._rows[rowIndex];
				}
			}
		}
	},
	_disposeOfKeyIndexTree: function ()
	{
		if (this._keyIndexTree && this._keyIndexTree._tree)
		{
			for (var keyIndex in this._keyIndexTree._tree)
			{
				





				var key = this._keyIndexTree._tree[keyIndex];
				if (key)
				{
					delete this._keyIndexTree._tree[keyIndex];
				}
				
			}
		}

	},
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRowCollection.dispose">
		/// Disposes of the collection object. The method is called automatically by the framework.
		/// </summary>
		this._disposeEachRow();

		if (this.get_element())
			$clearHandlers(this.get_element());
		if (this._keyIndexTree)
			this._keyIndexTree.dispose();
		$IG.GridRowCollection.callBaseMethod(this, 'dispose');
	},

	get_grid: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRowCollection.grid">
		/// Returns reference to the grid that owns the collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.WebDataGrid" />
		return this._owner;
	},

	get_length: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRowCollection.length">
		///Returns actual number of rows in the collection
		///regardless of how many were instantiated.
		///</summary>
		/// <value type="Number" integer="true" />
		return this._props[$IG.RowCollectionProps.RowCount];
	},

	_set_length: function (newRowCount)
	{
		this._props[$IG.RowCollectionProps.RowCount] = newRowCount;
	},

	get_row: function (index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRowCollection.row">
		///Returns a row by its index. If the row is not instantiated yet it is being created and returned.
		///</summary>
		///<param name="index" type="Number" integer="true">
		///Index of the row to return.
		///</param>
		/// <returns type="Infragistics.Web.UI.GridRow"></returns>
		if (index < 0 || index >= this.get_length())
			return null;

		var skipKeyIndexing = arguments[1];

		var returnRow = this._rows[index];
		if (!returnRow)
		{
			// get the row element by index
			// for hierarchical implementation wil have to override this method and use index*2 to account for the hidden TRs
			returnRow = this._rows[index] = this._create_item(index);
		}
		







		if (!skipKeyIndexing)
		{
			if (returnRow)
			{
				if (!returnRow._get_isKeyIndexed())
				{
					this._keyIndexTree.add(returnRow);
					returnRow._set_isKeyIndexed(true);
				}
			}
		}

		return returnRow;
	},

	get_rowFromKey: function (dataKey)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRowCollection.rowFromKey">
		///Returns a row by its data key. If the row is not instantiated yet it is being created and returned.
		///</summary>
		///<param name="dataKey" type="Array">
		///Data key of the row to return. The data key is expected to be provided as an array, 
		///in the case of a single data key field it should be an array with a single item.
		///</param>
		/// <returns type="Infragistics.Web.UI.GridRow"></returns>

		if (!dataKey || !dataKey.length)
			return null;

		



		var row = this._keyIndexTree.findByKey(dataKey);
		
		if (row)
			return row;

		for (var i = 0; i < this.get_length(); i++)
		{
			row = this.get_row(i);
			if (row && row.isDataKeyEqual(dataKey))
				return row;
		}
		return null;
	},

	get_rowFromIDPair: function (idPair)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRowCollection.rowFromIDPair">
		///Returns a row by its ID pair. If the row is not instantiated yet it is being created and returned.
		///</summary>
		///<param name="idPair" type="Infragistics.Web.UI.IDPair">
		///ID pair of the row to return. The ID pair is an object of type Infragistics.Web.UI.IDPair.
		///</param>
		///<remarks>
		///The method attempts to find the row by the data key provided in the ID pair.
		///If the attempt fails the row is sought and returned by its index.
		///</remarks>
		/// <returns type="Infragistics.Web.UI.GridRow"></returns>

		if (idPair.index < 0)
			return null;

		var row = null;
		if (idPair.key !== null)
		{
			row = this.get_rowFromKey(idPair.key);
			return row;
		}
		row = this.get_row(idPair.index);
		if (!row)
			row = this._owner._rows._rows[idPair.index];
		return row;
	},

	get_cellFromIDPair: function (idPair)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRowCollection.cellFromIDPair">
		///Returns a cell by its ID pair. If the cell is not instantiated yet it is being created and returned.
		///</summary>
		///<param name="idPair" type="Infragistics.Web.UI.CellIDPair">
		///ID pair of the cell to return. The ID pair is an object of type Infragistics.Web.UI.CellIDPair which 
		///contains two ID pairs of the cell's row and column.
		///</param>
		///<remarks>
		///The method attempts to find the row and column by their ID pairs and return the cell on the crosshair if successful.
		///</remarks>
		/// <returns type="Infragistics.Web.UI.GridCell"></returns>
		var cell = null;
		var row = this.get_rowFromIDPair(idPair.rowIDPair);
		if (row)
		{
			var column = this.get_grid().get_columns().get_columnFromIDPair(idPair.columnIDPair);
			if (column)
				cell = row.get_cellByColumn(column);
		}
		return cell;
	},

	



















	_compareDataKeys: function (key1, key2)
	{
		if (!key1 || !key2 || key1.length == undefined || key2.length == undefined || key1.length != key2.length)
			throw "Incorrect keys: " + key1.toString() + " " + key2.toString();

		for (var i = 0; i < key1.length; i++)
		{
			if (key1[i] < key2[i])
				return -i - 1;
			if (key1[i] > key2[i])
				return i + 1;
		}

		return 0;
	},

	_resolveIndexedKey: function (dataKey, indexTree)
	{
		if (indexTree.dataKey == undefined)
			return null;

		if (this._compareDataKeys(indexTree.dataKey, dataKey) == 0)
			return indexTree.row;

		var row = this._resolveIndexedKey(dataKey, indexTree.left);
		if (!row)
			row = this._resolveIndexedKey(dataKey, indexTree.right);
		return row;
	},

	_create_item: function (index)
	{
		
		var rows = $util.getRows(this.get_element());
		if (!rows)
			rows = $util.getRows(this._owner._elements.dataTbl);
		var rowElem = rows ? rows[index] : null;
		if (!rowElem)
			return null;

		var row = new $IG.GridRow(index, rowElem, [], this.get_grid(), null);

		//this._indexRow(row, this._keyIndexTree);
		// RowSelector behavior needs this to tag the row selector elements when the row is created
		this._owner._gridUtil._fireEvent(this, "RowCreated", row);
		return row;
	},

	_onMouseOver: function (e)
	{
		var target = e.target;

		// Make sure that the element that we're over is actually a Grid Cell
		target = this._owner._gridUtil._getGridCellFromElement(target);

		// Marke the Cell as a Grid Cell so that behaviors have a way to determine a cell via the UI.	
		if (target && (target.tagName == "TD" || target.tagName == "TH")) //TH for row selectors
		{
			var row = target.parentNode;
			this._onMouseOverCell(target, row);
		}
	},
	_onMouseOverCell: function (target, row)
	{
		var adr = row.getAttribute("adr");
		if (adr === null && row.id.indexOf("adr") >= 0)
		{
			$util._initAttr(row);
			adr = row.getAttribute("adr");
		}
		if (adr !== null && row.getAttribute("type") == null)
		{
			var index = parseInt(adr, 10);
			if (!this._rows[index])
				this._rows[index] = this._create_item(row.rowIndex);
		}

		if (!target.getAttribute("adr") && target.tagName == "TD")
		{
			var idx = this._owner._gridUtil.getCellIndexFromElem(target);
			if (idx < 0) 
				return;
			target.setAttribute("idx", idx);
			target.setAttribute("adr", this._owner._gridUtil._getColumnAdrFromVisibleIndex(idx));
			target.setAttribute("type", "cell");
		}
	},
	addRowCreatedEventHandler: function (handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRowCollection.addRowCreatedEventHandler">
		/// Adds a listener to the RowCreated internal event.
		/// </summary>
		/// <param name="handler" type="Function">Method to attach to the event listener.</param>

		this._owner._gridUtil._registerEventListener(this, "RowCreated", handler);
	},

	add: function (cellValues)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRowCollection.add">
		/// Creates and adds a row to the collection.
		/// </summary>
		/// <param name="cellValues" type="Array">
		/// Array of the new row values, i.e. ["ALFKI", "John", 30]. Or a JSON-notation object with { column-key : cell-value } pairs; example: { "ID": "ALFKI", "FirstName": "John", "Age": 30 }.
		/// </param>

		var editing = this.get_grid().get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);
		if (!editing)
			alert("The Editing behavior must be present for the 'add' method to function.");
		this.get_grid()._gridUtil._fireEvent(this.get_grid(), "RowAdded", { "cellValues": cellValues });
	},

	remove: function (row)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRowCollection.remove">
		/// Removes a row from the collection.
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">
		/// Row to remove from the collection.
		/// </param>

		var noncommitting = arguments[1];

		var editing = this.get_grid().get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);
		if (!editing)
			alert("The Editing behavior must be present for the 'remove' method to function.");
		this.get_grid()._gridUtil._fireEvent(this.get_grid(), "RowsDeleted", { "row": row, "commit": (noncommitting ? false : true) });
	}
}

$IG.GridRowCollection.registerClass('Infragistics.Web.UI.GridRowCollection', $IG.UIObject);





$IG.RowCollectionProps = new function ()
{
	this.RowCount = 0;
	this.Count = 1;
};




$IG.GridRow = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridRow">
	/// Grid row object.
	/// </summary>
	this._index = parseInt(adr);
	this._cells = [];
	$util._initAttr(element);
	element.setAttribute("type", "row");
	$IG.GridRow.initializeBase(this, [adr, element, props, owner, csm]);
	this._isKeyIndexed = false;
}

$IG.GridRow.prototype =
{
	initialize: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRow.initialize">
		/// Initializes the row. The method is called automatically by the framework.
		/// </summary>
		$IG.GridRow.callBaseMethod(this, 'initialize');
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridRow.dispose">
		/// Final clean up method. The method is called automatically by the framework.
		/// </summary>
		var ele = this.get_element();
		if (ele) $clearHandlers(ele);
		for (var cell in this._cells)
		{
			if (!isNaN(parseInt(cell)))
			{
				if (this._cells[cell])
					this._cells[cell].dispose();
				this._cells[cell] = null;
			}
		}
		$IG.GridRow.callBaseMethod(this, 'dispose');
	},

	get_grid: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.grid">
		/// Returns reference to the grid that owns the row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.WebDataGrid" />

		return this._owner;
	},

	get_cell: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.cell">
		/// Returns a cell by its index.
		/// </summary>
		/// <param name="index" type="Number" integer="true">
		/// Index of the cell in the row.
		/// </param>
		/// <value type="Infragistics.Web.UI.GridCell" />

		if (index < 0 || index >= this.get_cellCount())
			throw "CellCollection: Out of bounds exception.";

		if (!this._cells[index])
		{
			var adr = index;
			index = this.get_grid().get_columns().get_column(adr).get_visibleIndex();
			this._cells[adr] = this._create_item(adr, index);
			index = adr;
		}

		return this._cells[index];
	},

	get_cellByColumnKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.cellByColumnKey">
		/// Returns a cell by its column key.
		/// </summary>
		/// <param name="columnKey" type="String">
		/// Key of the column the cell belongs to. If a invalid key is passed null will be returned.
		/// </param>
		/// <value type="Infragistics.Web.UI.GridCell" />

		var column = this.get_grid().get_columns().get_columnFromKey(columnKey);
		if (column)
			return this.get_cell(column.get_index());
		return null;
	},

	get_cellByColumn: function (column)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.cellByColumn">
		/// Returns a cell by its column.
		/// </summary>
		/// <param name="column" type="Infragistics.Web.UI.GridColumn">
		/// Column the cell belongs to.
		/// </param>
		/// <value type="Infragistics.Web.UI.GridCell" />

		return this.get_cell(column.get_index());
	},

	_get_cellElementByIndex: function (rowElement, index)
	{
		var args = { rowElement: rowElement, index: index, cellElement: null, cancel: false };
		this._owner._gridUtil._fireEvent(this._owner, "GetCellElementByIndex", args);

		if (!args.cancel)
			return rowElement.childNodes[index];
		else
			return args.cellElement;
	},

	_create_item: function (adr, index)
	{
		var cellIndex = parseInt(index) + this._owner._get_cellIndexOffset();

		var cell = new $IG.GridCell(this, adr, this._get_cellElementByIndex(this.get_element(), cellIndex), [], this.get_grid(), null);
		cell._column = this._owner._columns._getObjectByIndex(adr);
		return cell;
	},

	get_cellCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.cellCount">
		/// Returns number of cells in the row.
		/// </summary>
		/// <value type="Number" integer="true" />

		return this.get_grid().get_columns().get_length();

		




	},

	get_index: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.index">
		/// Returns index of the row inside of its container collection.
		/// </summary>
		/// <value type="Number" integer="true" />

		return this._index;
	},
	__colon: ":",
	__colonSubs: "~$~",
	get_dataKey: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.dataKey">
		/// Returns data key of the row. It is always an array of objects even in a case of a single data key field.
		/// </summary>
		/// <value type="Array" />		
		var commentNode = this._element.nextSibling;
		var dataKey = commentNode && commentNode.nodeName == "#comment" ? commentNode.nodeValue : null;
		if (dataKey)
		{
		    
		    if (this._owner.get_enableClientRendering())
				dataKey = eval(dataKey)
			else
			    dataKey = Sys.Serialization.JavaScriptSerializer.deserialize($util.replace(dataKey, this.__colonSubs, this.__colon));
			
			var dateIndeces = this._owner._get_dateDataKeyIndeces();
			if (dateIndeces && dataKey != null)
			{
				for (var x = 0; x < dataKey.length; ++x)
				{
					if (dateIndeces.indexOf(x + ',') > -1)
						dataKey[x] = this._owner._gridUtil._convertServerDateStringToClientObject(dataKey[x]);
				}
			}
			

			return dataKey;
		}
		return [];
	},
	_get_internalDataKey: function()
	{
		var commentNode = this._element.nextSibling;
		var dataKey = commentNode && commentNode.nodeName == "#comment" ? commentNode.nodeValue : null;
		if (dataKey)
		{
			if (this._owner.get_enableClientRendering())
				dataKey = eval(dataKey);
			else
			    dataKey = Sys.Serialization.JavaScriptSerializer.deserialize($util.replace(dataKey, this.__colonSubs, this.__colon));
			return dataKey;
		}
		return [];
	},
	isDataKeyEqual: function (dataKey)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridRow.isDataKeyEqual">
		///Compares provided data key with the row's data key and returns a 
		///boolean value indicating whether these are equal.
		///</summary>
		///<param name="dataKey" type="Array">
		///A data key to compare with the row's one.
		///</param>
		///<returns type="Boolean">
		///Boolean value indicating whether the passed in data key is equal to the row's one.
		///</returns>

		var rowDataKey = this.get_dataKey();
		if (rowDataKey && dataKey && rowDataKey.length == dataKey.length)
		{
			for (var i = 0; i < dataKey.length; i++)
			{
			    
			    if (rowDataKey[i].valueOf && dataKey[i].valueOf && rowDataKey[i].valueOf() != dataKey[i].valueOf())
			        return false;
			    else if ((!rowDataKey[i].valueOf || !dataKey[i].valueOf) && rowDataKey[i] != dataKey[i])
			        return false;
			}
			return true;
		}
		return false;
	},
	get_idPair: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridRow.idPair">
		/// Gets the ID pair of the row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.IDPair" />

		if (!this._idPair)
			this._idPair = new $IG.IDPair(this.get_index(), this._get_internalDataKey());
		return this._idPair;
	},
	get_tag: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridRow.tag">
		///Returns the Tag property value that is set on the server.
		///</summary>
		///<value type="String"></value>

		if (this._element.getAttribute("tag"))
			return Sys.Serialization.JavaScriptSerializer.deserialize(this._element.getAttribute("tag").replace(this.__colonSubs, this.__colon));
		return null;
	},
	_get_isKeyIndexed: function ()
	{
		return this._isKeyIndexed;
	},
	_set_isKeyIndexed: function (value)
	{
		this._isKeyIndexed = value;
	}
}

$IG.GridRow.registerClass('Infragistics.Web.UI.GridRow', $IG.UIObject);





$IG.GridCell = function (row, adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridCell">
	/// Grid cell object.
	/// </summary>
	this._row = row;
	$IG.GridCell.initializeBase(this, [adr, element, props, owner, csm]);

	if (!element.getAttribute("wlkd"))
	{
		$util._initAttr(element);
		element.setAttribute("adr", adr);
		element.setAttribute("idx", owner._gridUtil.getCellIndexFromElem(element));
		element.setAttribute("type", "cell");
		element.setAttribute("wlkd", "1");
	}

}

$IG.GridCell.prototype =
{
	initialize: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridCell.initialize">
		/// The method is called during initialization of the cell. Contains initializing code for the cell.
		/// </summary>
		$IG.GridCell.callBaseMethod(this, 'initialize');
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridCell.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		var ele = this.get_element();
		if (ele)
			$clearHandlers(ele);
		delete this._row;
		delete this._checkBox;
		delete this._column;
		$IG.GridCell.callBaseMethod(this, 'dispose');
	},

	get_grid: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridCell.grid">
		/// Gets reference to the grid object that contains the cell.
		/// </summary>
		/// <value type="Infragistics.Web.UI.WebDataGrid" />

		return this._owner;
	},
	get_row: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridCell.row">
		/// Gets reference to the row object that contains the cell.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow" />

		return this._row;
	},
	get_column: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridCell.column">
		/// Gets reference to the column object that contains the cell.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridColumn" />

		return this._column;
	},

	get_index: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridCell.index">
		/// Gets index of the cell inside of its collection.
		/// </summary>
		/// <value type="Number" />

		if (!this.get_column())
			return -1;
		return this.get_column().get_idPair().index;
	},
	get_idPair: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridCell.idPair">
		/// Gets ID pair of the cell.
		/// </summary>
		/// <value type="Infragistics.Web.UI.CellIDPair" />

		if (!this._idPair)
			this._idPair = new $IG.CellIDPair(this.get_row().get_idPair(), this.get_column().get_idPair());
		return this._idPair;
	},
	get_value: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridCell.value">
		///Gets the cell's value.  Can be a Date object, string, number or boolean, depending upon the column's data type.
		///</summary>		

		var value = this._element.getAttribute("val");
		if (value)
		{
			
			var dateValue = Sys.Serialization.JavaScriptSerializer.deserialize(value.replace(/\%3A/g, ":"));

			if (this.get_column().get_type() == "date")			
				dateValue = this.get_grid()._gridUtil._convertServerDateStringToClientObject(dateValue);						

			return dateValue;
		}
		var origValue = this.get_text();
		var column = this.get_column();

		if (column.get_nullable() && origValue == column.get_nullText())
			return null;

		if (column.get_type() == "number")
		{
			
			value = this._parseNumberValue();
			if (isNaN(value) || !value)
				value = 0;
		}
		else if (column.get_type() == "boolean")
		{
			if (origValue.length > 0)
				value = (origValue.toString().toLowerCase() == "true");
			else
				value = origValue;
		}
		else
			value = origValue;
		return value;
	},
	_parseNumberValue: function ()
	{
		
		var origValue = this._element.getAttribute('val') ? this._element.getAttribute('val') : this.get_text();
		
		


		var value = Number.parseLocale(origValue);
		if (isNaN(value))
			value = parseFloat(origValue);
		if (isNaN(value))
			value = NaN;
		return value;
	},
	set_value: function (value, text)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridCell.value">
		///Sets the cell's value and text/checkstate.
		///</summary>
		///<param name="value">
		///Value of the cell to set.
		///</param>
		///<param name="text" type="String" optional="true">
		///Optional. If the cell's text differs from its value this parameter should contain the
		///text to render in the cell element.
		///For a checkbox column, the text parameter stands for the new checkbox state.
		/// $IG.CheckBoxState.Unchecked (0)-Unchecked, $IG.CheckBoxState.Checked (1)-Checked,
		/// $IG.CheckBoxState.Partial (2)-Partial
		///</param>

		var oldValue = this.get_value();
		
		if (oldValue === value)
			return;
		var args = { "cell": this, "oldValue": oldValue, "newValue": value, "cancel": false };
		this.get_grid()._gridUtil._fireEvent(this.get_grid(), "CellValueChanging", args);
		if (!args.cancel)
		{
			this._set_value_internal(args.newValue, text);

			if (!this.__overrideCellUpdate)
				this.get_grid()._gridUtil._fireEvent(this.get_grid(), "CellValueChanged", { "cell": this, "oldValue": oldValue });
		}
	},

	_set_value_internal: function (value, text)
	{
		value = this.__parseValue(value);
		var val = this._element.getAttribute("val");
		var oldval = val == null ? null : Sys.Serialization.JavaScriptSerializer.deserialize(val);
		if (val !== null || this.get_column()._formatMethod != null || this.get_column()._get_dataFormatString() || typeof (text) != "undefined")
		{
			val = Sys.Serialization.JavaScriptSerializer.serialize(value);
			if (this.get_column().get_type() == "date")
			{
				val = this.get_grid()._gridUtil._convertClientDateToServerString(value);
				val = Sys.Serialization.JavaScriptSerializer.serialize(val);				
			}
			this._element.setAttribute("val", val.replace(/\:/g, "%3A"));
		}
		if (typeof (text) == "undefined")
		{
			if (this._column._isCheck && this._column.get_type() == "boolean")
				text = value == null ? $IG.CheckBoxState.Partial : (value == true ? $IG.CheckBoxState.Checked : $IG.CheckBoxState.Unchecked);
			else
				text = this.get_column()._formatValue(value);
		}
		if (!this._column._isCheck || this.__setText)
			this.set_text(text);
		else
		{
			this._setCheckState(text);
			var column = this._column;
			if (column._headerCheckbox && this.get_row()._address != -1 && !column._isHeaderClicking && column.get_type() == "boolean" && oldval !== value)
			{
				var headerCheckbox = column._headerCheckbox;
				if (oldval == null)
					column._set_partialCount(column.get_partialCount() - 1);
				else if (value == null)
					column._set_partialCount(column.get_partialCount() + 1);
				if (oldval == 1)
					column._set_checkedCount(column.get_checkedCount() - 1);
				else if (value == 1)
					column._set_checkedCount(column.get_checkedCount() + 1);
				var checkCnt = column.get_checkedCount();
				var partialCnt = column.get_partialCount();
				if (checkCnt == column._get_totalRowCount())
				{
					headerCheckbox.setAttribute('src', column._checkedUrl);
					var alt = column._checkedAlt.replace("{0}", "true");
					headerCheckbox.setAttribute("alt", alt);
					headerCheckbox.setAttribute("title", alt);
					headerCheckbox.setAttribute('chkState', '1');
					column._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.Checked);
					column._set_value($IG.ColumnProps.HeaderCheckBoxState, $IG.CheckBoxState.Checked);
				}
				else if (checkCnt + partialCnt == 0)
				{
					headerCheckbox.setAttribute('src', column._uncheckedUrl);
					var alt = column._uncheckedAlt.replace("{0}", "false");
					headerCheckbox.setAttribute("alt", alt);
					headerCheckbox.setAttribute("title", alt);
					headerCheckbox.setAttribute('chkState', '0');
					column._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.Unchecked);
					column._set_value($IG.ColumnProps.HeaderCheckBoxState, $IG.CheckBoxState.Unchecked);
				}
				else if (column._isTri)
				{
					headerCheckbox.setAttribute('src', column._partialUrl);
					var alt = column._partialAlt.replace("{0}", "null");
					headerCheckbox.setAttribute("alt", alt);
					headerCheckbox.setAttribute("title", alt);
					headerCheckbox.setAttribute('chkState', '2');
					column._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.NotSet);
					column._set_value($IG.ColumnProps.HeaderCheckBoxState, $IG.CheckBoxState.Partial);
				}
				else
				{
					headerCheckbox.setAttribute('src', column._uncheckedUrl);
					var alt = column._uncheckedAlt.replace("{0}", "false");
					headerCheckbox.setAttribute("alt", alt);
					headerCheckbox.setAttribute("title", alt);
					headerCheckbox.setAttribute('chkState', '0');
					column._set_value($IG.ColumnProps.HeaderChecked, $IG.DefaultableBoolean.NotSet);
					column._set_value($IG.ColumnProps.HeaderCheckBoxState, $IG.CheckBoxState.Unchecked);
				}
			}
		}
	},

	__parseValue: function (value)
	{
		var column = this.get_column();
		if (column.get_nullable() && (column.get_nullText() === value || value === null))
			return null;
		switch (column.get_type())
		{
			case "number":
				if (typeof (value) != "number")
				{
					
					


					
					var val = value ? Number.parseLocale(value) : 0;
					if (isNaN(val))
						val = parseFloat(value);
					if (isNaN(value = val))
						value = 0;
				}
				break;
			case "boolean":
				if (typeof (value) != "boolean")
				{
					if (value && value.toString().toLowerCase() == "true")
						value = true;
					else
						value = false;
				}
				break;
			case "date":
				
				if (typeof (value) != "object" || (value != null && typeof (value.getMonth) == "undefined"))
					value = Date.parseLocale(value);
				break;
		}
		return value;
	},

	__set_overrideCellUpdate: function (val)
	{
		this.__overrideCellUpdate = val;
	},

	__get_alwaysSetText: function ()
	{
		return this.__setText;
	},
	__set_alwaysSetText: function (val)
	{
		this.__setText = val;
	},

	get_text: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridCell.text">
		///Gets the cell's text.
		///</summary>
		/// <value type="String" />

		


		if ($util.IsIE && this._element.childNodes && this._element.childNodes.length == 1
		    && this._element.childNodes[0].nodeName == "#comment")
			return "";


		
		
		var txt = $util.replace(this._element.innerHTML, "<BR>", "<br>").split("<br>").join("\r\n");
		if (this.get_column()._htmlEncode)
		{
			
			txt = $util.htmlUnescapeCharacters(txt);
		}
		return txt;
	},
	set_text: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridCell.text">
		///Sets the cell's text.
		///</summary>
		/// <param name="value" type="String">Text to set.</param>
		
		if (this.get_column()._htmlEncode)
		{
			
			value = $util.htmlEscapeCharacters(value);
		}
		this._element.innerHTML = value.split("\n").join("<BR>");

		this.get_grid()._gridUtil._fireEvent(this.get_grid(), "CellContentChanged", { "cell": this });
	},
	scrollToView: function (direction)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridCell.scrollToView">
		///Scrolls the cell into view inside of the grid's internal container element.
		///</summary>
		///<param name="direction" type="Number" optional="true">
		///Indicates which direction to scroll the grid. 1 - only horizontally, 2 - only vertically, 0 or no parameter - both.
		///</param>
		if (typeof direction == "undefined" || direction < 0 || direction > 2) direction = 0;
		var grid = this.get_grid();
		var elem = this.get_element();
		var cellPos = $util.getPosition(elem);
		
		var cellRect = { x: (cellPos.x - cellPos.scrollX + cellPos.xDivS), y: (cellPos.y - cellPos.scrollY + cellPos.yDivS), width: elem.offsetWidth, height: elem.offsetHeight };
		var cntrPos = $util.getPosition(grid._container);
		var cntrRect = { x: (cntrPos.x - cntrPos.scrollX), y: (cntrPos.y - cntrPos.scrollY), width: grid._container.offsetWidth, height: grid._container.offsetHeight };
		var xAdjusted = false;
		var yAdjusted = false;
		if (cellRect.x < cntrRect.x && (!direction || direction == 1))
		{
			grid._container.scrollLeft -= (cntrRect.x - cellRect.x);
			xAdjusted = true;
		}
		if (cellRect.y < cntrRect.y && (!direction || direction == 2))
		{
			grid._container.scrollTop -= (cntrRect.y - cellRect.y);
			yAdjusted = true;
		}
		if (!xAdjusted && cellRect.x + cellRect.width > cntrRect.x + cntrRect.width + 1 && (!direction || direction == 1))
		{
			if (cellRect.width < grid._container.offsetWidth)
				grid._container.scrollLeft += (cellRect.x + cellRect.width - (cntrRect.x + cntrRect.width));
			else
				grid._container.scrollLeft += (cellRect.x + cntrRect.x);
		}
		if (!yAdjusted && cellRect.y + cellRect.height > cntrRect.y + cntrRect.height && (!direction || direction == 2))
		{
			if (cellRect.height < grid._container.offsetHeight)
				grid._container.scrollTop += (cellRect.y + cellRect.height - (cntrRect.y + cntrRect.height));
			else
				grid._container.scrollTop += (cellRect.y + cntrRect.y);
		}
	},
	_get_ImgCheckbox: function ()
	{
		if (this._checkBox == null)
		{
			var children = this._element.childNodes;
			var childCount = children.length;
			for (var x = 0; x < childCount; ++x)
			{
				var child = children[x];
				$util._initAttr(child);
				if (child.getAttribute && child.getAttribute("chkState"))
				{
					this._checkBox = child;
					break;
				}
			}
		}
		return this._checkBox;
	},
	_getCheckState: function ()
	{
		return parseInt(this._get_ImgCheckbox().getAttribute("chkState"));
	},
	_setCheckState: function (state)
	{
		var checkbox = this._get_ImgCheckbox();
		if (checkbox)
		{
			var column = this._column;
			if (state == $IG.CheckBoxState.Unchecked)
			{
				checkbox.setAttribute("chkState", "0");
				var alt = column._uncheckedAlt.replace("{0}", this.get_value());
				checkbox.setAttribute("src", column._uncheckedUrl);
				checkbox.setAttribute("alt", alt);
				checkbox.setAttribute("title", alt);
			}
			else if (state == $IG.CheckBoxState.Checked)
			{
				checkbox.setAttribute("chkState", "1");
				checkbox.setAttribute("src", column._checkedUrl);
				var alt = column._checkedAlt.replace("{0}", this.get_value());
				checkbox.setAttribute("alt", alt);
				checkbox.setAttribute("title", alt);
			}
			else
			{
				checkbox.setAttribute("chkState", "2");
				checkbox.setAttribute("src", column._partialUrl);
				var value = this.get_value();
				var alt = column._partialAlt.replace("{0}", value == null ? "null" : value);
				checkbox.setAttribute("alt", alt);
				checkbox.setAttribute("title", alt);
			}
		}
	}
}

$IG.GridCell.registerClass('Infragistics.Web.UI.GridCell', Infragistics.Web.UI.UIObject);




$IG.CellIDPair = function (rowIDPair, columnIDPair)
{
	///<summary locid="T:J#Infragistics.Web.UI.CellIDPair">Uniquely identifies a cell in the grid</summary>
	///<field name="rowIDPair" type="Infragistics.Web.UI.IDPair">IDPair of the cell's row.</field>
	///<field name="columnIDPair" type="Infragistics.Web.UI.IDPair">IDPair of the cell's column.</field>

	this.rowIDPair = rowIDPair;
	this.columnIDPair = columnIDPair;
};

$IG.CellIDPair.prototype =
{
	rowIDPair: null,
	columnIDPair: null
}

// $IG.CellIDPair.registerClass('Infragistics.Web.UI.CellIDPair');




$IG.GridAJAXResponseEventArgs = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.AJAXResponseEventArgs">
	/// Event arguments object that is passed into the AJAXResponse event handler.
	/// </summary>
	$IG.GridAJAXResponseEventArgs.initializeBase(this);
}
$IG.GridAJAXResponseEventArgs.prototype =
{
	get_browserResponseObject: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.AJAXResponseEventArgs.browserResponseObject">
		/// Returns the browser's response object.
		/// </summary>
		/// <value type="XMLHttpRequest" />
		return this._props[0];
	},
	get_gridResponseObject: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.AJAXResponseEventArgs.gridResponseObject">
		/// Returns the grid's response object. The objects properties are set on the server.
		/// </summary>
		/// <value type="Infragistics.WebUI.CustomAJAXResponse" />
		return this._props[1];
	},
	get_customResponseObject: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.AJAXResponseEventArgs.customResponseObject">
		/// Returns the grid's response object. The objects properties are set on the server.
		/// </summary>
		/// <value type="Infragistics.WebUI.CustomAJAXResponse" />
		return this._props[1];
	},
	get_cancel: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.AJAXResponseEventArgs.cancel">
		/// This method is here to keep the event argument signature for the grid's
		/// AJAXResponse event consistent. This method does not do anything and should not be used.
		/// </summary>		
	},
	set_cancel: function (val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.AJAXResponseEventArgs.cancel">
		/// This method is here to keep the event argument signature for the grid's
		/// AJAXResponse event consistent. This method does not do anything and should not be used.
		/// </summary>
		/// <param name="val" type="Boolean"></param>		
	}
}
$IG.GridAJAXResponseEventArgs.registerClass('Infragistics.Web.UI.GridAJAXResponseEventArgs', $IG.EventArgs);

$IG.BrowserEventArgs = function (event)
{
	/// <summary locid="T:J#Infragistics.Web.UI.BrowserEventArgs">
	/// Event arguments object that is passed into the browser event handler when an event occurs.
	/// This event is cancelable and if it is canceled,
	/// the event will not be processed by the grid. 
	/// </summary>
	$IG.BrowserEventArgs.initializeBase(this);
	this._props[0] = event;
}
$IG.BrowserEventArgs.prototype =
{

}

$IG.BrowserEventArgs.registerClass('Infragistics.Web.UI.BrowserEventArgs', $IG.CancelEventArgs);


$IG.ItemEventArgs = function (event, grid)
{

	/// <summary locid="T:J#Infragistics.Web.UI.ItemEventArgs">

	/// Event arguments object that is passed into the browser event handler when an event occurs.

	/// Also if a grid's object such as cell, header, footer is availale, a reference to it is provided through

	/// the event arguments.

	/// This event is cancelable and if it is canceled,

	/// the event will not be processed by the grid. 

	/// </summary>

	$IG.ItemEventArgs.initializeBase(this, [event]);

	this._props[1] = null;

	this._props[2] = null;

	this._grid = grid;

}

$IG.ItemEventArgs.prototype =
{

	__createItemType: function ()
	{

		var event = this._props[0];

		var type = "cell";

		var item = this._grid._gridUtil.getCellFromElem(event.target);

		if (!item)
		{

			item = this._grid._gridUtil.getRowFromCellElem(event.target);

			type = "row";

		}

		if (!item)
		{

			item = this._grid._gridUtil.getHeaderFromElem(event.target);

			type = "header";

		}

		if (!item)
		{

			item = this._grid._gridUtil.getFooterFromElem(event.target);

			type = "footer";

		}

		if (!item)

			type = "";

		this._props[1] = item;

		this._props[2] = type;

	},


	get_item: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.ItemEventArgs.item">

		/// Reference to the object that is associated with the event.

		/// </summary>

		if (this._props[2] == null)

			this.__createItemType();

		return this._props[1];

	},

	get_type: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.ItemEventArgs.type">

		/// Type of the object that is associated with the event, for example: "cell", "column" etc.

		/// </summary>

		/// <value type="String" />

		if (this._props[2] == null)

			this.__createItemType();

		return this._props[2];

	}

}


$IG.ItemEventArgs.registerClass('Infragistics.Web.UI.ItemEventArgs', $IG.BrowserEventArgs);


$IG.RowEventArgs = function (row)
{

	/// <summary locid="T:J#Infragistics.Web.UI.RowEventArgs">

	/// Event arguments object that is passed into an event handler that is related to a row.

	/// </summary>

	$IG.RowEventArgs.initializeBase(this);

	this._props[0] = row;

}

$IG.RowEventArgs.prototype =
{

	get_row: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.RowEventArgs.row">

		/// Reference to the row object associated with the event.

		/// </summary>

		/// <value type="Infragistics.Web.UI.GridRow" />

		return this._props[0];

	}

}

$IG.RowEventArgs.registerClass('Infragistics.Web.UI.RowEventArgs', $IG.EventArgs);


$IG.CancelRowEventArgs = function (row, context)
{

	/// <summary locid="T:J#Infragistics.Web.UI.CancelRowEventArgs">

	/// Event arguments object that is passed into an event handler that is related to a row.

	/// This event is cancelable. 

	/// </summary>

	$IG.CancelRowEventArgs.initializeBase(this);

	this._props[0] = row;

	this._context = context;

}

$IG.CancelRowEventArgs.prototype =
{

	get_row: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelRowEventArgs.row">

		/// Reference to the row object associated with the event.

		/// </summary>

		/// <value type="Infragistics.Web.UI.GridRow" />

		return this._props[0];

	}

}

$IG.CancelRowEventArgs.registerClass('Infragistics.Web.UI.CancelRowEventArgs', $IG.CancelEventArgs);


$IG.CancelHeaderCheckBoxEventArgs = function (column, currentState, newChecked)
{

	/// <summary locid="T:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs">

	/// Event arguments object that is passed into an event handler for header checkbox clicking

	/// This event is cancelable. 

	/// </summary>

	$IG.CancelHeaderCheckBoxEventArgs.initializeBase(this);

	this._column = column;

	this._currentState = currentState;

	this._newChecked = newChecked;


}

$IG.CancelHeaderCheckBoxEventArgs.prototype =
{

	get_column: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs.column">

		/// Reference to the column object associated with the event.

		/// </summary>

		/// <value type="Infragistics.Web.UI.GridColumn" />

		return this._column;

	},

	get_currentCheckBoxState: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs.currentCheckBoxState">

		/// Returns the current state of the header checkbox

		/// </summary>

		/// <value type="Infragistics.Web.UI.CheckBoxState" />

		return this._currentState;

	},

	get_nextHeaderChecked: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs.nextChecked">

		/// Gets/sets whether all the cell checkboxes will be checked upon completion

		/// </summary>

		/// <value type="Boolean" />

		return this._newChecked;

	},

	set_nextHeaderChecked: function (newChecked)
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs.nextChecked">

		/// Sets whether all the cell checkboxes will be checked upon completion

		/// </summary>

		/// <param name="newChecked" type="Boolean">Whether cell checkboxes will be checked if this event is not cancelled</param>

		this._newChecked = newChecked;

	},

	dispose: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs.dispose">

		/// Disposes of the object

		/// </summary>

		this._column = null;

		this._currentState = null;

		this._newChecked = null;

	}

}

$IG.CancelHeaderCheckBoxEventArgs.registerClass('Infragistics.Web.UI.CancelHeaderCheckBoxEventArgs', $IG.CancelEventArgs);


$IG.HeaderCheckBoxEventArgs = function (column, currentState)
{

	/// <summary locid="T:J#Infragistics.Web.UI.HeaderCheckBoxEventArgs">

	/// Event arguments object that is passed into an event handler for header checkbox clicked

	/// </summary>

	$IG.HeaderCheckBoxEventArgs.initializeBase(this);

	this._column = column;

	this._currentState = currentState;


}

$IG.HeaderCheckBoxEventArgs.prototype =
{

	get_column: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.HeaderCheckBoxEventArgs.column">

		/// Reference to the column object associated with the event.

		/// </summary>

		/// <value type="Infragistics.Web.UI.GridColumn" />

		return this._column;

	},

	get_currentCheckBoxState: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.HeaderCheckBoxEventArgs.currentCheckBoxState">

		/// Returns the current state of the header checkbox

		/// </summary>

		/// <value type="Infragistics.Web.UI.CheckBoxState" />

		return this._currentState;

	},

	dispose: function ()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.HeaderCheckBoxEventArgs.dispose">

		/// Disposes of the object

		/// </summary>

		this._column = null;

		this._currentState = null;

	}

}

$IG.HeaderCheckBoxEventArgs.registerClass('Infragistics.Web.UI.HeaderCheckBoxEventArgs', $IG.EventArgs);







$IG.HashTree = function ()
{

	/// <summary locid="T:J#Infragistics.Web.UI.HashTree">

	/// A simple tree stucture using Javascript objects 

	///</summary>

	$IG.HashTree.initializeBase(this);


	this._tree = {};

}

$IG.HashTree.prototype =
{

	add: function (row)
	{

		/// <summary locid="M:J#Infragistics.Web.UI.HashTree.add">

		/// Adds a row object to the HashTree by it's DataKey value. 

		/// Throws exception if you attempt to add a row to the tree that shares a particular datakey value.

		/// </summary>

		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row to index.</param>

		if (!row) return;
		var dataKey = row._get_internalDataKey();
		var currentHash = this._tree;


		for (var i = 0; i < dataKey.length; i++)
		{

			var stepDataKey = dataKey[i];

			if (i < dataKey.length - 1)
			{

				if (currentHash[stepDataKey] == null)
				{

					currentHash = currentHash[stepDataKey] = {};

				}

				else
				{

					currentHash = currentHash[stepDataKey];

				}

			}

			else
			{

				if (currentHash[stepDataKey] == null)
				{

					currentHash[stepDataKey] = row;

				}

				else
				{

					throw "Rows must have unique DataKeys. This key appears more than once: " + dataKey;

				}

			}

		}

	},

	remove: function (row)
	{

		/// <summary locid="M:J#Infragistics.Web.UI.HashTree.remove">

		/// Removes a row object from the HashTree

		/// </summary>

		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row to remove from the index tree.</param>

		/// <returns type="Number" integer="true">0 if the row is removed from the collection, -1 if the row could not be found </returns>

		if (!row) return;
		var dataKey = row._get_internalDataKey();
		var currentHash = this._tree;


		for (var i = 0; i < dataKey.length; i++)
		{

			var stepDataKey = dataKey[i];

			if (i < dataKey.length - 1)
			{

				if (this._tree[stepDataKey] == null)
				{

					return 1; // if we don't find a part of the hash for now just return 1 indicating error				

				}

				else
				{

					currentHash = this._tree[stepDataKey];

				}

			}

			else
			{

				if (currentHash && currentHash[stepDataKey] != null)
				{

					

					delete currentHash[stepDataKey];

					return 0;

				}

				return -1;

			}

		}

		return -1;

	},

	contains: function (row)
	{

		/// <summary locid="M:J#Infragistics.Web.UI.HashTree.contains">

		/// Determines if the row object is in the HashTree

		/// </summary>

		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row to look for.</param>

		/// <returns type="Boolean">True if found, false otherwise</returns>
		return this.findByKey(row._get_internalDataKey()) != null;
	},

	findByKey: function (dataKey)
	{

		///<summary locid="M:J#Infragistics.Web.UI.HashTree.findByKey">

		/// Determines if a particular dataKey value is in the HashTree

		///</summary>

		/// <param name="dataKey" type="Array">Data key of the row.</param>

		/// <returns type="Infragistics.Web.UI.GridRow" mayBeNull="true">the row if found, null otherwise</returns>

		if (!dataKey) return;

		var currentHash = this._tree;

		for (var i = 0; i < dataKey.length; i++)
		{

			var stepDataKey = dataKey[i];

			if (i < dataKey.length - 1)
			{

				if (this._tree[stepDataKey] == null)
				{

					return null;

				}

				else
				{

					currentHash = this._tree[stepDataKey];

				}

			}

			else
			{

				var row = currentHash[stepDataKey];

				

				var el = (row && row.get_element) ? row.get_element() : null;
				
				if (!el || (el.type != "row" && el.getAttribute && el.getAttribute("type") != "row"))
				{

					row = null;

				}

				return row;

			}

		}

		return null;

	}

}

$IG.HashTree.registerClass('Infragistics.Web.UI.HashTree', $IG.ObjectBase);




$IG.GridDataType = function ()
{

	///<summary locid="T:J#Infragistics.Web.UI.GridDataType">

	/// Specifies the type of data in a column of WebDataGrid.

	///</summary>

	///<field name="Unknown" type="Number" integer="true" static="true"></field>

	///<field name="String" type="Number" integer="true" static="true"></field>

	///<field name="Double" type="Number" integer="true" static="true"></field>

	///<field name="Float" type="Number" integer="true" static="true"></field>

	///<field name="Decimal" type="Number" integer="true" static="true"></field>

	///<field name="Long" type="Number" integer="true" static="true"></field>

	///<field name="Ulong" type="Number" integer="true" static="true"></field>

	///<field name="Int" type="Number" integer="true" static="true"></field>

	///<field name="Uint" type="Number" integer="true" static="true"></field>

	///<field name="Short" type="Number" integer="true" static="true"></field>

	///<field name="Ushort" type="Number" integer="true" static="true"></field>

	///<field name="Sbyte" type="Number" integer="true" static="true"></field>

	///<field name="Byte" type="Number" integer="true" static="true"></field>

	///<field name="Date" type="Number" integer="true" static="true"></field>

	///<field name="Boolean" type="Number" integer="true" static="true"></field>

	///<field name="Char" type="Number" integer="true" static="true"></field>

}

$IG.GridDataType.prototype =
{

	Unknown: -1,

	String: 0,

	Double: 1,

	Float: 2,

	Decimal: 3,

	Long: 4,

	Ulong: 5,

	Int: 6,

	Uint: 7,

	Short: 8,

	Ushort: 9,

	Sbyte: 10,

	Byte: 11,

	Date: 12,

	Boolean: 13,

	Char: 14

};

$IG.GridDataType.registerEnum("Infragistics.Web.UI.GridDataType");



/*
* igWebDataGridCellEditing.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/



$IG.CellEditing = function(obj, objProps, control, parentCollection)
{
    ///<summary locid="T:J#Infragistics.Web.UI.CellEditing">
    ///Editing behavior object of the grid.
    ///</summary>
   	$IG.CellEditing.initializeBase(this, [obj, objProps, control, parentCollection]);

}

$IG.CellEditing.prototype =
{
	_createCollections: function(collectionsManager)
	{
		this._editors = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._editors._addObject($IG.ColumnEditor, null, columnKey);
	},

	_initializeComplete: function()
	{
		$IG.CellEditing.callBaseMethod(this, "_initializeComplete");
	},

	
	get_columnSettings: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.CellEditing.columnSettings">
		///Returns column settings.
		///</summary>
		///<value></value>
		return this._editors;
	},
	get_columnSettingFromKey: function(columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridEditBase.get_columnSettingFromKey">
		/// Gets the column summary setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the cell editing column setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnEditableSetting">The editing column setting tied to the specified column key</value>

		if (this._editors && this._editors._items)
		{
			for (var i = 0; i < this._editors._items.length; i++)
			{
				if (this._editors._items[i].get_columnKey() === columnKey)
					return this._editors._items[i];
			}
		}
		return null;
	},
	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.CellEditing.dispose">
		/// For internal use.
		///</summary>
		if (this._editors)
		{
			for (var x = 0; x < this._editors.length; ++x)
				this._editors[x].dispose();
			delete this._editors;
		}
		$IG.CellEditing.callBaseMethod(this, "dispose");

	}
	
}
$IG.CellEditing.registerClass('Infragistics.Web.UI.CellEditing', $IG.GridEditBase, $IG.IUpdatingBehavior);










$IG.ColumnEditor = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnEditor">
	/// Object that defines a column editor for the grid columns.
	/// </summary>
    $IG.ColumnEditor.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnEditor.prototype =
{
}
$IG.ColumnEditor.registerClass('Infragistics.Web.UI.ColumnEditor', $IG.ColumnEditableSetting);


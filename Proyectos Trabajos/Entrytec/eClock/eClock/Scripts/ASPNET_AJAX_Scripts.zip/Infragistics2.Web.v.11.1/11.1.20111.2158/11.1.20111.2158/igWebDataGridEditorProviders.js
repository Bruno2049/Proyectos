/*
* igWebDataGridEditorProviders.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/




$IG.SliderProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.SliderProvider">
	/// The object defines the WebSlider editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	var i = -1, nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		if (nodes[i].nodeName != 'DIV')
			continue;
		var id = nodes[i].id;
		if (!$util.isEmpty(id))
			if (this._editor = $find(id))
			break;
		if (nodes[i].getAttribute("_wrapper"))
		{
			this._wrapper = nodes[i];
			nodes = nodes[i].childNodes;
			i = -1;
		}
	}
	if (!this._editor)
		return;

	$IG.SliderProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._input;
}

$IG.SliderProvider.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderProvider.value">
		/// Overrides the EditorProvider object's property.
		/// Gets/sets the value to/from the underlying slider. 
		/// </summary>
		/// <value type="Number">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SliderProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Number">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if (!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
	},
	
	_onMouse: function(e)
	{
		var elem = e ? e.target : null;
		if (!elem)
			return;
		
		while ((elem = elem.parentNode) != null)
			if (elem == this._element)
			return;
		
		this.notifyLostFocus(e);
	},
	
	_removeHandlers: function()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(this._grid, 'mousedown', this._onMouseFn);
		this._grid = null;
		$IG.SliderProvider.callBaseMethod(this, '_removeHandlers');
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, slider = this._editor._element;
		
		slider.style.visibility = 'hidden';
		var wrapper = this._getWrapper(slider, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = slider.offsetWidth + 'px';
		slider.style.visibility = 'visible';
		this._focus(this._input);
		if (this._hasLsnr)
			return;
		this._addHandlers();
		
		if (this._grid)
			elem = this._grid;
		else
		{
			
			while ((elem = elem.parentNode) != null)
			{
				var id = elem.id;
				if (id && elem.nodeName == 'DIV' && id.length > 1 && id.charAt(0) != ':')
					break;
			}
			if (!elem)
				return;
			
			this._grid = elem;
		}
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(elem, 'mousedown', this._onMouseFn);
	}
}

$IG.SliderProvider.registerClass('Infragistics.Web.UI.SliderProvider', $IG.EditorProvider);



$IG.TextEditProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextEditProvider">
	/// The object defines the WebTextEdit editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if(typeof igedit_getById != 'function' || !element)
		return;
	
	var i = -1, id = null, nodes = element.childNodes;
	
	while(++i < nodes.length)
		if(nodes[i].nodeName == 'INPUT' && (id = nodes[i].id) != null)
			if(id.length > 1)
				break;
	this._editor = igedit_getById(id);
	if(!this._editor)
		return;
	$IG.TextEditProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor.elem;
}

$IG.TextEditProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="String">Current value in editor.</value>
		var val = this._editor ? this._editor.getValue() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="String">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		editor.setValue(val);
		this._old = editor.getValue();
		
		editor._gridKey = this._charKey;
	},
	_show:function(top, left, width, height, cssClass, parent, cell)
	{
		var editor = this._editor;
		var elem = editor.Element, wrapper = null, borderWidth = 0;
		
		
		if(elem.nodeName == 'TABLE')
		{
			wrapper = this._getWrapper(elem, cssClass);
			
			borderWidth = $util.toIntPX(null, 'borderTopWidth', 0, wrapper) * 2;
			width -= borderWidth;
			height -= borderWidth;
			
			elem.style.border = 'none';
			
			this._setCss(this._input, cssClass);
		}
		this._setCss(elem, cssClass);
		
		
		if(this._validator)
			editor.elemValue.onchange = null;
		
		
		var buts = editor.buttons;
		if(buts && buts[1])
		{
			var but, i = 0;
			while(i++ < 7)
			{
				if(i == 1 || i == 4)
					but = buts[(i & 1) + 1].elem;
				but.style.height = '';
				but = but.parentNode;
			}
			height++;
		}
		this._setBounds(top, left, height, this._element.style, parent, cell);
		editor.setVisible(true, null, null, width, height);
		this._addHandlers();
		var shiftW = elem.offsetWidth - width, shiftH = elem.offsetHeight - height;
		if(shiftW > 0 || shiftH > 0)
			if((width -= shiftW) > 5 && (height -= shiftH) > 5)
				editor.setVisible(true, null, null, width, height);
		if(wrapper)
		{
			
			wrapper.style.width = elem.offsetWidth + 'px';
			
			if(Sys.Browser.agent != Sys.Browser.InternetExplorer)
			{
				//if(Sys.Browser.agent == Sys.Browser.Firefox)
				//	borderWidth += 2;
				this._input.style.height = (elem.offsetHeight - borderWidth) + 'px';
			}
		}
	}
}
$IG.TextEditProvider.registerClass('Infragistics.Web.UI.TextEditProvider', $IG.EditorProvider);



$IG.DateChooserProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DateChooserProvider">
	/// The object defines the WebDateChooser editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if(typeof igdrp_getComboById != 'function' || !element)
		return;
	
	var i = -1, id = null, nodes = element.childNodes;
	
	while(++i < nodes.length)
	{
		if(nodes[i].nodeName == 'INPUT' && (id = nodes[i].id) != null)
		{
			var iH = id.indexOf('_hidden');
			if(iH > 1 && iH == id.length - 7)
			{
				id = id.substring(0, iH);
				break;
			}
		}
	}
	var dc = this._editor = igdrp_getComboById(id);
	if(!dc)
		return;
	
	if(!dc._oldFire)
	{
		
		dc._oldFire = dc._fire;
		dc._fire = function(id, arg, evt)
		{
			this._oldFire(id, arg, evt);
			
			if(id == 4)
				this.focus();
			
			if(id == 2)
			{
				var pos = $util.getPosition(this.Element), style = this.container.style;
				style.left = pos.x + 'px';
				style.top = (pos.y + this.Element.offsetHeight) + 'px';
			}
		}
	}
	$IG.DateChooserProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor.inputBox;
}

$IG.DateChooserProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DateChooserProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Date">Current value in editor.</value>
		var val = this._editor ? this._editor.getValue() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DateChooserProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Date">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		if(!val)
			val = null;
		else if(!val.getDate)
		{
			try
			{
				var time = Date.parse('' + val);
				if(time && !time.setDate && time.toString() != 'NaN')
					val = new Date(time);
			}
			catch(e){}
		}
		if(val && !val.getDate)
			editor.setText(val.toString());
		else
			editor.setValue(val);
		this._old = editor.getValue();
		
		editor._gridKey = this._charKey;
	},
	
	_onBlurHandler:function(e)
	{
		
		if(this._editor && this._editor.Dropped)
			return;
		this.notifyLostFocus(e);
	},
	_show:function(top, left, width, height, cssClass, parent, cell)
	{
		/// <summary>
		/// Overrides the EditorProvider's function.
		/// </summary>
		var editor = this._editor;
		
		
		
		
		if(editor.imH)
			editor.DropButton.Image.style.height = '';
		var elem = editor.Element;
		
		
		var wrapper = this._getWrapper(elem, cssClass);
		this._setBounds(top + 1, left + 1, height, this._element.style, parent, cell);
		this._setCss(this._input, cssClass);
		var borderWidth = $util.toIntPX(null, 'borderTopWidth', 0, wrapper) * 2;
		editor.setVisible(true, null, null, width -= borderWidth, height -= borderWidth);
		var shiftW = elem.offsetWidth - width, shiftH = elem.offsetHeight - height;
		if(shiftW > 0 || shiftH > 0) if((width -= shiftW) > 5 && (height -= shiftH) > 5)
			editor.setVisible(true, null, null, width, height);
		
		wrapper.style.width = elem.offsetWidth + 'px';
		this._addHandlers();
	}
}
$IG.DateChooserProvider.registerClass('Infragistics.Web.UI.DateChooserProvider', $IG.EditorProvider);



$IG.CalendarProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CalendarProvider">
	/// The object defines the WebCalendar editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if(typeof igcal_getCalendarById != 'function' || !element)
		return;
	
	var i = -1, id = null, nodes = element.childNodes;
	
	while(++i < nodes.length)
		if(nodes[i].nodeName == 'INPUT' && (id = nodes[i].id) != null) if(id.length > 1)
			break;
	this._editor = igcal_getCalendarById(id);
	if(!this._editor)
		return;
	$IG.CalendarProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = null;
}

$IG.CalendarProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Date">Current value in editor.</value>
		var val = this._editor ? this._editor.getSelectedDate() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CalendarProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Date">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		if(!val)
			val = null;
		else if(!val.getDate)
		{
			try
			{
				var time = Date.parse('' + val);
				if(time && !time.setDate && time.toString() != 'NaN')
					val = new Date(time);
			}
			catch(e){}
			if(!val.getDate)
				val = null;
		}
		editor.setSelectedDate(val);
		this._old = editor.getSelectedDate();
	},
	
	_onMouse:function(e)
	{
		var elem = e ? e.target : null;
		if(!elem)
			return;
		
		while((elem = elem.parentNode) != null)
			if(elem == this._editor.element)
				return;
		this._close(e);
	},
	
	_onKey:function(e)
	{
		var key = e ? e.keyCode : 0;
		if(key == 9 || key == 13 || key == 27)//tab, enter, esc
			this._close(e);
	},
	
	_close:function(e)
	{
		
		var me = this;
		if(!me._close)
			if((me = me._me) == null)
				if((me = e) != null)
					me = e._me;
		if(!me || !me._close)
			return;
		me.notifyLostFocus(e.keyCode ? e : null);
	},
	hideEditor:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalendarProvider.hideEditor">
		/// Overrides the EditorProvider's function.
		/// </summary>
		var editor = this._editor;
		





		
		if(!editor || !this._element)
			return;
		if(this._hasLsnr)
		{
			if(this._grid)
				$removeHandler(this._grid, 'mousedown', this._onMouseFn);
			$removeHandler(document, 'keydown', this._onKeyFn);
		}
		this._hasLsnr = false;
		$util.display(this._element, true);
		if(this._grid)
		{
			this._grid._me = null;
			this._grid = null;
		}
		editor.onValueChanged = null;
		editor._me = null;
	},
	_show:function(top, left, width, height, cssClass, parent, cell)
	{
		/// <summary>
		/// Overrides the EditorProvider's function.
		/// </summary>
		var editor = this._editor;
		editor.onValueChanged = this._close;
		var elem = this._element;
		this._setCss(editor.element, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, editor.element);
		
		if(!this._onMouseFn)
		{
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
			this._onKeyFn = Function.createDelegate(this, this._onKey);
		}
		
		editor._me = this;
		
		if(this._grid)
			elem = this._grid;
		else
		{
			
			if(this._owner)
				elem = this._owner._element;
			if(!elem) while((elem = elem.parentNode) != null)
			{
				var id = elem.id;
				if(id && elem.nodeName == 'DIV' && id.length > 1 && id.charAt(0) != ':')
					break;
			}
			
			if(elem)
			{
				this._grid = elem;
				elem._me = this;
			}
		}
		if(this._hasLsnr)
			return;
		this._hasLsnr = true;
		if(elem)
			$addHandler(elem, 'mousedown', this._onMouseFn);
		$addHandler(document, 'keydown', this._onKeyFn);
	}
}
$IG.CalendarProvider.registerClass('Infragistics.Web.UI.CalendarProvider', $IG.EditorProvider);



$IG.TextEditorProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextEditorProvider">
	/// The object defines the WebTextEditor editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	
	var i = -1, id = null, suffix = '_clientState', nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		id = nodes[i];
		id = (id.nodeName == 'INPUT') ? id.id : null;
		var len = id ? id.length : 0;
		if (len > 15 && id.indexOf(suffix) > len - 13)
		{
			this._editor = $find(id.substring(0, len - suffix.length));
			break;
		}
	}
	if (!this._editor)
		return;
	$IG.TextEditorProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._elem;
}

$IG.TextEditorProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditorProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="String">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TextEditorProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="String">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
		
		editor._gridKey = this._charKey;
	},
	_show:function(top, left, width, height, cssClass, parent, cell)
	{
		var editor = this._editor;
		var elem = editor._element, wrapper = null, borderWidth = 0, input = editor._elem;
		
		var css0 = editor._ep_css, oldIW = '';
		if(!css0)
			css0 = editor._ep_css = editor._css[0];
		
		editor._css = editor._cssI = null;
		
		
		if(elem.nodeName == 'TABLE')
		{
			
			input.parentNode.className = elem.className = '';
			wrapper = this._getWrapper(elem, cssClass);
			
			css0 = input.className;
			input.className += ' ' + cssClass;
			var style = input.style, rs = $util.getRuntimeStyle(input);
			style.color = $util.getStyleValue(rs, 'color');
			style.fontStyle = $util.getStyleValue(rs, 'fontStyle');
			style.fontWeight = $util.getStyleValue(rs, 'fontWeight');
			style.fontSize = $util.getStyleValue(rs, 'fontSize');
			style.fontFamily = $util.getStyleValue(rs, 'fontFamily');
			
			if(this._oldIW)
				style.width = this._oldIW;
			
			oldIW = $util.getStyleValue(rs, 'width');
			
			input.className = css0;
			
			borderWidth = $util.toIntPX(null, 'borderTopWidth', 0, wrapper) * 2;
			width -= borderWidth;
			height -= borderWidth;
		}
		else
			
			elem.className = css0 + ' ' + cssClass;
		
		
		this._setBounds(top, left, height, this._element.style, parent, cell);
		editor._fixSize(width + 'px', height + 'px');
		this._addHandlers();
		var shiftW = elem.offsetWidth - width, shiftH = elem.offsetHeight - height, w = width;
		if (wrapper && this._shared)
			shiftW = 0;
		
		if (shiftH > 4)
			shiftH = 0;
		if(shiftW > 0 || shiftH > 0)
			if((w -= shiftW) > 5 && (height -= shiftH) > 5)
				editor._fixSize(w + 'px', height + 'px');
		if(wrapper)
		{
			
			if((w = elem.offsetWidth) > width + 2 && (shiftW = input.offsetWidth) > 20)
			{
				
				if((w = width - w + shiftW) < 5)
					w = 15;
				
				this._oldIW = oldIW;
				input.style.width = w + 'px';
			}
			
			wrapper.style.width = (this._shared ? width : elem.offsetWidth) + 'px';
		}
		this._focus(input);
	}
}
$IG.TextEditorProvider.registerClass('Infragistics.Web.UI.TextEditorProvider', $IG.EditorProvider);



$IG.DropDownProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DropDownProvider">
	/// The object defines the WebDropDown editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	this._grid = owner;
	var controlElem = element.firstChild;
	while (controlElem && (typeof (controlElem.tagName) == "undefined" || controlElem.tagName != "DIV"))
		controlElem = controlElem.nextSibling;
	this._editor = $find(controlElem.id);
	if (!this._editor)
		return;
	$IG.DropDownProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._dropDown = this._editor._elements.DropDown;
	this._input = this._editor._elements.Input;
	this._stretchHeight = this._get_clientOnlyValue("sh");
	this._verticalAlign = this._get_clientOnlyValue("va");
}

$IG.DropDownProvider.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.value">
		/// Overrides the EditorProvider object's property.
		/// Gets/sets the value to/from the underlying drop down. 
		/// </summary>
		/// <value type="Object">Current value in editor.</value>
		var item = this._editor.get_selectedItem();
		var val = item ? item.get_value() : null;
		if (val == null && item)
			val = item.get_text();
		if (val == null || val === '')
			val = this._editor.get_currentValue();
		return val;
	},
	set_value: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Object">Value for editor.</param>
		var editor = this._editor;
		if (!editor)
			return;
		var item = editor.get_selectedItem();
		if (item)
		{
			item.unselect();
			editor.set_selectedItemIndex(-1);
		}
		
		if (this._editor.get_displayMode() > 1)
			this._charKey = null;
		
		if (this._charKey)
			return;
		var items = editor.get_items();
		var i = (val == null || val === '') ? -1 : items.getLength();
		
		while (i-- > 0)
			if (items.getItem(i).get_value() == val)
				break;
		
		if (i == -1)
		{
			i = items.getLength();
			while (i-- > 0)
				if (items.getItem(i).get_text() == val)
					break;
		}
		if (i >= 0)
		{
			item = items.getItem(i);
			item.select();
			editor.set_selectedItemIndex(i);
			if (!$util.isEmpty(i = item.get_text()))
				val = i;
		}
		editor.set_currentValue(val, true);
	},
	get_text: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropDownProvider.text">
		/// Gets formatted text from the editor. 
		/// </summary>
		/// <value type="String">Current text in editor.</value>
		var item = this._editor.get_selectedItem();
		return item ? item.get_text() : '' + this._editor.get_currentValue();
	},
	
	_onMouse: function(e)
	{
		var parent = e.target.parentNode;
		while (parent && parent.tagName && parent.tagName != "BODY" && parent != this._element && parent != this._dropDown)
			parent = parent.parentNode;
		if (parent != this._element && parent != this._dropDown)
			this.notifyLostFocus(e);
		//this.__internalClick = true;
	},
	_addHandlers: function()
	{
		if (this._hasLsnr)
			return;
		$IG.DropDownProvider.callBaseMethod(this, '_addHandlers');
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(document, 'mousedown', this._onMouseFn);
	},
	_removeHandlers: function()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(document, 'mousedown', this._onMouseFn);
		$IG.DropDownProvider.callBaseMethod(this, '_removeHandlers');
	},
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._editor.get_element();
		var cellElement = cell.get_element();
		if (!this._stretchHeight)
		{
			this._element.style.display = '';
			this._element.style.visibility = 'visible';
			



			if (this._verticalAlign == 0 || this._verticalAlign == 2) // NotSet or Middle
				top += Math.round((cellElement.offsetHeight - elem.offsetHeight) / 2);
			else if (this._verticalAlign == 3) // Bottom
				top += cellElement.offsetHeight - elem.offsetHeight;
		}
		this._setBounds(top, left, height, this._element.style, parent, cell);
		
		elem.style.width = width + "px";
		if (this._stretchHeight)
			elem.style.height = cellElement.clientHeight + "px";
		
		this._focus(this._input);
		
		this._firstKey(this._charKey);
		this._addHandlers();
	},

	_onBlurHandler: function(e)
	{
	},

	notifyLostFocus: function(e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DropDownProvider.notifyLostFocus">
		/// The method is called whenever the editor loses focus. 
		/// </summary>
		/// <param name="e" type="Sys.UI.DomEvent">
		/// Event object associated with the event that triggered losing focus by the editor.
		/// </param>
		
		
		if (this._editor != null)
			this._editor.closeDropDown();
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DropDownProvider.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		this._editor = null;
		this._grid = null;
		$IG.DropDownProvider.callBaseMethod(this, 'dispose');
	}
}

$IG.DropDownProvider.registerClass('Infragistics.Web.UI.DropDownProvider', $IG.EditorProvider);



$IG.MonthCalendarProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.MonthCalendarProvider">
	/// The object defines the WebTextEditor editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	
	var i = -1, id = null, suffix = '_clientState', nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		id = nodes[i];
		id = (id.nodeName == 'INPUT') ? id.id : null;
		var len = id ? id.length : 0;
		if (len > 15 && id.indexOf(suffix) > len - 13)
		{
			this._editor = $find(id.substring(0, len - suffix.length));
			break;
		}
	}
	if (!this._editor)
		return;
	
	this._editor._master = this;
	$IG.MonthCalendarProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor._elements[7];
}

$IG.MonthCalendarProvider.prototype =
{
	get_value:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MonthCalendarProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Date">Current value in editor.</value>
		var val = this._editor ? this._editor.get_selectedDate() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MonthCalendarProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Date">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if(!editor)
			return;
		editor.set_selectedDate(val);
		this._old = editor.get_selectedDate();
	},
	
	_onMouse: function(e)
	{
		var elem = e ? e.target : null;
		if (!elem)
			return;
		
		while ((elem = elem.parentNode) != null)
			if (elem == this._element)
			return;
		
		this.notifyLostFocus(e);
	},
	
	_removeHandlers: function()
	{
		if (this._onMouseFn && this._hasLsnr && this._grid)
			$removeHandler(this._grid, 'mousedown', this._onMouseFn);
		this._grid = null;
		$IG.MonthCalendarProvider.callBaseMethod(this, '_removeHandlers');
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, calendar = this._editor._element;
		
		calendar.style.visibility = 'hidden';
		var wrapper = this._getWrapper(calendar, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = calendar.offsetWidth + 'px';
		calendar.style.visibility = 'visible';
		this._focus(this._input);
		if (this._hasLsnr)
			return;
		this._addHandlers();
		
		if (this._grid)
			elem = this._grid;
		else
		{
			
			while ((elem = elem.parentNode) != null)
			{
				var id = elem.id;
				if (id && elem.nodeName == 'DIV' && id.length > 1 && id.charAt(0) != ':')
					break;
			}
			if (!elem)
				return;
			
			this._grid = elem;
		}
		if (!this._onMouseFn)
			this._onMouseFn = Function.createDelegate(this, this._onMouse);
		$addHandler(elem, 'mousedown', this._onMouseFn);
	},
	
	_doCal: function()
	{
		
		this.notifyLostFocus();
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.MonthCalendarProvider.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		if (!this._editor)
			return;
		delete this._editor._master;
		delete this._editor;
		this._grid = null;
		$IG.MonthCalendarProvider.callBaseMethod(this, 'dispose');
	}
}
$IG.MonthCalendarProvider.registerClass('Infragistics.Web.UI.MonthCalendarProvider', $IG.EditorProvider);












































































































$IG.RatingProvider = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RatingProvider">
	/// The object defines the WebRating editor provider for a column. 
	/// Overrides the EditorProvider object.
	/// </summary>
	if (!element)
		return;
	var i = -1, nodes = element.childNodes;
	
	while (++i < nodes.length)
	{
		if (nodes[i].nodeName != 'DIV')
			continue;
		var id = nodes[i].id;
		if (!$util.isEmpty(id))
			if (this._editor = $find(id))
				break;
		if (nodes[i].getAttribute("_wrapper"))
		{
			nodes = nodes[i].childNodes;
			i = -1;
		}
	}
	if (!this._editor)
		return;
	$IG.RatingProvider.initializeBase(this, [adr, element, props, owner, csm]);
	this._input = this._editor.get_element();
}

$IG.RatingProvider.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingProvider.value">
		/// Overrides the EditorProvider's function.
		/// </summary>
		/// <value type="Number">Current value in editor.</value>
		var val = this._editor ? this._editor.get_value() : this._old;
		return this._areEqual(val, this._old) ? this._old0 : val;
	},
	set_value: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Number">Value for editor.</param>
		
		
		this._old0 = this._old = val;
		var editor = this._editor;
		if (!editor)
			return;
		editor.set_value(val);
		this._old = editor.get_value();
	},
	
	_show: function(top, left, width, height, cssClass, parent, cell)
	{
		var elem = this._element, rating = this._editor._element;
		this._editor._provider = this;
		
		rating.style.visibility = 'hidden';
		var wrapper = this._getWrapper(rating, cssClass);
		this._setBounds(top, left, height, elem.style, parent, cell, wrapper);
		wrapper.style.width = rating.offsetWidth + 'px';
		rating.style.visibility = 'visible';
		this._focus(this._input);
		this._addHandlers();
	},
	_onKeyDownHandler: function(e)
	{
		var key = e.keyCode;
		
		if (key == Sys.UI.Key.enter)
			this._editor.set_value(this._editor._realValFromLengthVal(this._editor._keyHover));
		if (key == Sys.UI.Key.tab || key == Sys.UI.Key.space || key == Sys.UI.Key.esc || (key == Sys.UI.Key.enter && !e.shiftKey && !e.ctrlKey && this._getExitEditModeOnEnter()))
			this.notifyLostFocus(e);
	}
	



}
$IG.RatingProvider.registerClass('Infragistics.Web.UI.RatingProvider', $IG.EditorProvider);



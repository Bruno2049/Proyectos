/*
* igWebDataGridClientBinding.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


$IG.WebDataGrid.prototype.__loadClientBindingObjects = function ()
{
	var clientBindingsCount = this._get_clientOnlyValue("cbc");
	var clientBindingDataContextIndex = this._get_clientOnlyValue("cbdci");

	this._clientBindingDataContext = new $IG.ClientBindingDataContext("clientBindingDataContext", null, this._objectsManager.get_objectProps(clientBindingDataContextIndex), this, "clientBindingDataContext");
	this._objectsManager.register_object(clientBindingDataContextIndex, this._clientBindingDataContext);
	this._clientBindings = [];

	var count = 0;
	for (i = clientBindingDataContextIndex + 1; i < clientBindingDataContextIndex + 1 + clientBindingsCount; i++)
	{
		this._clientBindings[count] = new $IG.ClientDataBinding("clientBinding", null, this._objectsManager.get_objectProps(i), this, "clientBinding");
		this._objectsManager.register_object(i, this._clientBindings[count]);
		count++;
	}
	var ds = this._dataStore[this._dataStore.length - 1];
	for (var r = 0; r < ds.length; ++r)
	{
		for (var c = 0; c < this.get_columns().get_length(); ++c)
		{
			var col = this.get_columns().get_column(c);
			if (col.get_type() == "date" && typeof ds[r][col._dataFieldName] == "string")
				ds[r][col._dataFieldName] = this._gridUtil._convertServerDateStringToClientObject(ds[r][col._dataFieldName]);
		}
	}
	
	this._onHideColumnCssCreatedClientRenderingHandler = Function.createDelegate(this, this._onHideColumnCssCreatedClientRendering);
	this._gridUtil._registerEventListener(this, "HideColumnCssCreated", this._onHideColumnCssCreatedClientRenderingHandler);
}
$IG.WebDataGrid.prototype._renderFormatedValue = function (item, text, htmlEncode, multiLine)
{
	if ($util.IsIE && text == "")			
		return "<!---->";	
    
    if (htmlEncode)
        text = $util.htmlEscapeCharacters(text);
    if (multiLine)
        text = text.split("\n").join("<BR>");
	return text;

}
$IG.WebDataGrid.prototype.applyClientBinding = function ()
{
	/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.applyClientBinding">
	/// Used the render the HTML rows of WebDataGrid on the client.
	/// </summary>
	this._applyClientBinding(false);
}
$IG.WebDataGrid.prototype._applyClientBinding = function (init)
{
	var firstTime = false;
	if (!this._tableTemplate)
	{
		this._emptyRowTemplate = this._get_clientOnlyValue("ertmpl");
		this._tableTemplate = this._get_clientOnlyValue("tmpl");

		this.__dataKeyFieldsSet = (this._tableTemplate.endsWith("</tr>") ? false : true);
		firstTime = true;
	}
	var args = this._raiseClientEvent('DataBinding', 'Cancel', null);
	var cancel = args ? args.get_cancel() : false;
	if (cancel)
		return;

	this._gridUtil._fireEvent(this, "DataBinding");

	var dataSource = this.get_dataSource();

	
	if (!firstTime && this._rows)
	{
		this._rows._disposeEachRow();
		this._rows._disposeOfKeyIndexTree();
	}
	$(this._elements.dataTbl.lastChild).attr('mkr', 'rows');
	$(this._elements.dataTbl.lastChild).empty();


	// A.T. 30 August 2010 - adding support for alt classes and more flexible row-by-row rendering
	var dataSourceObject = eval(dataSource);

	var hash = this._getHashCode();
	var rowsElement = this._elements["rows"];

	if (dataSourceObject.length > 0 || !this._emptyRowTemplate)
	{
		

		if (rowsElement && this._rowsClass && rowsElement.className != this._rowsClass)
		{			
			rowsElement.className = this._rowsClass;
			this._rowsClass = null;
		}

		var grid = this;
		$.each(dataSourceObject, function (index, val)
		{
			var dataTable = grid._elements.dataTbl;
			$.tmpl(grid._tableTemplate, val, { grid: grid, rowIndex: index }).appendTo(dataTable);

			var row = !grid.__dataKeyFieldsSet ? $(dataTable.lastChild.lastChild) : dataTable.lastChild.childNodes[dataTable.lastChild.childNodes.length - 2];

			$(row).attr('id', hash + ":adr:" + index);
			if (index % 2 != 0)
				$(row).addClass(grid._get_clientOnlyValue("rac"));
			if (!grid.__dataKeyFieldsSet)
			{
				var keyComment = "<!--[" + index + "]-->";
				$(dataTable.lastChild).append(keyComment);
			}

		});
	}
	else
	{
		

		if (rowsElement && (!this._rowsClass))
		{			
			this._rowsClass = rowsElement.className;
			rowsElement.className = "";
		}
		$(this._elements.dataTbl.lastChild).html(this._emptyRowTemplate);
	}

	if (!firstTime && this._rows)
	{
		this._rows._set_length(dataSourceObject.length);
		if (this._rows.get_length() > 0)
			this._adjustFirstRowHTML(this._rows.get_row(0));

		this._onDataTblResize({ "clientHeight": this._elements.dataTbl.clientHeight }, null);
		this._onResize({ "clientHeight": this._element.clientHeight }, false);
	}

	this._gridUtil._fireEvent(this, "DataBound", { init: init });
	this._raiseClientEvent('DataBound', null, null);
}

$IG.WebDataGrid.prototype._adjustFirstRowHTML = function (row)
{
		
	if (row)
	{
		for (var i = 0; i < row.get_cellCount(); i++)
		{
			var cell = row.get_cell(i);
			if (cell && cell.get_element())
			{
				var width = cell.get_column().get_width();
				width = (width == "" ? this.get_defaultColumnWidth() : width );
				if (width != "")
					cell.get_element().style.width = width;
			}
		}
	}
}

$IG.WebDataGrid.prototype._get_dataKeyFieldsSet = function ()
{
	return this.__dataKeyFieldsSet;
}

$IG.WebDataGrid.prototype._getHashCode = function ()
{
	var attributeCounter = 10000;
	var hash = 0;
	for (var i = 0; i < this._id.length; i++)
	{
		hash = hash << 2;
		hash += this._id.charCodeAt(0);
	}

	return "x:" + hash + '.' + attributeCounter;
}


$IG.WebDataGrid.prototype._onHideColumnCssCreatedClientRendering = function (args)
{
	var column = args.column;
	var css = args.css;
	var tableTemplate = $("<div></div>").html(this._tableTemplate);
	var rowTemplate = tableTemplate[0].firstChild;
	var offset = this._cell_index_offset + column.get_visibleIndex();
	var cellElem = rowTemplate.childNodes[offset];
	if (cellElem)
		$util.addCompoundClass(cellElem, css);
	this._tableTemplate = tableTemplate.html();
}

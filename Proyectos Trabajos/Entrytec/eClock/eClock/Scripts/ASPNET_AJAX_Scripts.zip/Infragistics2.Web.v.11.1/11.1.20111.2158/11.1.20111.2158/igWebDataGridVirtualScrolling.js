/*
* igWebDataGridVirtualScrolling.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/



$IG.VirtualScrolling = function(obj, objProps, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.VirtualScrolling">
	/// Virtual scrolling behavior object of the grid. 
	/// </summary>
	$IG.VirtualScrolling.initializeBase(this, [obj, objProps, control]);

	this._grid = this._owner;
	this._rows = this._grid.get_rows();
	this._rowsElem = this._rows._element;
	this._scrollingMode = this._get_clientOnlyValue("vsm");
	this._rowPersistence = this._get_clientOnlyValue("vspm");
	this._rowCacheFactor = this._get_clientOnlyValue("vscf");
	this._thresholdFactor = this._get_clientOnlyValue("vstf");
	this._recordCount = this._get_clientOnlyValue("rc");
	
	if (this._get_clientOnlyValue("rs"))
		this._grid.set_scrollTop(0);
	if (this._recordCount <= this._rowsLengh())
		return;
	this._onvscrollinitdelegate = Function.createDelegate(this, this._onInitVerticalHeight);
	this._grid._gridUtil._registerEventListener(this._grid, "VerticalScrollBarHeightInit", this._onvscrollinitdelegate);
	this._oninitinglayout = Function.createDelegate(this, this._initLayout);
	this._grid._gridUtil._registerEventListener(this._grid, "InitializingLayout", this._oninitinglayout);
	this._oninitedlayout = Function.createDelegate(this, this._initLayoutComplete);
	this._grid._gridUtil._registerEventListener(this._grid, "InitializedLayout", this._oninitedlayout);
	this._onscrolltopchange = Function.createDelegate(this, this._onScrollTopChange);
	this._grid._gridUtil._registerEventListener(this._grid, "ScrollTopChange", this._onscrolltopchange);
	this._onmousewheel = Function.createDelegate(this, this._onMouseWheel);
	this._grid._gridUtil._registerEventListener(this._grid, "MouseWheel", this._onmousewheel);
	this._onresize = Function.createDelegate(this, this._onResize);
	this._grid._gridUtil._registerEventListener(this._grid, "Resize", this._onresize);
    this._ontouchscrolledtop = Function.createDelegate(this, this._onTouchScrolledTop);
	this._grid._gridUtil._registerEventListener(this._grid, "TouchScrolledTop", this._ontouchscrolledtop);

	this._onscrollbarstopped = Function.createDelegate(this, this._scrollbarStopped);
}

$IG.VirtualScrolling.prototype =
{
	get_scrollingMode: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.scrollingMode">
		/// Gets scrolling mode: 0 - virtual, 1 - deferred. 
		/// </summary>
		/// <value type="Number" integer="true" />
		return this._scrollingMode;
	},

	get_rowCacheFactor: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.rowCacheFactor">
		/// Gets row cache factor. Defines the cache size in number 
		/// of visible rows times the factor. 
		/// </summary>
		/// <value type="Number" />
		return this._rowCacheFactor;
	},

	get_thresholdFactor: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.thresholdFactor">
		/// Gets cache threshold factor. Defines the threshold point of 
		/// the cache size in number of visible rows times the factor.
		/// </summary>
		/// <value type="Number" />
		return this._thresholdFactor;
	},

	get_dataFetchDelay: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.dataFetchDelay">
		/// Gets a wait delay between the scrollbar movements to initiate the
		/// rows request to the server.
		/// </summary>
		/// <value type="Number" integer="true" />
		return this._get_value($IG.VirtualScrollingProps.DataFetchDelay);
	},
	set_dataFetchDelay: function (val)
	{
		/// <param name="val" type="Number" integer="true">Deleay in milliseconds.</param>
		return this._set_value($IG.VirtualScrollingProps.DataFetchDelay, val);
	},

	get_tooltipCssClass: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.tooltipCssClass">
		/// Gets css class name for the tooltip.
		/// </summary>
		/// <value type="String" />
		return this._get_value($IG.VirtualScrollingProps.TooltipCssClass);
	},
	set_tooltipCssClass: function (val)
	{
		/// <param name="val" type="String">CssClass name for the tooltip.</param>
		return this._set_value($IG.VirtualScrollingProps.TooltipCssClass, val);
	},

	get_tooltipVisibility: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.tooltipVisibility">
		/// Gets visibility of tooltip. 0 - tooltip appears in deferred mode 
		/// and does not appear in virtual. 1 - tooltip always appear, 
		/// 2 - tooltip never appears.
		/// </summary>
		/// <value type="Number" />
		return this._get_value($IG.VirtualScrollingProps.TooltipVisibility);
	},
	set_tooltipVisibility: function (val)
	{
		/// <param name="val" type="Number" integer="true">0 - tooltip appears in deferred mode 
		/// and does not appear in virtual. 1 - tooltip always appear, 
		/// 2 - tooltip never appears.</param>
		return this._set_value($IG.VirtualScrollingProps.TooltipVisibility, val);
	},
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.VirtualScrolling.dispose">
		/// Called by the framework when the behavior is being disposed of.
		/// </summary>
		if (this._onvscrollinitdelegate)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "VerticalScrollBarHeightInit", this._onvscrollinitdelegate);
			this._onvscrollinitdelegate = null;
			this._grid._gridUtil._unregisterEventListener(this._grid, "InitializingLayout", this._oninitinglayout);
			this._oninitinglayout = null;
			this._grid._gridUtil._unregisterEventListener(this._grid, "InitializedLayout", this._oninitedlayout);
			this._oninitedlayout = null;
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollTopChange", this._onscrolltopchange);
			this._onscrolltopchange = null;
			this._grid._gridUtil._unregisterEventListener(this._grid, "MouseWheel", this._onmousewheel);
			this._onmousewheel = null;
			this._grid._gridUtil._unregisterEventListener(this._grid, "Resize", this._onresize);
			this._onresize = null;
            this._grid._gridUtil._unregisterEventListener(this._grid, "TouchScrolledTop", this._ontouchscrolledtop);
			this._ontouchscrolledtop = null;

			this._onscrollbarstopped = null;
		}
		$IG.VirtualScrolling.callBaseMethod(this, "dispose");
	},

	_get_rowCacheOffsetIndex: function ()
	{
		return this._get_value($IG.VirtualScrollingProps.RowCacheOffsetIndex);
	},
	_set_rowCacheOffsetIndex: function (value)
	{
		this._set_value($IG.VirtualScrollingProps.RowCacheOffsetIndex, value);
	},

	_get_rowCacheSize: function ()
	{
		return this._get_value($IG.VirtualScrollingProps.RowCacheSize);
	},
	_set_rowCacheSize: function (value)
	{
		this._set_value($IG.VirtualScrollingProps.RowCacheSize, value);
	},
	_rowsLengh: function ()
	{
		return this._rows ? this._rows.get_length() : 0;
	},
	_get_averageRowHeight: function ()
	{
		return this._get_value($IG.VirtualScrollingProps.AverageRowHeight);
	},
	_set_averageRowHeight: function (value)
	{
	    
        if (this._get_averageRowHeight() > 0)
	        this._grid.set_scrollTop(this._grid.get_scrollTop() * value / this._get_averageRowHeight());
		this._set_value($IG.VirtualScrollingProps.AverageRowHeight, value);
	},

	_initializeComplete: function ()
	{
		$IG.VirtualScrolling.callBaseMethod(this, "_initializeComplete");
		this._paging = this._grid.get_behaviors().getBehaviorFromInterface($IG.IPagingBehavior);
		this._pagingOffset = 0;
		if (this._paging)
			this._pagingOffset = this._paging.get_pageIndex() * this._paging.get_pageSize();
	},

	_initLayout: function ()
	{
		var rowsElem = this._rowsElem;
		var rows = $util.getRows(rowsElem);
		if (rows && rowsElem.offsetHeight > 0 && rows.length > 0)
			this._set_averageRowHeight(rowsElem.offsetHeight / rows.length);
	},

	_cnt: function ()
	{
		return this._grid._container;
	},
	_vsb: function ()
	{
		return this._grid._vScrBar;
	},
	_initLayoutComplete: function ()
	{
		
		this._lastTop = this._vsb().scrollTop;
		var rowHeight = this._get_averageRowHeight(), height = this._cnt().offsetHeight;
		
		var size = Math.max(height / rowHeight * this.get_rowCacheFactor(), height / rowHeight + 3);
		if (this._get_rowCacheSize() < size)
			this._set_rowCacheSize(Math.ceil(size));
	},

	_onInitVerticalHeight: function (vsb)
	{		
		this._lastAverageRowHeightUsed = this._get_averageRowHeight();
		this._initPhase = (new Date()).getTime();
		var ht = 1000000, height = Math.ceil((this._recordCount + 1) * this._get_averageRowHeight() + this._grid._get_marginHeight());
		var div, i = -1, nodes = vsb.childNodes;
		
		
		while (!this._ie8Bug && ++i < nodes.length)
		{
			div = nodes[i];
			if (div.nodeName != 'DIV')
				continue;
			div.style.height = height + 'px';
			if (height > ht * 1.18 && div.style.height != height + 'px')
			{
				this._ie8Bug = 1;
				div.style.height = ht + 'px';
				while ((height -= ht) > 0)
				{
					div = document.createElement('DIV');
					div.style.height = Math.min(height, ht) + 'px';
					div.style.width = '1px';
					vsb.appendChild(div);
				}
			}
			break;
		}
		
		this._initScroll = vsb.scrollTop = this._grid.get_scrollTop();
		this._doGridTop(Math.floor(this._get_rowCacheOffsetIndex() * this._get_averageRowHeight()));
		return true;
	},
	_doGridTop: function (top)
	{
		
		
		var old = top;
		while (this._ie8Bug && top > 1000000)
			top -= 1000000;
		
		this._grid._scrollMinus = old - top;
		
		this._grid._marginTop = top;
		this._grid._elements.dataTbl.style.marginTop = top + 'px';
		this._grid._adjustScrollTop();
	},
	_onScrollTopChange: function ()
	{
		var init = this._initPhase, grid = this._grid, vsb = this._vsb();
		
		var scroll = this._initScroll, time = (new Date()).getTime();
		if ($util.IsOpera && init && init + 100 > time && scroll > 10 && vsb.scrollTop != scroll)
		{
			vsb.scrollTop = scroll;
			return;
		}
		delete this._initPhase;
		
		
		if (!grid || grid._posted || (grid._get_isAjaxCallInProgress && grid._get_isAjaxCallInProgress()))
			return true;
		var lock = this._lockScroll && time - this._lockScroll < 100;
		
		if (init && !this._scrollTimer && time < init + 300 && !lock)
			return;
		
		if (this._get_rowCacheOffsetIndex() == 0 && vsb.scrollTop == 0)
			return;
		
		if (lock)
		
			return true;
		if (this._scrollTimer)
			window.clearTimeout(this._scrollTimer);
		this._scrollTimer = window.setTimeout(this._onscrollbarstopped, this.get_dataFetchDelay());
		this._showTooltip(true);
		if (this.get_scrollingMode() == 0)
		{
			if (this._hasReachedThreshold())
			{
				grid.set_scrollTop(vsb.scrollTop);
				return true;
			}
		}
		else
		{
			grid.set_scrollTop(vsb.scrollTop);
			return true;
		}
	},

	_HScrollUpdate: function ()
	{
		if (this._hasReachedThreshold())
		{
			this._updateViewPort();
		}
	},

	_onMouseWheel: function ()
	{
		this._HScrollUpdate();
	},

    _onTouchScrolledTop: function ()
	{
		this._HScrollUpdate();
	},

	_onResize: function ()
	{
		
		//this._initLayout();
		this._initLayoutComplete();
		this._onScrollTopChange();
	},

	_scrollbarStopped: function ()
	{
		if (this._scrollTimer)
		{
			window.clearTimeout(this._scrollTimer);
			this._scrollTimer = null;
		}
		this._showTooltip(false);
		if (this.get_scrollingMode() == 0)
		{
			if (this._hasReachedThreshold())
				this._updateViewPort();
		}
		else
		{
			if (this._hasReachedThreshold())
				this._updateViewPort();
			else
				this._grid._adjustScrollTop();
		}
	},
	
	
	_doScroll: function (upDown)
	{
		
		if (this._grid._posted || this._scrollTimer)
			return;
		
		if (!this._hasReachedThreshold(upDown))
			return;
		var count = this._recordCount, row = this._oldIndex, range = this._oldRange;
		if (upDown == 1)
		{
			if (row < 1)
				return;
			if ((row -= range >> 1) < 0)
				row = 0;
		}
		else
		{
			if (row >= count)
				return;
			if ((row += range >> 1) > count - range)
				row = count - range;
		}
		return this._requestMoreRows(row, range);
	},

	
	_hasReachedThreshold: function (upDown)
	{
		if (!this._rowsElem)
			return false;
		var top = this._vsb().scrollTop;
		var first = this._get_rowCacheOffsetIndex();
		
		if (first == 0 && top == 0)
			return false;
		var rowHeight = this._get_averageRowHeight();
		
		var marginTop = parseInt(this._grid._elements.dataTbl.style.marginTop);
		if (isNaN(marginTop)) marginTop = 0;
		var topRow = Math.ceil(marginTop / rowHeight);
		
		var availRows = this._rowsLengh();
		
		var scrollRow = Math.ceil(top / rowHeight + 0.2);
		
		var visRows = Math.ceil(this._cnt().offsetHeight / rowHeight + 0.8);
		
		var factor = Math.floor(visRows * this.get_thresholdFactor());
		
		if (factor + factor >= visRows)
			factor = Math.floor(visRows / 2) - 1;
		
		if (factor < 1)
			factor = 1;
		
		if (first == 0 && topRow <= factor)
			topRow = 0;
		this._visRows = visRows;
		this._factor = factor;
		
		var up = topRow > 0 && topRow + factor > scrollRow;
		var down = topRow < this._recordCount - availRows && topRow + availRows < scrollRow + visRows + factor;
		
		if (upDown)
			return (upDown == 1 && up) || (upDown == 2 && down);
		return up || down;
	},
	
	
	_showTooltip: function (show, par)
	{
		var vis = this.get_tooltipVisibility(), tt = this._tooltip, vsb = this._vsb();
		if (par === true)
			this._fixedTT = true;
		if (this._fixedTT)
			show = true;
		
		if (vis > 1 || (vis < 1 && this.get_scrollingMode() == 0))
			if (show || !tt)
				return;
		if (!tt)
		{
			tt = this._tooltip = document.createElement('DIV');
			tt.style.position = 'absolute';
			tt.className = this.get_tooltipCssClass();
			
			vsb.parentNode.insertBefore(tt, vsb);
		}
		
		if (par == 2 && tt.offsetWidth == 0)
			return;
		tt.style.display = show ? '' : 'none';
		if (show)
		{
			var i = Math.floor(vsb.scrollTop / this._get_averageRowHeight() + 1.7 + this._pagingOffset);
			
			if (!par)
				window.setTimeout($util.createDelegate(this, this._showTooltip, [true, 2]), this.get_dataFetchDelay() >> 1);
			
			else if (this._ttIndex == i)
				return;
			
			this._ttIndex = i;
			
			
			var txt = '&nbsp;' + i + '&nbsp;';
			tt.innerHTML = txt;
			this.__raiseClientEvent("FormatToolTip", $IG.VirtualScrollingFormatToolTipEventArgs, [null, 0, i, txt, tt]);
			
			tt.style.marginLeft = -(tt.offsetWidth + 5) + 'px';
			
			
			var sbHeight = vsb.offsetHeight - 48;
			var top = sbHeight / (vsb.scrollHeight - sbHeight) * vsb.scrollTop;
			
			tt.style.marginTop = Math.floor(21 + top - tt.offsetHeight / 2) + 'px';
		}
	},

	_updateViewPort: function ()
	{
		
		this._initLayout();
		var avgHeight = this._get_averageRowHeight();
		var oldTopRow = this._get_rowCacheOffsetIndex();
		
		var rowsAll = this._recordCount;
		
		if (this._rowsLengh() >= rowsAll && oldTopRow == 0)
			return;
		var scrollTop = this._vsb().scrollTop;
		var viewPortHeight = this._cnt().offsetHeight;
		var newCacheSize = Math.ceil(viewPortHeight * this.get_rowCacheFactor() / avgHeight);
		var viewableRows = Math.ceil(viewPortHeight / avgHeight);
		
		newCacheSize = Math.max(newCacheSize, viewableRows + 3);
		var newTopRow = Math.floor(scrollTop / avgHeight - (newCacheSize - viewableRows) / 2);
		
		if (scrollTop < this._lastTop)
		{
			if (oldTopRow == 0)
				return;
			newTopRow = Math.min(newTopRow, oldTopRow - 1);
		}
		
		else if (scrollTop > this._lastTop)
			newTopRow = Math.max(newTopRow, oldTopRow + 1);
		
		
		
		this._lastTop = scrollTop;
		
		if (newTopRow + newCacheSize > rowsAll)
			newTopRow = rowsAll - newCacheSize;
		if (newTopRow < 0)
			newTopRow = 0;
		
		if (newCacheSize > 0)
			this._requestMoreRows(newTopRow, newCacheSize);
	},

	_requestMoreRows: function (topRowIndex, rowsRange)
	{
		
		if (this._oldIndex === topRowIndex && this._oldRange === rowsRange)
			return;
		
		this._oldIndex = topRowIndex;
		this._oldRange = rowsRange;
		var eventArgs = new $IG.CancelMoreRowsRequestingEventArgs(this, topRowIndex, rowsRange);
		this._get_owner()._raiseSenderClientEventStart(this, this._clientEvents["MoreRowsRequesting"], eventArgs);
		if (!eventArgs.get_cancel())
		{
			var action = new $IG.GridAction("MoreRows", this.get_name(), this, { "topRowIndex": topRowIndex, "rowsRange": rowsRange });
			this._get_owner()._actionList.add_transaction(action);
			this._get_owner()._raiseClientEventEnd(eventArgs);
			return true;
		}
	},

	_addReceivedMoreRowsEventHandler: function (handler)
	{
		/// <summary>
		/// Adds a listener to the ReceivedMoreRows event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
		this._grid._gridUtil._registerEventListener(this, "ReceivedMoreRows", handler);
	},

	
	_tempObj: null,
	_responseComplete: function (callbackObject, responseOptions)
	{
		var enableClientRendering = this._grid.get_enableClientRendering();

		if (!enableClientRendering && this._tempObj == null)
		{
			this._tempObj = document.createElement("DIV");
			this._tempObj.style.position = "absolute";
			this._tempObj.style.display = "none";
		}

		
		var oldTopIndex = this._get_rowCacheOffsetIndex();
		var oldCacheSize = this._get_rowCacheSize();
		
		var topIndex = responseOptions.vsIndex;
		if (typeof topIndex != 'number')
			topIndex = oldTopIndex;
		
		var cacheSize = responseOptions.vsSize;
		if (typeof cacheSize != 'number')
			cacheSize = oldCacheSize;
		
		this._set_rowCacheSize(cacheSize);

		if (!enableClientRendering)
		{
			
			this._tempObj.innerHTML = "<table style=\"table-layout:fixed;\">" + responseOptions.vsResponse.RowsHTML + "</table>";
			var newRows = this._tempObj.firstChild.firstChild;

			
			var oldRowCount = this._rowsElem ? this._rowsElem.rows.length : 0;
			for (var i = 0; i < oldRowCount; i++)
			{
				var oldRowObj = this._rows._element.rows[i]._object;
				if (oldRowObj)
				{
					this._grid._rows._rows[oldRowObj.get_index()] = null;
					this._grid._rows._keyIndexTree.remove(oldRowObj);
					oldRowObj.dispose();
				}
			}

			
			this._grid.get_rows()._set_length(cacheSize);

			
			if (this._rowsElem)
				this._rowsElem.parentNode.replaceChild(newRows, this._rowsElem);
			this._grid._elements["rows"] = this._rows._element = this._rowsElem = newRows;
		}
		else
		{
			this._grid.set_dataSource(responseOptions.vsData);
			this._grid._applyClientBinding(false);
		}

		
		this._set_rowCacheOffsetIndex(topIndex);
		
		var topPos = Math.floor(topIndex * this._get_averageRowHeight());
		var vsb = this._vsb();
		
		if (vsb.scrollTop != this._lastTop)
			vsb.scrollTop = this._lastTop;
		this._doGridTop(topPos);
		
		this._lockScroll = new Date().getTime();
		
		this._lastTop = vsb.scrollTop;

		if (!enableClientRendering)
		{
			
			var actBeh = this._owner.get_behaviors().getBehaviorByName('Activation');
			var cell = actBeh ? actBeh.get_activeCell() : null;
			if (cell)
			{
				var pair = cell.get_idPair();
				
				var actRow = oldTopIndex + pair.rowIDPair.index;
				
				cell = (actRow >= topIndex && actRow <= topIndex + cacheSize) ? this._rows.get_cellFromIDPair(pair) : null;
				actBeh.set_activeCell(cell);
			}
			
			var selBeh = this._owner.get_behaviors().getBehaviorByName('Selection');
			var cols = selBeh ? selBeh.get_selectedColumns() : null;
			if (cols)
				cols._repaintRows();
		}
		
		





		if ($util.IsIE9Plus)
			window.setTimeout(Function.createDelegate(this, this.__adjustVerticleScrollBar), 102);		
		
		
		this._grid._gridUtil._fireEvent(this, "ReceivedMoreRows");
		var evt = this._clientEvents['MoreRowsReceived'];
		if (evt && evt.fnc)
			this._get_owner()._raiseSenderClientEventStart(this, evt, new $IG.MoreRowsReceivedEventArgs(topIndex, cacheSize));
	},
	updateGridWithNewRows: function (firstVisibleRowIndex, rowCacheSize, dataSource)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrolling.updateGridWithNewRows">
		/// This method is to be used only if the EnableClientRendering property is set to true.
		/// It updates the grid with new rows retrieved during a scroll request and the virtual scrolling 
		/// behavior with a new row cache size and top row index.
		/// </summary>
		/// <param name="firstVisibleRowIndex" type="Number">The index of the top/first row that is present on the client.</param>
		/// <param name="rowCacheSize" type="Number">The number of rows present on the client.</param>
		/// <param name="dataSource" type="Number">The dataSource containing the grid's rows, Json array only, generated at the 
		/// client or retrieved as a result from Ajax anabled web service call.</param>

		
		var oldTopIndex = this._get_rowCacheOffsetIndex();
		var oldCacheSize = this._get_rowCacheSize();
		
		var topIndex = firstVisibleRowIndex;
		if (typeof topIndex != 'number')
			topIndex = oldTopIndex;
		
		var cacheSize = rowCacheSize;
		if (typeof cacheSize != 'number')
			cacheSize = oldCacheSize;

		
		this._set_rowCacheSize(cacheSize);

		
		this._grid.get_rows()._set_length(cacheSize);

		
		this._set_rowCacheOffsetIndex(topIndex);
		
		var topPos = Math.floor(topIndex * this._get_averageRowHeight());

		this._grid.set_dataSource(dataSource);
		this._grid.applyClientBinding();

		var vsb = this._vsb();
		
		if (vsb.scrollTop != this._lastTop)
			vsb.scrollTop = this._lastTop;
		this._doGridTop(topPos);
		
		this._lockScroll = new Date().getTime();
		
		this._lastTop = vsb.scrollTop;
		
		this._grid._gridUtil._fireEvent(this, "ReceivedMoreRows");
		
	},
	__adjustVerticleScrollBar: function ()
	{
		if ($util.IsIE9Plus && Math.abs(this._get_averageRowHeight() - this._lastAverageRowHeightUsed) > .5)
			this._owner._onDataTblResize({ "clientHeight": this._owner._elements.dataTbl.clientHeight }, null);
	}
}

$IG.VirtualScrolling.registerClass('Infragistics.Web.UI.VirtualScrolling', $IG.GridBehavior);


$IG.VirtualScrollingProps = new function()
{
	var count = $IG.GridBehaviorProps.Count;
	this.DataFetchDelay = [count++, 500];
	this.TooltipCssClass = [count++, ""];
	this.RowCacheOffsetIndex = [count++, 0];
	this.RowCacheSize = [count++, 0];
	this.AverageRowHeight = [count++, 20];
	this.TooltipVisibility = [count++, 0];
	this.Count = count;
};



$IG.CancelMoreRowsRequestingEventArgs = function(virtualScrolling, topRowIndex, rowsRange)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelMoreRowsRequestingEventArgs">
	///Event arguments object passed into the more rows requesting event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelMoreRowsRequestingEventArgs.initializeBase(this, [virtualScrolling]);
	this._topRowIndex = topRowIndex;
	this._rowsRange = rowsRange;
}
$IG.CancelMoreRowsRequestingEventArgs.prototype =
{
	get_topRowIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelMoreRowsRequestingEventArgs.topRowIndex">
		/// Returns top index of the rows that are being requested.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._topRowIndex;
	},

	get_rowsRange: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelMoreRowsRequestingEventArgs.rowsRange">
		/// Returns number of rows being requested from the server.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._rowsRange;
	}
}
$IG.CancelMoreRowsRequestingEventArgs.registerClass('Infragistics.Web.UI.CancelMoreRowsRequestingEventArgs', $IG.CancelBehaviorEventArgs);



$IG.MoreRowsReceivedEventArgs = function(topRowIndex, rowsRange)
{
	///<summary locid="T:J#Infragistics.Web.UI.MoreRowsReceivedEventArgs">
	///Event arguments object passed into event raised after rows were received from server.
	///</summary>
	$IG.MoreRowsReceivedEventArgs.initializeBase(this);
	
	this._props[2] = topRowIndex;
	this._props[3] = rowsRange;
}
$IG.MoreRowsReceivedEventArgs.prototype =
{
	get_topRowIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MoreRowsReceivedEventArgs.topRowIndex">
		/// Returns top index of the row received from server.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._props[2];
	},
	get_rowsRange: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MoreRowsReceivedEventArgs.rowsRange">
		/// Returns number of rows received from server.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._props[3];
	}
}
$IG.MoreRowsReceivedEventArgs.registerClass('Infragistics.Web.UI.MoreRowsReceivedEventArgs', $IG.EventArgs);



$IG.VirtualScrollingFormatToolTipEventArgs = function(props)
{
	///<summary locid="T:J#Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs">
	///Event arguments object passed into event raised before display tooltip.
	///</summary>
	$IG.VirtualScrollingFormatToolTipEventArgs.initializeBase(this);
	this._props = props;
}
$IG.VirtualScrollingFormatToolTipEventArgs.prototype =
{
	
	get_element: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs.element">
		/// Gets reference to html element which is used for tooltip.
		/// </summary>
		/// <returns domElement="true">Reference to DIV element</returns>
		return this._props[4];
	},
	
	get_rowIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs.rowIndex">
		/// Gets index of the row for tooltip.
		/// </summary>
		/// <value type="Number" integer="true">Index of row.</value>
		return this._props[2];
	},
	
	get_text: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs.text">
		/// Gets text for tooltip.
		/// </summary>
		/// <value type="String">Suggested text.</value>
		return this._props[3];
	},
	
	set_text: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs.text">
		/// Sets text for tooltip. That is used to set innerHTML of DIV, so, it can contain html tags.
		/// </summary>
		/// <param name="val" type="String">Text for tooptip.</param>
		this._props[4].innerHTML = this._props[3] = val;
	}
}
$IG.VirtualScrollingFormatToolTipEventArgs.registerClass('Infragistics.Web.UI.VirtualScrollingFormatToolTipEventArgs', $IG.EventArgs);


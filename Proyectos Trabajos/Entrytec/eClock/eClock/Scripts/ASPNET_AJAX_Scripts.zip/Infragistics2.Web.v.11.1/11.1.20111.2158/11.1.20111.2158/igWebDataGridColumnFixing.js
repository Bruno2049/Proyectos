/*
* igWebDataGridColumnFixing.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/




$IG.IColumnFixingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IColumnFixingBehavior">
	///Interface that identifies the column fixing behavior.
	///</summary>
};

$IG.IColumnFixingBehavior.prototype =
{
	get_headerRegions: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IColumnFixingBehavior.headerRegions">
		/// Returns a two dimentional array.  The first dimention contains the regions that 
		/// the WebDataGrid header is devided into and the second dimention contains all the TH
		/// elements in that region.
		/// </summary>
	}
};

$IG.IColumnFixingBehavior.registerInterface("Infragistics.Web.UI.IColumnFixingBehavior");




$IG.ColumnFixing = function (obj, objProps, control, parentCollection)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnFixing">
	///Column fixing behavior for the WebDataGrid.
	///</summary>	
	$IG.ColumnFixing.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._grid = this._owner;

	this._get_cellElementByIndexHandler = Function.createDelegate(this, this._get_cellElementByIndex);
	this._grid._gridUtil._registerEventListener(this._grid, "GetCellElementByIndex", this._get_cellElementByIndexHandler);

	
	
	this._getGridCellFromElementHandler = this._grid._gridUtil._getGridCellFromElement;
	this._grid._gridUtil._getGridCellFromElement = Function.createDelegate(this, this._getGridCellFromElement);

	this._getCellIndexFromElemHandler = this._grid._gridUtil.getCellIndexFromElem;
	this._grid._gridUtil.getCellIndexFromElem = Function.createDelegate(this, this.getCellIndexFromElem);

	this._findRowIndexByCellElemHandler = this._grid._gridUtil.findRowIndexByCellElem;
	this._grid._gridUtil.findRowIndexByCellElem = Function.createDelegate(this, this.findRowIndexByCellElem);

	this._scrollCellIntoViewIEHandler = this._grid._gridUtil.scrollCellIntoViewIE;
	this._grid._gridUtil.scrollCellIntoViewIE = Function.createDelegate(this, this.scrollCellIntoViewIE);



	if (!$util.IsIE && !$util.IsSafari)
	{
		var className = this._get_clientOnlyValue("sdcc");
		if (className)
			this._scrollStyleSheet = this._getStyleSheet(className);
	}

	this._initScrollDivs();

	
	this._headerRegions = [];

	
	this._fixedColumns = [];
	this.__initializeFixedColumns();

	this.__initializeColumnWidthCssClasses();
	this._fixButtons = control._elements["fixBtn"];
	if (this._fixButtons && !this._fixButtons.length)
	{
		var fixBtn = this._fixButtons;
		this._fixButtons = [];
		this._fixButtons[0] = fixBtn;
	}
	this._fixButtonsObjs = [];

	this._autoAdjustCells = this._get_clientOnlyValue("cfach");
	this._leftFixedCount = this._get_clientOnlyValue("leftC");
	this._rightFixedCount = this._get_clientOnlyValue("rightC");
	this._unfixedCount = this._grid.get_columns().get_length() - this._leftFixedCount - this._rightFixedCount;

	this._leftSeparator = control._elements["lftSeparator"];
	this._rightSeparator = control._elements["rhtSeparator"];

	var stopperStylClassName = this._get_clientOnlyValue("fcscc");
	if (stopperStylClassName)
		this._stopperStyleCss = this._getStyleSheet(stopperStylClassName);
	className = this._get_clientOnlyValue("fcthscc");
	if (className)
		this._captionStopperStyleCss = this._getStyleSheet(className);

	this._checkScrollDivsInitialized();	

	this._onImgMouseOverHandler = Function.createDelegate(this, this._onImgMouseOver);
	this._onImgMouseOutHandler = Function.createDelegate(this, this._onImgMouseOut);
	this._onImgMouseDownHandler = Function.createDelegate(this, this._onImgMouseDown);
	this._onImgMouseClickHandler = Function.createDelegate(this, this._onImgMouseClick);
	for (var i = 0; this._fixButtons && this._fixButtons.length && i < this._fixButtons.length; i++)
	{
		$addHandler(this._fixButtons[i], 'mouseover', this._onImgMouseOverHandler);
		$addHandler(this._fixButtons[i], 'mouseout', this._onImgMouseOutHandler);
		$addHandler(this._fixButtons[i], 'mousedown', this._onImgMouseDownHandler);
		$addHandler(this._fixButtons[i], 'click', this._onImgMouseClickHandler);
	}

	this._onShowHorizontalScrollBarHandler = Function.createDelegate(this, this._onShowHorizontalScrollBar);
	this._grid._gridUtil._registerEventListener(this._grid, "ShowHorizontalScrollBar", this._onShowHorizontalScrollBarHandler);

	this._onHorizontalScrollBarWidthInitHandler = Function.createDelegate(this, this._onHorizontalScrollBarWidthInit);
	this._grid._gridUtil._registerEventListener(this._grid, "HorizontalScrollBarWidthInit", this._onHorizontalScrollBarWidthInitHandler);

	this._onGridScrollLeftChangeHandler = Function.createDelegate(this, this._onGridScrolled);
	this._grid._gridUtil._registerEventListener(this._grid, "ScrollLeftChange", this._onGridScrollLeftChangeHandler);

	this._onGridTouchScrollingLeftHandler = Function.createDelegate(this, this._onGridTouchScrollingLeft);
	this._grid._gridUtil._registerEventListener(this._grid, "TouchScrollingLeft", this._onGridTouchScrollingLeftHandler);


	this._onGridCScrollLeftChangeHandler = Function.createDelegate(this, this._onGridCScrollLeft);
	this._grid._gridUtil._registerEventListener(this._grid, "CScrollLeftChange", this._onGridCScrollLeftChangeHandler);

	this._onAlignFooterHandler = Function.createDelegate(this, this._onAlignFooter);
	this._grid._gridUtil._registerEventListener(this._grid, "AlignFooter", this._onAlignFooterHandler);

	this._onAlignStatCaptionHandler = Function.createDelegate(this, this._onAlignStatCaption);
	this._grid._gridUtil._registerEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);

	this._onInitializedLayoutHandler = Function.createDelegate(this, this._initializedLayout);
	this._grid._gridUtil._registerEventListener(this._grid, "InitializedLayout", this._onInitializedLayoutHandler);

	this._onResizeHandler = Function.createDelegate(this, this._resizeSeparators);
	this._grid._gridUtil._registerEventListener(this._grid, "Resize", this._onResizeHandler);

	this._onAsyncRenderingHandler = Function.createDelegate(this, this._onAsyncRendering);
	this._grid._gridUtil._registerEventListener(this._grid, "AsyncRendering", this._onAsyncRenderingHandler);

	this._onSetColumnWidthHandler = Function.createDelegate(this, this._onSetColumnWidth);
	this._grid._gridUtil._registerEventListener(this._grid, "SetColumnWidth", this._onSetColumnWidthHandler);

	this._onCellContentChangedHandler = Function.createDelegate(this, this._onCellContentChanged);
	this._grid._gridUtil._registerEventListener(this._grid, "CellContentChanged", this._onCellContentChangedHandler);

	this._onFilterCellEnteringEditHandler = Function.createDelegate(this, this._onFilterCellEnteringEdit);
	this._grid._gridUtil._registerEventListener(this._grid, "FilterCellEnteringEdit", this._onFilterCellEnteringEditHandler);

	this._onHiddenColumnHander = Function.createDelegate(this, this._onHiddenColumn);
	this._grid._gridUtil._registerEventListener(this._grid, "HideColumn", this._onHiddenColumnHander);

	if (this._grid.get_enableClientRendering())
	{
		this._onDataBoundHandler = Function.createDelegate(this, this._onDataBound);
		this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
	}
}

$IG.ColumnFixing.prototype =
{
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the Column Fixing behavior removes all the event handlers that it
		/// had attached.
		/// </summary>
		if (!this._grid)
			return;

		this._grid._gridUtil._unregisterEventListener(this._grid, "GetCellElementByIndex", this._get_cellElementByIndexHandler);
		delete this._get_cellElementByIndexHandler;

		
		this._grid._gridUtil._getGridCellFromElement = this._getGridCellFromElementHandler;
		delete this._getGridCellFromElementHandler;

		this._grid._gridUtil.getCellIndexFromElem = this._getCellIndexFromElemHandler;
		delete this._getCellIndexFromElemHandler;

		this._grid._gridUtil.findRowIndexByCellElem = this._findRowIndexByCellElemHandler;
		delete this._findRowIndexByCellElemHandler;

		this._grid._gridUtil.scrollCellIntoViewIE = this._scrollCellIntoViewIEHandler;
		delete this._scrollCellIntoViewIEHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "ShowHorizontalScrollBar", this._onShowHorizontalScrollBarHandler);
		delete this._onShowHorizontalScrollBarHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "HorizontalScrollBarWidthInit", this._onHorizontalScrollBarWidthInitHandler);
		delete this._onHorizontalScrollBarWidthInitHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollLeftChange", this._onGridScrollLeftChangeHandler);
		delete this._onGridScrollLeftChangeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "TouchScrollingLeft", this._onGridTouchScrollingLeftHandler);
		delete this._onGridTouchScrollingLeftHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "CScrollLeftChange", this._onGridCScrollLeftChangeHandler);
		delete this._onGridCScrollLeftChangeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AlignFooter", this._onAlignFooterHandler);
		delete this._onAlignFooterHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);
		delete this._onAlignStatCaptionHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "InitializedLayout", this._onInitializedLayoutHandler);
		delete this._onInitializedLayoutHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "Resize", this._onResizeHandler);
		delete this._onResizeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AsyncRendering", this._onAsyncRenderingHandler);
		delete this._onAsyncRenderingHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "SetColumnWidth", this._onSetColumnWidthHandler);
		delete this._onSetColumnWidthHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "CellContentChanged", this._onCellContentChangedHandler);
		delete this._onCellContentChangedHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "FilterCellEnteringEdit", this._onFilterCellEnteringEditHandler);
		delete this._onFilterCellEnteringEditHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "HideColumn", this._onHiddenColumnHander);
		delete this._onHiddenColumnHander;

		if (this._grid.get_enableClientRendering())
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
			delete this._onDataBoundHandler;
		}

		if (this._activation)
		{
			this._grid._gridUtil._unregisterEventListener(this._activation, "AddingActiveRowCssClass", this._addingActiveRowCssClassHandler);
			delete this._addingActiveRowCssClassHandler;

			this._grid._gridUtil._unregisterEventListener(this._activation, "RemovingActiveRowCssClass", this._removingActiveRowCssClassHandler);
			delete this._removingActiveRowCssClassHandler;

			this._grid._gridUtil._unregisterEventListener(this._grid, "KeyDown", this._onKeyDownHandler);
			delete this._onKeyDownHandler;
			delete this._activation;
		}
		if (this._columnResizing)
			delete this._columnResizing;
		if (this._virtualScrolling)
			delete this._virtualScrolling;
		delete this._cellEditing;
		delete this._rowAdding;
		delete this._editingCore;
		delete this._summaryRow;
		delete this._filtering;

		for (var i = 0; this._fixButtons && this._fixButtons.length && i < this._fixButtons.length; i++)
		{
			$removeHandler(this._fixButtons[i], 'mouseover', this._onImgMouseOverHandler);
			$removeHandler(this._fixButtons[i], 'mouseout', this._onImgMouseOutHandler);
			$removeHandler(this._fixButtons[i], 'mousedown', this._onImgMouseDownHandler);
			$removeHandler(this._fixButtons[i], 'click', this._onImgMouseClickHandler);
		}
		delete this._onImgMouseOverHandler;
		delete this._onImgMouseOutHandler;
		delete this._onImgMouseDownHandler;
		delete this._onImgMouseClickHandler;

		for (var i = 0; i < this._fixedColumns.length; i++)
			this._fixedColumns[i].dispose();

		delete this._enteringEditModeHandler;
		delete this._fixedColumns;
		delete this._fixButtons;
		delete this._fixButtonsObjs;
		delete this._headerRegions;

		this._columnSettings.dispose();
		delete this._columnSettings;

		delete this._scrollDivs;
		delete this._scrollStyleSheet;

		delete this._autoAdjustCells;
		delete this._leftFixedCount;
		delete this._rightFixedCount;
		delete this._unfixedCount;

		delete this._leftSeparator;
		delete this._rightSeparator;
		
		delete this._leftSeparatorFooter;
		delete this._rightSeparatorFooter;

		delete this._stopperStyleCss;
		delete this._captionStopperStyleCss;
		delete this._grid;

		$IG.ColumnFixing.callBaseMethod(this, "dispose");


	},

	
	get_headerRegions: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.headerRegions">
		/// Returns a two dimentional array.  The first dimention contains the regions that 
		/// the WebDataGrid header is devided into and the second dimention contains all the TH
		/// elements in that region.
		/// </summary>
		return this._headerRegions;
	},
	


	

	
	get_columnSettings: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSettings">
		/// Gets the column fixing settings collection
		/// </summary>
		/// <returns type="ObjectCollection">column fixing settings collection </returns>
		return this._columnSettings;
	},
	

	get_columnSetting: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSetting">
		/// Gets the column fixing setting object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <returns type="ColumnFixingSettings">The column fixing setting at the specified index</returns>
		if (index >= 0 && index < this._columnSettings._items.length)
			return this._columnSettings._items[index];
		else
			return null;
	},

	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSettingFromKey">
		/// Gets the column fixing setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column fixing setting is tied to.
		///</param>
		/// <returns type="ColumnFixingSettings">The column fixing setting tied to the specified column key</returns>

		for (var i = 0; i < this._columnSettings._items.length; i++)
		{
			if (this._columnSettings._items[i].get_columnKey() === columnKey)
				return this._columnSettings._items[i];
		}

		return null;
	},
	


	
	get_fixedColumns: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixedColumns">
		/// Returns an array with the columns that are currently fixed.
		/// </summary>
		/// <returns type="Array">An array of FixedColumnInfo objects. </returns>
		return this._fixedColumns;
	},

	getFixedColumnFromKey: function (key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.getFixedColumnFromKey">
		/// Returns the fixed column for the specified column key.
		/// </summary>
		///<param name="key" type="String"  optional="false" mayBeNull="false">
		/// The column key of the fixed column.
		///</param>
		/// <returns type="$IG.FixedColumnInfo">The fixed column object for the given key.  
		/// Null will be returned if the column is not found. </returns>

		for (var i = 0; i < this._fixedColumns.length; i++)
		{
			if (this._fixedColumns[i].get_column().get_key() == key)
				return this._fixedColumns[i];
		}
		return null;
	},

	containsFixedColumnByKey: function (key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.containsFixedColumnByKey">
		/// Returns the true/false based on whether the column associated with the given key is currently fixed..
		/// </summary>
		/// <param name="key" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column.
		/// </param>
		/// <returns type="boolean">True is the column is currently fixed, false otherwise. </returns>

		for (var i = 0; i < this._fixedColumns.length; i++)
		{
			if (this._fixedColumns[i].get_column().get_key() == key)
				return true;
		}
		return false;
	},

	createFixedColumnObj: function (column, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.createFixedColumnObj">
		///	Creates a $IG.FixedColumnInfo object for the given column.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column for which to create a $IG.FixedColumnInfo object.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, $IG.FixedColumnInfo will be created with the given fix location,
		/// if not there than the $IG.FixedColumnInfo object will be created to the fix location specified in settings or behavior default
		/// </param>

		if (!column)
			return null;
		fixLocation = this._determineFixLocation(column.get_key(), fixLocation);

		return new $IG.FixedColumnInfo(column, fixLocation);
	},
	

	
	get_autoAdjustCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.autoAdjustCells">
		/// Gets the setting for whether the cell height of the unfixed columns needs to be kept
		/// in sync with the cell height of the fixed columns.		
		/// </summary>
		/// <returns type="boolean">True - adjust cell height. False - do not adjust cell height. </returns>

		return this._autoAdjustCells;
	},

	get_fixLocation: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixLocation">
		/// Gets the direction to which all columns are fixed to unless otherwise specified in the 
		/// ColumnSetting object for the column
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the columns will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the columns will be fixed to the right edge of the grid
		/// </returns>

		return this._get_value($IG.GridColumnFixingProps.FixLocation);
	},
	set_fixLocation: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixLocation">
		/// Sets direction to which all columns are fixed to unless otherwise specified in the 
		/// ColumnSetting object for the column
		/// </summary>
		/// <param name="value" type="$IG.FixLocation"  optional="false" mayBeNull="false">
		/// $IG.FixLocation.Left - the columns will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the columns will be fixed to the right edge of the grid
		/// </param>

		if (value == $IG.FixLocation.Left || value == $IG.FixLocation.Right)
			this._set_value($IG.GridColumnFixingProps.FixLocation, value);
	},
	get_fixButtonAlignment: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixButtonAlignment">
		/// Indicate whether the fix button/pin is located to the left or to the right of the header caption.
		/// </summary>
		/// <returns type="$IG.HeaderButtonAlignment">Location of the button.</returns>

		return this._get_clientOnlyValue("cfbtna");
	},

	get_leftFixedCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.leftFixedCount">
		/// The number of columns that are currently fixed to the left
		/// edge of the grid.
		/// </summary>
		/// <returns type="Integer">Count.</returns>

		return this._leftFixedCount;
	},

	get_rightFixedCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.rightFixedCount">
		/// The number of columns that are currently fixed to the right
		/// edge of the grid.
		/// </summary>
		/// <returns type="Integer">Count.</returns>

		return this._rightFixedCount;
	},

	

	

	fixColumn: function (column, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumn">
		/// Fixes the given column, if the column settings allow.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column to be fixed.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (column && column.get_key() && this._grid.get_columns().get_columnFromKey(column.get_key()))
			this._fixColumn(column.get_key(), fixLocation);

	},

	fixColumnByKey: function (columnKey, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnByKey">
		/// Fixes the column associated with the given column key, if the column settings allow.
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column that is to be fixed.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (this._grid.get_columns().get_columnFromKey(columnKey))
			this._fixColumn(columnKey, fixLocation);
	},

	fixColumnByIndex: function (columnIndex, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnByIndex">
		/// Fixes the column associated with the given index, if the column settings allow.
		/// </summary>
		/// <param name="columnIndex" type="Integer"  optional="false" mayBeNull="false">
		/// The column index of the column in the columns collection that is to be fixed.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (columnIndex > -1 && columnIndex < this._grid.get_columns().get_length())
			this._fixColumn(this._grid.get_columns().get_column(columnIndex).get_key(), fixLocation);
	},

	fixColumnRange: function (columnKeys)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnRange">
		/// Fixes the columns associated with the given column keys, if the column settings allow.
		/// </summary>
		/// <param name="columnKeys" type="Array"  optional="false" mayBeNull="false">
		/// An array of Strings, which are the column keys associated to the columns that will be fixed.
		/// </param>

		if (columnKeys && columnKeys.length)
		{
			var colInfo = [];
			for (var i = 0; i < columnKeys.length; i++)
			{
				if (this._grid.get_columns().get_columnFromKey(columnKeys[i]))
					colInfo[colInfo.length] = this.__createTransportableFixedColumnObj(columnKeys[i], this._determineFixLocation(columnKeys[i], null));
			}

			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	fixColumnObjRange: function (fixedColumns)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnObjRange">
		/// Fixes the given columns, if the column settings allow.
		/// </summary>
		/// <param name="fixedColumns" type="Array"  optional="false" mayBeNull="false">
		/// An array of $IG.FixedColumnInfo objects (these should be created with the createFixedColumnObj method of Column Fixing behavior).
		/// </param>

		if (fixedColumns && fixedColumns.length)
		{
			var colInfo = [];
			for (var i = 0; i < fixedColumns.length; i++)
			{
				if (fixedColumns[i] && fixedColumns[i].get_column() && fixedColumns[i].get_column().get_key())
				{
					var columnKey = fixedColumns[i].get_column().get_key();
					if (this._grid.get_columns().get_columnFromKey(columnKey))
						colInfo[colInfo.length] = this.__createTransportableFixedColumnObj(columnKey, this._determineFixLocation(columnKey, fixedColumns[i].get_fixLocation()));
				}
			}

			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	unfixColumn: function (column)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumn">
		/// Unfixes the given column, if the column is currently fixed.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column to be unfixed.
		/// </param>

		if (column && column.get_key())
			this._unfixColumn(column.get_key());
	},

	unfixColumnByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnByKey">
		/// Unfixes the column associated with the given column key, if the column is currently fixed.
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column that is to be unfixed.
		/// </param>

		if (columnKey)
			this._unfixColumn(columnKey);

	},
	unfixColumnByIndex: function (columnIndex)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnByIndex">
		/// Unfixes the column associated with the given index, if the column is currently fixed.
		/// </summary>
		/// <param name="columnIndex" type="Integer"  optional="false" mayBeNull="false">
		/// The column index of the column in the columns collection that is to be unfixed.
		/// </param>

		if (columnIndex > -1 && columnIndex < this._grid.get_columns().get_length())
			this._unfixColumn(this._grid.get_columns().get_column(columnIndex).get_key());
	},

	unfixColumnRange: function (columnKeys)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnRange">
		/// Unfixes the columns associated with the given column keys, if the columns are currently fixed.
		/// </summary>
		/// <param name="columnKeys" type="Array"  optional="false" mayBeNull="false">
		/// An array of Strings, which are the column keys associated to the columns that will be unfixed.
		/// </param>

		if (columnKeys)
		{
			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("UnfixColumnManual", this.get_name(), this._grid, columnKeys, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	adjustUnfixedCellHeight: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.adjustUnfixedCellHeight">
		/// Adjusts the cell height of the unfixed columns so they are kept
		/// in sync with the cell height of the fixed columns.
		/// </summary>

		if (this.__unfixedCellHeightTimer)
			return;
		this.__unfixedCellHeightTimer = window.setTimeout(Function.createDelegate(this, this.__onUnfixedHeightTimerExpire), 100);

		tableRows = (this._grid._elements.rows) ? this._grid._elements.rows.childNodes : null;
		if (tableRows)
		{
			var index = (tableRows.length && tableRows.length > 0) ? this.__findColsSpanIndex(tableRows[0]) : null;
			if (index != null)
			{
				var operaResizeNeeded = false;
				for (var i = 0; i < tableRows.length; i++)
				{
					var tableRow = tableRows[i];
					if (tableRow.tagName != "TR")
						continue;
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
					{
						operaResizeNeeded = true;
						if ($util.IsIEStandards || ($util.IsOpera && !this.get_autoAdjustCells()))
							divElement.firstChild.style.height = "";
						divElement.style.height = height + "px";
						if ($util.IsIEStandards || ($util.IsOpera && !this.get_autoAdjustCells()))
							setTimeout($util.createDelegate(this, this._adjustIE8Opera, [divElement.firstChild]), 0);
					}
				}
				if ($util.IsOpera && !this.get_autoAdjustCells() && operaResizeNeeded)
					setTimeout($util.createDelegate(this, this._forceGridResize), 0);
			}
		}
	},
	

	
	_initScrollDivs: function ()
	{
		this._scrollDivs = this._grid._elements["unfixedDiv"];
		
		if (this._scrollDivs == null || this._scrollDivs == undefined)
			this._scrollDivs = [];
		else if (this._scrollDivs.length === undefined || this._scrollDivs.tagName)
			this._scrollDivs = [ this._scrollDivs ];

		var cellDivs = this._grid._elements.dataTbl.getElementsByTagName('div');

		if (this._grid.get_enableClientRendering())
		{
			var numOfunfixedDivs = 0;
			for (var i = 0; i < cellDivs.length; i++)
			{
				var cellDiv = cellDivs[i];
				$util._initAttr(cellDiv);
				if (cellDiv.getAttribute("mkr") == "unfixedDiv")
				{
					cellDiv.id = cellDiv.id + numOfunfixedDivs.toString();
					this._scrollDivs[this._scrollDivs.length] = cellDiv;
					
					if (numOfunfixedDivs % 2 != 0)
						$(cellDiv.firstChild.firstChild.firstChild).addClass(this._grid._get_clientOnlyValue("rac"));
					numOfunfixedDivs++;
				}
			}
		}
	},
	_checkScrollDivsInitialized: function ()
	{
		

		if (!this._scrollDivs && this._stopperStyleCss)
		{
			var row = this._grid._rows.get_row(0);
			if (row)
			{
				var rowElem = row.get_element();
				var i = 0;
				var stopperStylClassName = this._get_clientOnlyValue("fcscc");
				var stopperClassName = this._getClassNameOnly(stopperStylClassName);
				while (!this._scrollDivs && rowElem && i < rowElem.childNodes.length)
				{
					var cell = rowElem.childNodes[i];
					if (cell.className.indexOf(stopperClassName) != -1 && cell.firstChild && cell.firstChild.tagName == "DIV" &&
					cell.firstChild.id.indexOf("mkr:unfixedDiv") != -1)
					{
						this._scrollDivs = cell.firstChild;
					}
					i++;
				}
			}
		}
	},
	_onDataBound: function (args)
	{
		this._initScrollDivs();
		this._checkScrollDivsInitialized();
		if (this._grid._hScrBar)
			this._onGridScrolled();
	},
	_onHiddenColumn: function (evnt)
	{
		if ($util.IsOpera)
			setTimeout($util.createDelegate(this, this._forceGridResize), 0);
	},
	_adjustIE8Opera: function (table)
	{
		table.style.height = "100%";
	},
	_onSetColumnWidth: function (eventArgs)
	{
		eventArgs.cancel = true;
		var column = eventArgs.column;
		var columnWidth = eventArgs.width;

		
		if (column._headerElement)
			column._headerElement.style.width = columnWidth;
		if (column._footerElement)
			column._footerElement.style.width = columnWidth;
		if (this._grid.get_rows().get_length() > 0)
		{
			var rowZero = this._grid.get_rows().get_row(0);

			var cellElmenet = rowZero.get_cellByColumn(column).get_element();
			cellElmenet.style.width = columnWidth;
			if (this.__isUnfixedTD(cellElmenet))
			{
				var tdStyle = this._getStyleSheet(column._columnWidthCssClass);
				tdStyle.width = columnWidth;
			}
		}

		this._owner._onResize({ "clientHeight": this._grid._element.clientHeight }, false);

	},
	_onAsyncRendering: function (eventArgs)
	{
		var element = eventArgs.gridElement;
		var newElement = eventArgs.newElement.firstChild;
		var tableElement = eventArgs.tableElement;

		
		if (this._leftSeparator)
		{
			element.removeChild(this._leftSeparator);
			if ($util.IsIE)
				this._leftSeparator.removeNode();
			delete this._leftSeparator;
		}

		if (this._rightSeparator)
		{
			element.removeChild(this._rightSeparator);
			if ($util.IsIE)
				this._rightSeparator.removeNode();
			delete this._rightSeparator;
		}


		while (newElement && !(newElement.tagName == "TABLE" && newElement.id.indexOf("outerTbl")))
		{
			var nextNewElement = newElement.nextSibling;
			if (newElement.id.indexOf("lftSeparator") || newElement.id.indexOf("rhtSeparator"))
			{
				if (tableElement)
					element.insertBefore(newElement, tableElement);
				else
					element.appendChild(newElement);
			}
			newElement = nextNewElement;
		}
	},
	_fixColumn: function (columnKey, fixLocation)
	{
		var columnSetting = this.get_columnSettingFromKey(columnKey);

		if (!columnSetting || (columnSetting && columnSetting.get_enabled()))
		{
			fixLocation = this._determineFixLocation(columnKey, fixLocation);

			if (this._doesColumnNeedFixing(columnKey, fixLocation))
			{
				var colInfo = this.__createTransportableFixedColumnObj(columnKey, fixLocation);
				var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
				this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
				this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},

	_unfixColumn: function (columnKey)
	{
		if (this._doesColumnNeedUnfixing(columnKey))
		{
			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("UnfixColumnManual", this.get_name(), this._grid, columnKey, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	_doesColumnNeedFixing: function (columnKey, fixLocation)
	{
		var fixedCol = this.getFixedColumnFromKey(columnKey);
		if (!fixedCol || fixedCol.get_fixLocation() != fixLocation)
			return true;
		else
			return false;
	},

	_doesColumnNeedUnfixing: function (columnKey)
	{
		if (this.getFixedColumnFromKey(columnKey))
			return true;
		else
			return false;
	},

	_get_fixButtonObject: function (column, elem)
	{
		var key = column.get_key();
		if (this._fixButtonsObjs[key] == null)
		{
			if (this.getFixedColumnFromKey(key))
				this._fixButtonsObjs[key] = new $IG.ImageObject("fixBtn", elem, this._objectManager.get_objectProps(1), this);
			else
				this._fixButtonsObjs[key] = new $IG.ImageObject("fixBtn", elem, this._objectManager.get_objectProps(0), this);

			var altTxt = this._fixButtonsObjs[key]._get_clientOnlyValue("altTxt");
			

			altTxt = (altTxt ? altTxt : "");
			var btnElement = this._fixButtonsObjs[key].get_element();
			if (btnElement && column.get_headerElement())
			{
				var formatedAltTxt = String.format(altTxt, column.get_headerText());
				btnElement.alt = formatedAltTxt;
				btnElement.title = formatedAltTxt;
			}
		}
		return this._fixButtonsObjs[key];
	},

	_onImgMouseOver: function (evnt)
	{
		$util.cancelEvent(evnt);
		var column = (evnt.target && evnt.target.parentNode) ? this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode) : null;
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Hover);
		}
	},

	_onImgMouseOut: function (evnt)
	{
		$util.cancelEvent(evnt);
		var column = (evnt.target && evnt.target.parentNode) ? this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode) : null;
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Normal);
		}
	},

	_onImgMouseDown: function (evnt)
	{
		$util.cancelEvent(evnt);
		var column = (evnt.target && evnt.target.parentNode) ? this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode) : null;
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Pressed);
		}
	},

	_onImgMouseClick: function (evnt)
	{
		$util.cancelEvent(evnt);
		var column = (evnt.target && evnt.target.parentNode) ? this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode) : null;
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Normal);
			this.__changeFixState(column);
		}
	},

	__changeFixState: function (column, byKeyboard)
	{
		if (column)
		{
			var fixedColumn = this.getFixedColumnFromKey(column.get_key());
			var fixed = (fixedColumn) ? true : false;
			fixedColumn = (fixedColumn) ? fixedColumn : this.createFixedColumnObj(column);

			fixedColumn = new $IG.ClientFixedColumnInfo(fixedColumn.get_column(), fixedColumn.get_fixLocation());

			var eventArgs = new $IG.FixingEventArgs(this, fixedColumn, fixed);
			this._owner._raiseSenderClientEventStart(this, this._clientEvents["FixedStateChanging"], eventArgs);
			if (!eventArgs.get_cancel())
			{
				var fixedColumnInfo = this.__createTransportableFixedColumnObj(fixedColumn.get_column().get_key(), fixedColumn.get_fixLocation());

				var noPost = (eventArgs._props[1] == 2);
				this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumn", this.get_name(), this._grid, fixedColumnInfo, (byKeyboard ? true : null)));
				if (!noPost)
					this._owner._postAction(1);
				else
					this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},

	_onKeyDown: function (event)
	{
		if (event.ctrlKey && event.shiftKey && event.keyCode == 70)
		{
			if (this._cellEditing && this._cellEditing.get_cellInEditMode())
				return false;
			var cell = this._activation.get_activeCell();
			if (cell)
				this.__changeFixState(cell.get_column(), true);
			return true;
		}
	},

	_determineFixLocation: function (columnKey, fixLocation)
	{
		var columnSetting = this.get_columnSettingFromKey(columnKey);
		if (fixLocation != $IG.FixLocation.Left && fixLocation != $IG.FixLocation.Right)
			fixLocation = (!columnSetting) ? this.get_fixLocation() : columnSetting.get_fixLocation();

		return fixLocation;
	},

	_onGridCScrollLeft: function (evntArgs)
	{
		evntArgs.containerScrollLeft = this._grid.get_scrollLeft();
	},
	_onGridScrolled: function (evnt)
	{
		this._grid._ignoreCScroll = true;
		var scroll = (this._grid._hScrBar.offsetHeight > 0) ? this._grid._hScrBar.scrollLeft : this._grid.get_scrollLeft();

		if ($util.IsIE || $util.IsSafari)
		{
			

			if (this._scrollDivs && !this._scrollDivs.length)
				this._scrollDivs.scrollLeft = scroll;

			for (var i = 0; this._scrollDivs && i < this._scrollDivs.length; i++)
				this._scrollDivs[i].scrollLeft = scroll;
		}
		else
		{
			this._scrollStyleSheet.left = (-scroll) + "px";
		}

		
		if (this._grid._cellInEditMode)
		{
			if (this._cellEditing && this._cellEditing.get_cellInEditMode())
				this._cellEditing._forceExitEditMode();
			else if (this._rowAdding && this._rowAdding.get_cellInEditMode())
				this._rowAdding._forceExitEditMode();
			else if (this._filtering && this._filtering.get_cellInEditMode())
				this._filtering._forceExitEditMode();
		}
		this._grid.set_scrollLeft(scroll);
		
		this._grid._gridUtil._fireEvent(this._grid, "ScrollLeftChanged");
		delete this._grid._ignoreCScroll;

		
		return true;
	},

	_onGridTouchScrollingLeft: function (evnt)
	{
		if ($util.IsIE || $util.IsSafari)
		{
			if (this._scrollDivs && !this._scrollDivs.length)
				this._scrollDivs.scrollLeft += evnt.deltaScrollLeft;

			for (var i = 0; this._scrollDivs && i < this._scrollDivs.length; i++)
				this._scrollDivs[i].scrollLeft += evnt.deltaScrollLeft;
		}
		else
		{
			var pxIndex = this._scrollStyleSheet.left.indexOf("px");
			var currentScroll = -parseInt(this._scrollStyleSheet.left.substring(0, pxIndex));
			var scroll = currentScroll + evnt.deltaScrollLeft;

			this._scrollStyleSheet.left = (-scroll) + "px";
		}

		
		return true;
	},

	_onScrolledCellIntoView: function (args)
	{
		var cell = args.cell;
		var elem = cell.get_element();
		args.cancel = true;

		if ($util.IsIE || $util.IsOpera || $util.IsSafari)
		{
			this._grid._gridUtil.scrollCellIntoViewIE(cell);
		}
		else
		{
			


			if ($util.IsFireFox && this._grid._notifyBehaviorTData)
				this._grid._notifyBehaviorTData._onTick();

			if (this.__isUnfixedTD(elem))
			{
				var pxIndex = this._scrollStyleSheet.left.indexOf("px");
				var originalScroll = -parseInt(this._scrollStyleSheet.left.substring(0, pxIndex));
				var currentStyleScroll = originalScroll;
				var div = elem.parentNode.parentNode.parentNode.parentNode;

				if (originalScroll != div.scrollLeft)
				{
					currentStyleScroll = 0;
					this._scrollStyleSheet.left = "0px";
					div.scrollLeft = originalScroll;

				}

				elem.focus();
				var currentDivScroll = div.scrollLeft;
				div.scrollLeft = 0;

				if (currentStyleScroll != currentDivScroll)
				{
					this._grid._hScrBar.scrollLeft = currentDivScroll;
					this._onGridScrolled();
				}
				
				else if (currentStyleScroll == currentDivScroll && currentStyleScroll != originalScroll)
					this._grid._hScrBar.scrollLeft = currentDivScroll;

			}
			else
			{
				
				if (elem)
					elem.focus();
			}

		}
	},

	_onHorizontalScrollBarWidthInit: function (scrollBar)
	{
		var scrollDiv = null;
		if (this._grid._rows.get_length() < 1)
			scrollDiv = this.__getFirstScrollDiv();
		else
		{
			var row = this._grid._rows.get_row(0).get_element();
			index = this.__findColsSpanIndex(row);
			if (index != null && index > -1 && index < row.childNodes.length)
				scrollDiv = row.childNodes[index].firstChild;
		}
		if (scrollDiv)
		{
			scrollBar.firstChild.style.width = scrollBar.clientWidth + (scrollDiv.firstChild.clientWidth - scrollDiv.clientWidth) + "px";
			scrollBar.scrollLeft = this._grid.get_scrollLeft();
			var result = this._onGridScrolled();

		}

		return true;
	},

	_onShowHorizontalScrollBar: function (event)
	{
		var scrollDiv = null;
		if (this._grid._rows.get_length() < 1)
			scrollDiv = this.__getFirstScrollDiv();
		else
		{
			var row = this._grid._rows.get_row(0).get_element();
			index = this.__findColsSpanIndex(row);
			if (index != null && index > -1 && index < row.childNodes.length)
				scrollDiv = row.childNodes[index].firstChild;
		}

		if (scrollDiv)
		{
			event.scrollBar.style.display = ((event.scrollContainer.offsetWidth + (scrollDiv.firstChild.clientWidth - scrollDiv.clientWidth)) > event.container.offsetWidth ? "" : "none");
			return true;
		}
		return false;
	},

	_initializedLayout: function ()
	{
		if (!this._grid._header && !this._grid._footer)
			this.__createSpaceForSeparators();
		this._resizeSeparators();

		var fixedByKeyboard = this._get_clientOnlyValue("fByKey");
		if (this._activation && fixedByKeyboard && this._activation.get_activeCell())
			this._activation.__focusCell(this._activation.get_activeCell());
	},

	_adjustUnfixedCaptionsHeight: function ()
	{
		var headerContent = this._grid._elements.headerContent;
		var headerRows = (headerContent && headerContent.firstChild) ? headerContent.firstChild.childNodes : null;

		var footerContent = this._grid._elements.footerContent;
		var footerRows = (footerContent && footerContent.firstChild) ? footerContent.firstChild.childNodes : null;

		var index = null;
		if (headerRows && headerRows.length && headerRows.length > 0)
		{
			index = this.__findColsSpanIndex(headerRows[0]);
			if (index != null)
			{
				for (var i = 0; i < headerRows.length; i++)
				{
					var tableRow = headerRows[i];
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
						divElement.style.height = height + "px";
				}
			}
		}
		if (footerRows && footerRows.length && footerRows.length > 0)
		{
			if (index == null)
				index = this.__findColsSpanIndex(footerRows[0]);

			if (index != null)
			{
				for (var i = 0; i < footerRows.length; i++)
				{
					var tableRow = footerRows[i];

					if (this._summaryRow && tableRow.getAttribute("mkr") == "capSumRow")
						continue;
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
						divElement.style.height = height + "px";
				}
			}
		}
	},

	_resizeSeparators: function ()
	{
		var scrollDiv = this.__getFirstScrollDiv();
		if (scrollDiv)
		{
			var contentTbl = this._grid._elements["contentTbl"];
			var gridMainDiv = this._grid.get_element();
			var leftEdge = gridMainDiv.offsetLeft;
			var rightEdge = gridMainDiv.offsetLeft + gridMainDiv.clientWidth;
			rightEdge -= this._grid._vScrBar ? this._grid._determineScrollbarWidth() : 0;

			var emptyRowTemplate = this._get_clientOnlyValue("hasEmptyRT");
			if (this._leftSeparator)
			{
				var height;
				if (emptyRowTemplate)
				{
					height = this._grid._headingArea.offsetHeight;
					
					if (!this._leftSeparatorFooter && this._grid._footer)
					{
						this._leftSeparatorFooter = this._leftSeparator.cloneNode(true);
						this._leftSeparatorFooter.id = this._leftSeparatorFooter.id + "Footer";
						this._leftSeparator.parentNode.insertBefore(this._leftSeparatorFooter, this._leftSeparator);
						this._leftSeparatorFooter.setAttribute("mkr", "lftSeparatorFooter");
					}
				}
				else
					height = contentTbl.clientHeight;

				var marginLeft = scrollDiv.parentNode.offsetLeft;

				if (marginLeft < leftEdge || marginLeft > rightEdge)
				{
					this._leftSeparator.style.height = "0px";
					this._leftSeparator.style.marginLeft = "0px";

					
					if (this._leftSeparatorFooter)
					{
						this._leftSeparatorFooter.style.height = "0px";
						this._leftSeparatorFooter.style.marginLeft = "0px";
					}
				}
				else
				{
					this._leftSeparator.style.height = height + "px";
					this._leftSeparator.style.marginTop = contentTbl.parentNode.offsetTop + "px";
					this._leftSeparator.style.marginLeft = marginLeft + "px";

					
					if (this._leftSeparatorFooter)
					{
						this._leftSeparatorFooter.style.height = this._grid._footingArea.offsetHeight + "px";
						this._leftSeparatorFooter.style.marginTop = this._grid._footingArea.offsetTop + "px";
						this._leftSeparatorFooter.style.marginLeft = marginLeft + "px";
					}
				}

			}
			if (this._rightSeparator)
			{

				var height;
				if (emptyRowTemplate)
				{
					height = this._grid._headingArea.offsetHeight;

					
					if (!this._rightSeparatorFooter && this._grid._footer)
					{
						this._rightSeparatorFooter = this._rightSeparator.cloneNode(true);
						this._rightSeparatorFooter.id = this._rightSeparatorFooter.id + "Footer";
						this._rightSeparator.parentNode.insertBefore(this._rightSeparatorFooter, this._rightSeparator);
						this._rightSeparatorFooter.setAttribute("mkr", "rhtSeparatorFooter");
					}
				}
				else
					height = contentTbl.clientHeight;

				var cell = scrollDiv.parentNode;
				var marginLeft = cell.offsetLeft + cell.clientWidth - this._rightSeparator.clientWidth;
				if (marginLeft < leftEdge || marginLeft > rightEdge)
				{
					this._rightSeparator.style.height = "0px";
					this._rightSeparator.style.marginLeft = "0px";

					
					if (this._rightSeparatorFooter)
					{
						this._rightSeparatorFooter.style.height = "0px";
						this._rightSeparatorFooter.style.marginLeft = "0px";
					}

				}
				else
				{
					this._rightSeparator.style.height = height + "px";
					this._rightSeparator.style.marginLeft = marginLeft + "px";
					this._rightSeparator.style.marginTop = contentTbl.parentNode.offsetTop + "px";

					
					if (this._rightSeparatorFooter)
					{
						this._rightSeparatorFooter.style.height = this._grid._footingArea.offsetHeight + "px";
						this._rightSeparatorFooter.style.marginTop = this._grid._footingArea.offsetTop + "px";
						this._rightSeparatorFooter.style.marginLeft = marginLeft + "px";
					}
				}
			}
		}
	},

	_onAlignFooter: function ()
	{
		var headerContent = this._grid._elements["headerContent"];
		var footerContent = this._grid._elements["footerContent"];
		var headerRows = $util.getRows(headerContent);
		var headerRow = (headerRows && headerRows.length) ? headerRows[0] : null;
		var footerRows = $util.getRows(footerContent);

		var existingTableWidth;
		if (this._grid._elements.dataTbl)
		{
			var dataTblStyle = this._grid._elements.dataTbl.style;
			existingTableWidth = dataTblStyle.width;

			if (headerContent)
			{
				if (headerContent.style.tableLayout != "fixed")
					headerContent.style.tableLayout = "fixed";
				if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
					headerContent.style.width = dataTblStyle.width;
			}
			if (footerContent)
			{
				if (footerContent.style.tableLayout != "fixed")
					footerContent.style.tableLayout = "fixed";
				if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
					footerContent.style.width = dataTblStyle.width;
			}
		}

		if (headerRow)
		{
			for (var i = 1; i < headerRows.length; i++)
			{
				var captions = headerRows[i].childNodes;

				this.__alignPixeledStatCaption(headerRow.childNodes, captions, existingTableWidth, true);
				this.__alignNonePixeledStatCaption(headerRow.childNodes, captions);
			}

			for (var i = 0; footerRows && i < footerRows.length; i++)
			{
				var captions = footerRows[i].childNodes;

				this.__alignPixeledStatCaption(headerRow.childNodes, captions, existingTableWidth, true);
				this.__alignNonePixeledStatCaption(headerRow.childNodes, captions);
			}
		}
		else if (footerRows && footerRows.length > 1)
		{
			var footerRow = footerRows[footerRows.length - 1];
			for (var i = 0; i < footerRows.length - 1; i++)
			{
				var captions = footerRows[i].childNodes;

				this.__alignPixeledStatCaption(footerRow.childNodes, captions, existingTableWidth, true);
				this.__alignNonePixeledStatCaption(footerRow.childNodes, captions);
			}
		}
		return true;

	},

	_onAlignStatCaption: function (eventArgs)
	{
		var captionProperty = eventArgs.captionProperty;
		var capElem = this._grid._elements[captionProperty];
		if (capElem.style.tableLayout != "fixed")
			capElem.style.tableLayout = "fixed";

		var existingTableWidth;
		if (this._grid._elements.dataTbl)
		{
			var dataTblStyle = this._grid._elements.dataTbl.style;
			existingTableWidth = dataTblStyle.width;
			if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
			{
				capElem.style.width = dataTblStyle.width;
			}
		}

		this.__createSpaceForSeparators();

		var row = this._grid._rows.get_row(0);
		if (row)
		{
			var rowElem = row.get_element();

			var rows = $util.getRows(capElem);
			for (var i = 0; rows && i < rows.length; i++)
			{
				var captions = rows[i].childNodes;

				this.__alignPixeledStatCaption(rowElem.childNodes, captions, existingTableWidth);
				this.__alignNonePixeledStatCaption(rowElem.childNodes, captions);
			}

			if (this.get_autoAdjustCells())
				this.adjustUnfixedCellHeight();
			this._adjustUnfixedCaptionsHeight();
		}

		this._resizeSeparators();
		return true;

	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.ColumnFixingSettings, null, columnKey);

	},

	_createObjects: function (objectManager)
	{
		this._objectManager = objectManager;
		this._objectManager.__createdObjectCount = 0;

		$IG.ColumnFixing.callBaseMethod(this, "_createObjects", [objectManager]);
	},

	_onCellContentChanged: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		if (!this.__isUnfixedTD(cellElement))
		{
			var row = evntArgs.cell.get_row().get_element();
			var index = (row) ? this.__findColsSpanIndex(row) : null;
			if (index)
			{
				var cell = row.childNodes[index];
				var divElement = cell.firstChild;
				if (divElement.style.height != "")
					divElement.style.height = "";

				divElement.firstChild.style.height = "";
				setTimeout($util.createDelegate(this, this._setDivElementHeight, [divElement, row]), 0);
			}
		}
	},

	_setDivElementHeight: function (divElement, row)
	{
		var height = row.offsetHeight;
		if (height != divElement.clientHeight)
			divElement.style.height = height + "px";
		divElement.firstChild.style.height = "100%";

	},

	_enteringEditMode: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		var parentCell = this.__getColSpanTDFromUnfixedCell(cellElement);
		if (parentCell)
		{
			var leftBounds = parentCell.offsetLeft;
			var rightBounds = null;
			if (this._rightSeparator)
			{
				var pxIndex = this._rightSeparator.style.marginLeft.indexOf("px");
				if (pxIndex > -1)
					rightBounds = parseInt(this._rightSeparator.style.marginLeft.substring(0, pxIndex));
			}
			if (rightBounds == null)
			{
				rightBounds = leftBounds + parentCell.clientWidth;
				var pd = $util.getStyleValue(null, "paddingRight", parentCell);
				pd = parseInt(pd);
				if (!isNaN(pd))
					rightBounds -= pd;
			}

			var paddingLeft = $util.getStyleValue(null, "paddingLeft", parentCell);
			paddingLeft = parseInt(paddingLeft);

			
			if (!isNaN(paddingLeft))
				leftBounds += paddingLeft;

			var width = cellElement.offsetWidth;

			var left = cellElement.offsetLeft + parentCell.offsetLeft;
			
			if ($util.IsIE)
				left += parentCell.firstChild.offsetLeft - parentCell.firstChild.scrollLeft;
			else if ($util.IsSafari || $util.IsChrome)
				left -= parentCell.firstChild.scrollLeft;
			else
			{
				left += parentCell.firstChild.firstChild.offsetLeft;
				

			}

			if (left < leftBounds)
			{
				width -= (leftBounds - left);
				evntArgs.customDisplay.leftCutOff = leftBounds - left;
				left = leftBounds;
			}
			if (left + width > rightBounds)
				width += rightBounds - (left + width);

			evntArgs.customDisplay.left = left;
			evntArgs.customDisplay.width = width;
			evntArgs.customDisplay.top = parentCell.parentNode.offsetTop + cellElement.parentNode.offsetTop;
		}

	},

	_onFilterCellEnteringEdit: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		var parentCell = this.__getColSpanTDFromUnfixedCell(cellElement);
		if (parentCell)
		{
			var cfDisplayOption = { cancel: null, top: null, left: null, height: null, width: null, text: null };
			var cfArgs = { cell: evntArgs.cell, customDisplay: cfDisplayOption };
			this._enteringEditMode(cfArgs);

			var leftDif = cellElement.offsetLeft - evntArgs.customDisplay.left;
			var widthDif = cellElement.offsetWidth - evntArgs.customDisplay.width;

			if (cfArgs.customDisplay.leftCutOff)
			{
				if (cfArgs.customDisplay.leftCutOff >= Math.abs(leftDif))
				{
					leftDif = 0;
					widthDif = 0;
				}
				else
				{
					leftDif += cfArgs.customDisplay.leftCutOff;
					widthDif -= cfArgs.customDisplay.leftCutOff;
				}
			}

			evntArgs.customDisplay.left = cfArgs.customDisplay.left - leftDif;
			evntArgs.customDisplay.width = cfArgs.customDisplay.width - widthDif;
			evntArgs.customDisplay.top = cfArgs.customDisplay.top;

		}
	},

	_getClassNameOnly: function (name)
	{
		var nameAr = name.split(".");
		if (nameAr.length > 2)
			return null;
		else if (nameAr.length == 2)
			return nameAr[1];
		else
			return name;
	},
	_getStyleSheet: function (name)
	{
		return $util.getStyleSheet(name);
	},

	_registerEnteringEditHandlerForBehaviors: function (behaviors)
	{
		if (!behaviors)
			return;
		for (var i = 0; i < behaviors._behaviors.length; i++)
		{
			var behavior = behaviors._behaviors[i];
			if (behavior)
			{
				//check and add
				if ($IG.GridEditBase && $IG.GridEditBase.isInstanceOfType(behavior) && (!$IG.Filtering || !$IG.Filtering.isInstanceOfType(behavior)))
					behavior._addEnteringEditEventListener(this._enteringEditModeHandler);

				if ($IG.IGridBehaviorContainer.isInstanceOfType(behavior))
				{
					var subBehCollection = behavior.get_behaviors();
					if (subBehCollection)
						this._registerEnteringEditHandlerForBehaviors(subBehCollection);
				}
			}
		}
	},

	_addingActiveRowCssClass: function (eventArgs)
	{
		if (eventArgs.row)
		{
			var rowElem = eventArgs.row.get_element();
			var index = rowElem ? this.__findColsSpanIndex(rowElem) : null;
			if (index != null)
			{
				var unfixedCells = this.__getUnfixedCellsFromTd(rowElem.childNodes[index]);
				if (unfixedCells && unfixedCells[0].parentNode)
					$util.addCompoundClass(unfixedCells[0].parentNode, eventArgs.cssClass);
			}
		}
	},
	_removingActiveRowCssClass: function (eventArgs)
	{
		if (eventArgs.row)
		{
			var rowElem = eventArgs.row.get_element();
			var index = rowElem ? this.__findColsSpanIndex(rowElem) : null;
			if (index != null)
			{
				var unfixedCells = this.__getUnfixedCellsFromTd(rowElem.childNodes[index]);
				if (unfixedCells && unfixedCells[0].parentNode)
					$util.removeCompoundClass(unfixedCells[0].parentNode, eventArgs.cssClass);
			}
		}
	},
	_initializeComplete: function ()
	{
		this._enteringEditModeHandler = Function.createDelegate(this, this._enteringEditMode);
		this._registerEnteringEditHandlerForBehaviors(this._grid.get_behaviors());

		this._activation = this._grid.get_behaviors().get_activation();
		if (this._activation)
		{
			this._addingActiveRowCssClassHandler = Function.createDelegate(this, this._addingActiveRowCssClass);
			this._grid._gridUtil._registerEventListener(this._activation, "AddingActiveRowCssClass", this._addingActiveRowCssClassHandler);

			this._removingActiveRowCssClassHandler = Function.createDelegate(this, this._removingActiveRowCssClass);
			this._grid._gridUtil._registerEventListener(this._activation, "RemovingActiveRowCssClass", this._removingActiveRowCssClassHandler);

			this._activation._addScrolledCellIntoViewEventHandler(Function.createDelegate(this, this._onScrolledCellIntoView));
			this._onKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
			this._grid._gridUtil._registerEventListener(this._grid, "KeyDown", this._onKeyDownHandler);
		}
		this._columnResizing = this._grid.get_behaviors().get_columnResizing();
		if (this._columnResizing)
			this._columnResizing._rebalanceContainerWidths = Function.createDelegate(this, this._rebalanceContainerWidths);
		this._virtualScrolling = this._grid.get_behaviors().get_virtualScrolling();
		if (this._virtualScrolling)
			this._virtualScrolling._addReceivedMoreRowsEventHandler(Function.createDelegate(this, this._onReceivedMoreRows));

		this._editingCore = this._grid.get_behaviors().get_editingCore();
		if (this._editingCore)
		{
			this._cellEditing = this._editingCore.get_behaviors().get_cellEditing();
			this._rowAdding = this._editingCore.get_behaviors().get_rowAdding();
		}

		this._summaryRow = this._grid.get_behaviors().get_summaryRow();
		this._filtering = this._grid.get_behaviors().get_filtering();

		

		if ($util.IsSafari)
			setTimeout(Function.createDelegate(this, this._forceGridResize), 0);

		
		var affectedColKey = this._get_clientOnlyValue("fscKey");
		if (affectedColKey && affectedColKey != "" && this._clientEvents["FixedStateChanged"])
		{
			var column = this._grid.get_columns().get_columnFromKey(affectedColKey);
			if (column)
			{
				var direction = this._get_clientOnlyValue("fscDir");
				var isFixed = this._get_clientOnlyValue("fscFixed");
				this._grid._raiseSenderClientEvent(this, this._clientEvents['FixedStateChanged'], new $IG.FixedEvenArgs(this.createFixedColumnObj(column, direction), isFixed));
			}
		}
	},

	

	_forceGridResize: function ()
	{
		this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
	},

	_onReceivedMoreRows: function ()
	{
		if ($util.IsIE || $util.IsSafari)
		{
			var rows = this._grid._elements["rows"];
			delete this._grid._elements["rows"];
			this._grid.__walkThrough(rows, false);
			this._scrollDivs = this._grid._elements["unfixedDiv"];
		}
		this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
	},

	

	
	__createSpaceForSeparators: function ()
	{
		try
		{
			if (this._leftSeparator && this._stopperStyleCss)
			{
				this._stopperStyleCss.paddingLeft = (this._leftFixedCount ? this._leftSeparator.clientWidth : 0) + "px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingLeft = (this._leftFixedCount ? this._leftSeparator.clientWidth : 0) + "px";
			}
			else if (this._stopperStyleCss && this._stopperStyleCss.paddingLeft != "0px")
			{
				this._stopperStyleCss.paddingLeft = "0px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingLeft = "0px";
			}

			if (this._rightSeparator && this._stopperStyleCss)
			{
				this._stopperStyleCss.paddingRight = this._rightSeparator.clientWidth + "px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingRight = this._rightSeparator.clientWidth + "px";
			}
			else if (this._stopperStyleCss && this._stopperStyleCss.paddingRight != "0px")
			{
				this._stopperStyleCss.paddingRight = "0px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingRight = "0px";
			}
		}
		catch (e)
		{
		}
	},

	__getFirstScrollDiv: function ()
	{
		if (!this._scrollDivs)
			return null;
		
		return (this._scrollDivs.length != undefined ? this._scrollDivs[0] : this._scrollDivs);
	},

	__createTransportableFixedColumnObj: function (columnKey, fixLocation)
	{
		var info = new Object();
		info.columnKey = columnKey;
		info.fixLocation = fixLocation;
		return info;
	},

	__initializeFixedColumns: function ()
	{
		var fixedCols = this._get_value($IG.GridColumnFixingProps.FixedColumns);
		if (fixedCols)
		{
			for (var i = 0; i < fixedCols.length; i++)
			{
				var column = this._owner._columns.get_columnFromKey(fixedCols[i][0]);
				column._fixedDirection = fixedCols[i][1];
				this._fixedColumns[this._fixedColumns.length] = new $IG.FixedColumnInfo(column, column._fixedDirection);

			}
		}
	},

	__initializeColumnWidthCssClasses: function ()
	{
		var gridCols = this._owner.get_columns();
		var midRegion = [];
		var leftRegion = [];
		var rightRegion = [];
		var defaultColWidth = this._owner.get_defaultColumnWidth();
		for (var i = 0; i < gridCols.get_length(); i++)
		{
			var column = gridCols.get_column(i);
			var className = this._get_clientOnlyValue(column._key + "_cw");
			if (className)
			{
				column._columnWidthCssClass = className;
				var columnStyle = this._getStyleSheet(className);
				if (columnStyle)
				{
					if (column.get_width() != "" && columnStyle.width != column.get_width())
						columnStyle.width = column.get_width();
					else if (column.get_width() == "" && columnStyle.width != defaultColWidth)
						columnStyle.width = defaultColWidth;
				}
			}

			if (column._fixedDirection == $IG.FixLocation.Left)
				leftRegion[leftRegion.length] = column.get_headerElement();
			else if (column._fixedDirection == $IG.FixLocation.Right)
				rightRegion[rightRegion.length] = column.get_headerElement();
			else
				midRegion[midRegion.length] = column.get_headerElement();
		}
		if (leftRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = leftRegion;
		if (midRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = midRegion;
		if (rightRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = rightRegion;
	},

	__unfixedCellHeightTimer: null,
	__onUnfixedHeightTimerExpire: function ()
	{
		this.__unfixedCellHeightTimer = null;
	},

	__findColsSpanIndex: function (row)
	{
		for (var i = this._grid._get_cellIndexOffset(); i < row.childNodes.length; i++)
		{
			var cell = row.childNodes[i];
			if (cell && cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || cell.firstChild.id.indexOf("mkr:unfixedDiv") != -1))
			{
				return i;
			}
		}
		return null;
	},

	__alignPixeledStatCaption: function (cells, captionCells, existingTableWidth, reverse)
	{

		for (var i = 0; i < cells.length; i++)
		{
			var cell = cells[i];
			var caption;
			if (cell.style.width != "" && cell.style.width.indexOf("%") < 0 && cell.offsetWidth > 0)
			{
				

				var pxIndex = cell.style.width.indexOf("px");
				if (pxIndex > -1 && existingTableWidth)
				{
					var neededWidth = parseInt(cell.style.width.substring(0, pxIndex));
					if (!isNaN(neededWidth))
					{
						cell.style.width = neededWidth + 1 + "px";
						cell.style.width = neededWidth + "px";
					}
				}

				caption = (captionCells && captionCells.length && i < captionCells.length) ? captionCells[i] : null;
				if (caption)
				{
					$util.setAbsoluteWidth(caption, cell.offsetWidth);
				}
			}
			

			else
			{
				caption = (captionCells && captionCells.length && i < captionCells.length) ? captionCells[i] : null;
				if (caption)
					caption.style.width = "";
			}

			var unfixedCells = reverse ? this.__getUnfixedCellsFromTh(cell) : this.__getUnfixedCellsFromTd(cell);

			
			if (unfixedCells)
			{
				var unfixedCaption = this.__getUnfixedCellsFromTh(caption);
				
				if (unfixedCaption == null)
					unfixedCaption = this.__getUnfixedCellsFromTd(caption);
				this.__alignPixeledStatCaption(unfixedCells, unfixedCaption, existingTableWidth, reverse);
			}
		}

	},

	__alignNonePixeledStatCaption: function (cells, captionCells, reverse)
	{
		for (var i = 0; i < cells.length; i++)
		{
			var cell = cells[i];
			var caption;
			if ((cell.style.width == "" && !this.__isColSpanForUnfixedCols(cell)) || cell.style.width.indexOf("%") > -1 && cell.offsetWidth > 0)
			{
				caption = caption = (captionCells && captionCells.length && i < captionCells.length) ? captionCells[i] : null;

				if (caption)
				{
					$util.setAbsoluteWidth(caption, cell.offsetWidth);
				}
			}

			var unfixedCells = reverse ? this.__getUnfixedCellsFromTh(cell) : this.__getUnfixedCellsFromTd(cell);

			
			if (unfixedCells)
			{
				var unfixedCaption = this.__getUnfixedCellsFromTh(caption);
				
				if (unfixedCaption == null)
					unfixedCaption = this.__getUnfixedCellsFromTd(caption);
				this.__alignNonePixeledStatCaption(unfixedCells, unfixedCaption, reverse);
			}
		}
	},

	__isColSpanTDForUnfixedCols: function (cell)
	{
		if (cell && cell.tagName == "TD" && this.__isColSpanForUnfixedCols(cell))
			return true;
		else
			return false;
	},
	__isColSpanTHForUnfixedCols: function (cell)
	{
		if (cell && cell.tagName == "TH" && this.__isColSpanForUnfixedCols(cell))
			return true;
		else
			return false;
	},
	__isColSpanForUnfixedCols: function (cell)
	{
		if (cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || cell.firstChild.id.indexOf("mkr:unfixedDiv") != -1))
			return true;
		else
			return false;
	},
	__isUnfixedTD: function (elem)
	{
		if (elem && elem.tagName == "TD" && elem.parentNode && elem.parentNode.parentNode && elem.parentNode.parentNode.parentNode &&
			elem.parentNode.parentNode.parentNode.parentNode &&
			elem.parentNode.parentNode.parentNode.parentNode.tagName == "DIV" &&
			(elem.parentNode.parentNode.parentNode.parentNode.getAttribute("mkr") == "unfixedDiv" ||
				elem.parentNode.parentNode.parentNode.parentNode.id.indexOf("mkr:unfixedDiv") != -1))
			return true;
		else
			return false;
	},
	__getUnfixedCellsFromTd: function (cell)
	{
		if (this.__isColSpanTDForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0].childNodes;
		return null;
	},
	__getTRElemForUnfixedCellsFromSpanTd: function (cell)
	{
		if (this.__isColSpanTDForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0];
		return null;
	},
	__getUnfixedCellsFromTh: function (cell)
	{
		if (this.__isColSpanTHForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0].childNodes;
		return null;
	},

	__getColSpanTDFromUnfixedCell: function (cell)
	{
		if (this.__isUnfixedTD(cell))
			return cell.parentNode.parentNode.parentNode.parentNode.parentNode;
		return null;
	},
	

	
	_rebalanceContainerWidths: function ()
	{

	},
	findRowIndexByCellElem: function (elem)
	{
		if (this.__isUnfixedTD(elem))
			elem = elem.parentNode.parentNode.parentNode.parentNode.parentNode;

		var obj = $util.resolveMarkedElement(elem.parentNode);
		if (obj)
		{
			var type = obj[0].getAttribute("type");
			if (type == "row")
				return obj[1];
		}
		return null;
	},

	_getGridCellFromElement: function (element)
	{
		if (this.__isUnfixedTD(element))
			return element;
		else
		{
			while (element && (element.tagName != "TD" && element.tagName != "TH" || element.parentNode.id.indexOf("adr") == -1 && element.parentNode.getAttribute("adr") === null)) //TH for row selectors
				element = element.parentNode;
			return element;
		}
	},

	_get_cellElementByIndex: function (args)
	{
		args.cancel = true;
		var row = args.rowElement;
		var index = args.index;

		args.cellElement = this.__get_cellElementByIndex(row, index);
	},

	__get_cellElementByIndex: function (row, index)
	{
		var i = this._grid._get_cellIndexOffset();
		var j = i;
		var oldI = null;
		var oldRow = row;
		do
		{
			
			if (i >= row.childNodes.length && oldI != null)
			{
				i = oldI;
				oldI = null;
				row = oldRow;
			}
			var cell = row.childNodes[i];

			if (cell && cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || cell.firstChild.id.indexOf("mkr:unfixedDiv") != -1))
			{
				oldI = i + 1;
				i = 0;
				row = cell.firstChild.firstChild.rows[0];
			}
			else
			{
				j++;
				i++;
			}
		}
		while (j <= index);

		return row.childNodes[i - 1];
	},

	getCellIndexFromElem: function (elem)
	{
		var spanTd = null;
		if (this.__isUnfixedTD(elem))
			spanTd = elem.parentNode.parentNode.parentNode.parentNode.parentNode;
		if (spanTd)
			return this._grid._gridUtil.getCellIndex(spanTd) + this._grid._gridUtil.getCellIndex(elem) - this._grid._get_cellIndexOffset();
		else
		{
			var indexWithoutOffset = this._grid._gridUtil.getCellIndex(elem) - this._grid._get_cellIndexOffset();
			if (indexWithoutOffset < this._leftFixedCount)
				return indexWithoutOffset;
			else
				return indexWithoutOffset + (this._unfixedCount > 0 ? this._unfixedCount - 1 : 0);
		}
	},

	scrollCellIntoViewIE: function (cell)
	{
		var elem = cell.get_element();
		var row = cell.get_row();

		
		if ($util.IsOpera)
		{
			
			var topFix = this._grid._marginTop;
			var elemVertical = this.__isUnfixedTD(elem) ? this.__getColSpanTDFromUnfixedCell(elem) : elem;
			var scrollContainerVertical = this._grid._elements["container"];
			var bounds = Sys.UI.DomElement.getBounds(elemVertical);
			var scrollTop = scrollContainerVertical.scrollTop - topFix;
			var scrollBoundsVertical = (scrollTop + scrollContainerVertical.offsetHeight);
			var elemBoundsVertical = elemVertical.offsetTop + bounds.height;
			var vScrBar = this._grid._elements["vScrBar"];

			

			if (!this._grid._isAuxRow(row) && vScrBar && (elemVertical.offsetHeight > scrollBoundsVertical ||
						elemBoundsVertical < scrollTop ||
						elemVertical.offsetTop <= scrollBoundsVertical && elemBoundsVertical > scrollBoundsVertical ||
						elemVertical.offsetTop <= scrollTop && elemBoundsVertical >= scrollTop
						))
			{
				scrollTop = elemBoundsVertical - (scrollContainerVertical.offsetHeight) + topFix;
				vScrBar.scrollTop = scrollTop;
			}
		}

		if (this.__isUnfixedTD(elem))
		{
			var scrollContainer = elem.parentNode.parentNode.parentNode.parentNode;
			var scrollLeft = scrollContainer.scrollLeft;
			var bounds = Sys.UI.DomElement.getBounds(elem);
			var scrollBounds = (scrollLeft + scrollContainer.offsetWidth);
			var elemBounds = elem.offsetLeft + bounds.width;

			if (elem.offsetLeft > scrollBounds ||
						elemBounds < scrollLeft ||
						elem.offsetLeft <= scrollBounds && elemBounds > scrollBounds ||
						elem.offsetLeft <= scrollLeft && elemBounds >= scrollLeft
						)
			{
				scrollLeft = elemBounds - (scrollContainer.offsetWidth);
			}

			this._grid._hScrBar.scrollLeft = scrollLeft;

			var delegate = Function.createDelegate(this, this._onGridScrolled);
			$addHandler(scrollContainer, "scroll", delegate);
			elem.focus();
			$removeHandler(scrollContainer, "scroll", delegate);
		}
		else
		{
			if (elem)
				elem.focus();
		}
	}
	


}

$IG.ColumnFixing.registerClass('Infragistics.Web.UI.ColumnFixing', $IG.GridBehavior, $IG.IColumnSettings, $IG.IColumnFixingBehavior);


$IG.ColumnFixingSettings = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFixingSettings">
	/// Object that defines a column fixing setting for the grid column.
	/// </summary>
	$IG.ColumnFixingSettings.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnFixingSettings.prototype =
{
	get_enabled: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.enabled">
		/// Indicates whether column fixing is enabled on the particular column.
		/// </summary>
		/// <returns type="boolean">True if fixing is enabled for the column, false otherwise</returns>

		return this._get_clientOnlyValue("cfse");
	},

	get_fixButtonAlignment: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixButtonAlignment">
		/// Indicate whether the fix button/pin is located to the left or to the right of the header caption.
		/// </summary>
		/// <returns type="$IG.HeaderButtonAlignment">Location of the button.</returns>

		return this._get_clientOnlyValue("cfsba");
	},

	get_showFixButton: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.showFixButton">
		/// Determines if the pin button for fixing the column is shown next to the header caption.
		/// </summary>
		/// <returns type="boolean">True if the button will be displayed, false otherwise </returns>

		return this._get_clientOnlyValue("cfssfb");
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixLocation">
		/// Gets the direction to which the column will be fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column will be fixed to the right edge of the grid
		/// </returns>
		return this._get_value($IG.ColumnFixingSettingProps.FixLocation);
	},

	set_fixLocation: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixLocation">
		/// Sets direction to which the column will be fixed to.
		/// </summary>
		/// <param name="value" type="$IG.FixLocation"  optional="false" mayBeNull="false">
		/// $IG.FixLocation.Left - the column will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column will be fixed to the right edge of the grid
		/// </param>
		if (value == $IG.FixLocation.Left || value == $IG.FixLocation.Right)
			return this._set_value($IG.ColumnFixingSettingProps.FixLocation, value);
	}

}
$IG.ColumnFixingSettings.registerClass('Infragistics.Web.UI.ColumnFixingSettings', $IG.ColumnSetting);



$IG.FixedColumnInfo = function(column, fixLocation)
{
	/// <summary locid="T:J#Infragistics.Web.UI.FixedColumnInfo">
	/// Fixed column object.
	/// </summary>
	this._column = column;
	this._fixLocation = fixLocation;
}

$IG.FixedColumnInfo.prototype =
{

	get_column: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FixedColumnInfo.column">
		/// Get the refrence to the grid's column.
		/// </summary>
		/// <returns type="$IG.GridColumn"> Grid's column. </returns>

		return this._column;
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FixedColumnInfo.fixLocation">
		/// Gets the direction to which the column is fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column is fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column is fixed to the right edge of the grid
		/// </returns>
		return this._fixLocation;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.FixedColumnInfo.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the object will cleanup after itself.
		/// </summary>
		this._column = null;
		this._fixLocation = null;
	}

}
$IG.FixedColumnInfo.registerClass('Infragistics.Web.UI.FixedColumnInfo');



$IG.ClientFixedColumnInfo = function(column, fixLocation)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientFixedColumnInfo">
	/// Fixed column object to be used in the FixedStateChanging event.
	/// </summary>
	this._column = column;
	this._fixLocation = fixLocation;
}

$IG.ClientFixedColumnInfo.prototype =
{

	get_column: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientFixedColumnInfo.column">
		/// Get the refrence to the grid's column.
		/// </summary>
		/// <returns type="$IG.GridColumn"> Grid's column. </returns>

		return this._column;
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientFixedColumnInfo.fixLocation">
		/// Gets the direction to which the column is fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column is fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column is fixed to the right edge of the grid
		/// </returns>
		return this._fixLocation;
	},

	set_fixLocation: function(direction)
	{
		if (direction == $IG.FixLocation.Left || direction == $IG.FixLocation.Right)
			this._fixLocation = direction;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientFixedColumnInfo.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the object will cleanup after itself.
		/// </summary>
		this._column = null;
		this._fixLocation = null;
	}

}
$IG.ClientFixedColumnInfo.registerClass('Infragistics.Web.UI.ClientFixedColumnInfo');





$IG.FixLocation = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FixLocation">
	/// Enumeration of values for where a grid's column will be fixed to.
	/// </summary>
}
$IG.FixLocation.prototype =
{
	/// <summary>
	/// Left edge of the grid
	/// </summary>
	Left: 0,

	/// <summary>
	/// Right edge of the grid
	/// </summary>
	Right: 1
};
$IG.FixLocation.registerEnum("Infragistics.Web.UI.FixLocation");



$IG.HeaderButtonAlignment = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.HeaderButtonAlignment">
	/// Enumeration of values for where the column fixing button will be placed.
	/// </summary>
}
$IG.HeaderButtonAlignment.prototype =
{
	/// <summary>
	/// Place the button the the left of column header caption
	/// </summary>
	Left: 0,

	/// <summary>
	/// Place the button the the right of column header caption
	/// </summary>
	Right: 1
};
$IG.HeaderButtonAlignment.registerEnum("Infragistics.Web.UI.HeaderButtonAlignment");



$IG.GridColumnFixingProps = new function()
{
	/// <summary>
	/// An enumeration of all the properties that the Column Fixing behavior will send to the client.
	/// </summary>

	this.FixedColumns = [$IG.GridBehaviorProps.Count + 0, null];
	this.FixLocation = [$IG.GridBehaviorProps.Count + 1, $IG.FixLocation.Left];
	this.Count = $IG.GridBehaviorProps.Count + 2;
};


$IG.ColumnFixingSettingProps = new function()
{
	/// <summary>
	/// An enumeration of all the properties that the ColumnFixingSetting object will send to the client.   
	/// </summary> 
	this.FixLocation = [$IG.ColumnSettingProps.Count + 0, $IG.FixLocation.Left];
	this.Count = $IG.ColumnSettingProps.Count + 1;
};




$IG.ColumnFixingAction = function(type, ownerName, object, value, tag)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnFixingAction">
	///Object for event arguments used in the ColumnFixing behaviors to make full or partial postbacks.
	///</summary>

	$IG.ColumnFixingAction.initializeBase(this, [type, ownerName, object, value, tag]);
}
$IG.ColumnFixingAction.prototype =
{
}
$IG.ColumnFixingAction.registerClass('Infragistics.Web.UI.ColumnFixingAction', $IG.GridAction);





$IG.FixingEventArgs = function(behavior, fixedColumn, fixed)
{

	/// <summary locid="T:J#Infragistics.Web.UI.FixingEventArgs">

	/// Class used as EventArgs while raising FixedStateChanging event

	/// </summary>

	$IG.FixingEventArgs.initializeBase(this, [behavior]);


	this._fixed = fixed;

	this._fixedColumn = fixedColumn;
}

$IG.FixingEventArgs.prototype =
{

	get_fixedColumn: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixingEventArgs.fixedColumn">

		/// Get the refrence to the FixedColumnInfo obect whose state is currently changing.

		/// </summary>

		/// <return type="$IG.FixedColumnInfo"> The FixedColumnInfo obect whose state is currently changing </return> 


		return this._fixedColumn;

	},


	get_isFixed: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixingEventArgs.isFixed">

		/// Indicates if the column is currently fixed.

		/// </summary>

		/// <return type="boolean"> True-if the column is currently fixed.  False othersie </return>

		return this._fixed;

	}

}

$IG.FixingEventArgs.registerClass('Infragistics.Web.UI.FixingEventArgs', $IG.CancelBehaviorEventArgs);





$IG.FixedEvenArgs = function(fixedColumn, fixed) //function(fixedColumns)
{

	/// <summary locid="T:J#Infragistics.Web.UI.FixedEvenArgs">

	/// Class used as EventArgs while raising FixedStateChanged event

	/// </summary>


	$IG.FixedEvenArgs.initializeBase(this);

	this._fixed = fixed;

	this._fixedColumn = fixedColumn;

}

$IG.FixedEvenArgs.prototype =
{


	get_fixedColumn: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixedEvenArgs.fixedColumn">

		/// Get the refrence to the FixedColumnInfo obect whose state is currently changing.

		/// </summary>

		/// <return type="$IG.FixedColumnInfo"> The FixedColumnInfo obect whose state is currently changing </return> 


		return this._fixedColumn;

	},


	get_isFixed: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixedEvenArgs.isFixed">

		/// Indicates if the column is currently fixed.

		/// </summary>

		/// <return type="boolean"> True-if the column is currently fixed.  False otherwise </return>

		return this._fixed;

	}

}

$IG.FixedEvenArgs.registerClass('Infragistics.Web.UI.FixedEvenArgs', $IG.EventArgs);








$IG.FixUnfixColumnEventArgs = function(behavior)
{


	///<summary locid="T:J#Infragistics.Web.UI.FixUnfixColumnEventArgs">

	///Object for event arguments used in the ColumnFixing behavior for Fixing/Unfixing a column.

	///</summary>


	$IG.FixUnfixColumnEventArgs.initializeBase(this, [behavior]);


	

	this._props[1] = (behavior._grid._enableAjax) ? 2 : 1;


}

$IG.FixUnfixColumnEventArgs.prototype =
{
}
$IG.FixUnfixColumnEventArgs.registerClass('Infragistics.Web.UI.FixUnfixColumnEventArgs', $IG.CancelBehaviorEventArgs);


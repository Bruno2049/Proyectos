/*
* igWebDataGridEditing.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/



$IG.EditingCore = function(obj, objProps, control, parentCollection, hierarchical)
{
	///<summary locid="T:J#Infragistics.Web.UI.EditingCore">
	///Updating behavior object of the grid.
	///</summary>
	$IG.EditingCore.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._hierarchical = hierarchical;
	this._rowsToDelete = new $IG.GridAffectedItems();
	this._addRowCellValues = null;	

	this._cellValueChangingListener = Function.createDelegate(this, this._cellValueChanging);
	control._gridUtil._registerEventListener(control, "CellValueChanging", this._cellValueChangingListener);
	
	this._onTriggerCommit = Function.createDelegate(this, this._forceUpdateCommit);
	control._gridUtil._registerEventListener(control, "TriggerCommit", this._onTriggerCommit);

	this._cellValueChangedListener = Function.createDelegate(this, this._cellValueChanged);
	control._gridUtil._registerEventListener(control, "CellValueChanged", this._cellValueChangedListener);
	this._onRowsDeletingListener = Function.createDelegate(this, this._onRowsDeleting);
	control._gridUtil._registerEventListener(control, "RowsDeleted", this._onRowsDeletingListener);
	this._onRowAddingListener = Function.createDelegate(this, this._onRowAdding);
	control._gridUtil._registerEventListener(control, "RowAdded", this._onRowAddingListener);
	
	this._actions = {};
	
}

$IG.EditingCore.prototype =
{
	commit: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.commit">
		/// Commits all of the changes to the server.
		/// </summary>
		
		var shouldPost = this._commitUpdates(false);
		shouldPost = this._commitDeletes(false) || shouldPost;
		shouldPost = this._commitAdds(false) || shouldPost;

		var eventArgs = new $IG.CancelBehaviorEventArgs(this);
		if (shouldPost)
			eventArgs._props[1] = this._get_owner()._enableAjax ? 2 : 1;
		this._get_owner()._raiseClientEventEnd(eventArgs);
	},

	_commitUpdates: function(fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		var commitUpdate = false;
		for (var actionKey in this._actions)
		{
			var action = this._actions[actionKey];
			if (!action._commited)
			{
				var clientRendering = this._owner.get_enableClientRendering();
				var row = action._object;
				var updatedCells = action.get_updatedCells();
				var eventArgs = (!clientRendering ? new $IG.CancelUpdateRowEventArgs(this, row, updatedCells)
					: new $IG.ClientCancelUpdateRowEventArgs(this, row, updatedCells));

				if (this._clientEvents["RowUpdating"])
					this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowUpdating"], eventArgs);

				if (!eventArgs.get_cancel())
				{
					if (this._clientEvents["RowUpdating"])
					{
						
						if (this._clientEvents["RowUpdating"].postBack > 0)
						{
							action._commited = true;
							commitUpdate = true;
						}
						if (fireServerEvent)
							this._get_owner()._raiseClientEventEnd(eventArgs);
					}
				}
				else if (clientRendering && eventArgs.get_cancel() && eventArgs.get_selfUpdate())
					action._commited = true;
				else
				{
					for (var i = 0; i < updatedCells.get_length(); i++)
					{
						var change = updatedCells.getItem(i);
						var column = this._grid.get_columns().get_columnFromIDPair(change.colIdPair);
						var cell = row.get_cellByColumn(column);
						cell._set_value_internal(change.oldValue);
					}
					updatedCells.clear();
				}
				if (action._commited)
					delete this._actions[actionKey];
			}
		}
		return commitUpdate;
	},

	_commitDeletes: function(fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		if (this._rowsToDelete.get_length() > 0)
		{
			var RowsDeletingEventArgs = new $IG.CancelRowsDeletingEventArgs(this, this._rowsToDelete);

			this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowsDeleting"], RowsDeletingEventArgs);

			if (!RowsDeletingEventArgs.get_cancel())
			{

				rows = RowsDeletingEventArgs.get_rows();
				var numRows = rows.get_length();
				var row;
				var rowIdPairs = new Array();

				//Loop through collection of rows targeted for deletion and save the rowIdPairs
				for (var i = numRows - 1; i >= 0; i--)
				{
					row = rows.getItem(i);
					if (row.get_idPair) 
						rowIdPairs[i] = row.get_idPair();
					else 
						rowIdPairs[i] = row;
				}

				//Sort the rowIdPairs to ensure that the rows are deleted in the correct order
				rowIdPairs.sort(this._sortRowIdPairs);

				//Clear the selected rows
				if (this._selection)
				{
					this._selection._selectedRowCollection.clear();
					this._selection._selectedCellCollection.clear();
				}

				this._get_owner()._actionList.add_transaction(new $IG.GridAction("DeleteRow", "EditingCore", this._get_owner(), rowIdPairs));
				if (fireServerEvent)
					this._get_owner()._raiseClientEventEnd(RowsDeletingEventArgs);
				return true;
			}
			else
				this._rowsToDelete.clear();
		}
		return false;
	},


	_commitAdds: function(fireServerEvent)
	{
		if (typeof fireServerEvent == "undefined")
			fireServerEvent = true;
		if (this._addRowCellValues)
		{
			var row = null;
			if (this._addNew)
				row = this._addNew.get_row();
			var eventArgs = new $IG.CancelAddRowEventArgs(this, row, this._addRowCellValues);

			this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowAdding"], eventArgs);

			if (!eventArgs.get_cancel())
			{
				




				var isDate = {};
				for (var i = 0; i < this._addRowCellValues.length; i++)
				{
					var column = (this._addRowCellValues[i] && this._addRowCellValues[i].DataKeyField ? this._get_owner().get_columns().get_columnFromKey(this._addRowCellValues[i].DataKeyField) : this._get_owner().get_columns().get_column(i));
					if (column && column.get_type() == "date")
					{											
						if (this._addRowCellValues[i] && this._addRowCellValues[i].DataKeyField)
						{
							this._addRowCellValues[i].Value = this._get_owner()._gridUtil._convertClientDateToServerString(this._addRowCellValues[i].Value);
							this._addRowCellValues[i].IsDate = true;
						}
						else if (this._addRowCellValues[i])
						{
							isDate[i.toString()] = true;
							this._addRowCellValues[i] = this._get_owner()._gridUtil._convertClientDateToServerString(this._addRowCellValues[i]);
						}
					}
				}
				this._get_owner()._actionList.add_transaction(new $IG.GridAction("AddRow", "EditingCore", this._get_owner().get_behaviors().get_editingCore(), this._addRowCellValues, isDate));
				if (fireServerEvent)
					this._get_owner()._raiseClientEventEnd(eventArgs);
				this._addRowCellValues = null;

				return true;
			}
		}
		return false;
	},

	_sortRowIdPairs: function(a, b)
	{
		return (b.index - a.index)
	},

	_cellValueChanging: function(args)
	{
		var eventArgs = this.__raiseClientEvent("CellValueChanging", $IG.CancelCellValueChangingEventArgs, [this, args.cell, args.oldValue, args.newValue]);
		if (eventArgs != null)
		{
			args.cancel = eventArgs.get_cancel();
			args.newValue = eventArgs.get_newValue();
		}

	},
	_cellValueChanged: function(args)
	{
		var row = args.cell.get_row();
		var action = this._getUpdateAction(row);

		if (!action || !action._object)
		{
			action = this._createUpdateAction(row);
			this._addUpdateAction(action, row);
			this._owner._actionList.add_transaction(action);
			action.addUpdateCell(args.cell, args.oldValue);
		}
		else
		{
			action.addUpdateCell(args.cell, args.oldValue);
			// if the cell is updated with the original value it will be removed from the action.
			var prevAction = action._object["_action" + action.type];
			if (!action.hasUpdatedCells() && prevAction && prevAction._transactionList == this._owner._actionList)
			{
				// if there are no updated cells in this action and there is a previous action associated with this object then remove it from the transaction list.
				this._owner._actionList.remove_transaction(action);
				this._removeUpdateAction(row);
			}
		}

		this._hasCellValueChanged = true;
		this.__raiseClientEvent("CellValueChanged", $IG.CellValueChangedEventArgs, [this, args.cell, args.oldValue]);
	},
	
	_forceUpdateCommit: function ()
	{
		if (this._hasCellValueChanged)
		{
			this._hasCellValueChanged = false;
			this._commitUpdates();
		}
	},
	_activeCellChanged: function (args)
	{
		


		

		if (args.cell)
		{
			var activeRow = args.cell.get_row();
			if (this._lastActiveRow && (activeRow != this._lastActiveRow && this._hasCellValueChanged == true))
			{
				this._hasCellValueChanged = false;
				this._commitUpdates();
			}
			this._lastActiveRow = activeRow;
		}
		else if (this._hierarchical && args.cell == null && this._hasCellValueChanged)
		{
			var mainGrid = this._grid._get_mainGrid();
			if (mainGrid && (mainGrid._lastActiveGridIdLock || this._activation.__inSetActiveElement) && mainGrid._get_lastActiveGridId() == this._grid._id)
			{
				this._hasCellValueChanged = false;
				this._lastActiveRow = null;
				this._commitUpdates();
			}

		}
		else
			this._lastActiveRow = null;
	},

	_getRowActionKey: function(row)
	{
		var rowIdPair = row.get_idPair();
		var actionKey = rowIdPair.key;

		if (actionKey.length == 0)
			actionKey = rowIdPair.index;

		return actionKey;
	},

	_getUpdateAction: function(row)
	{
		return this._actions[this._getRowActionKey(row)];
	},

	_removeUpdateAction: function(row)
	{
		delete this._actions[this._getRowActionKey(row)];
	},

	_createUpdateAction: function(row)
	{
		return new $IG.UpdateRowAction("UpdateRow", this.get_name(), row, new $IG.GridAffectedItems());
	},

	_addUpdateAction: function(action, row)
	{
		if (action && row)
		{
			this._actions[this._getRowActionKey(row)] = action;
		}
	},

	_onRowsDeleting: function(args)
	{
		var row = args.row;
		
		if (this._rowsToDelete.indexOf(row) == -1)
			this._rowsToDelete.add(row);
		if (args.commit)
			this.commit();
	},

	_onRowAdding: function(args)
	{
		this._addRowCellValues = args.cellValues;
		this.commit();
	},
	_activateCell: function(cellElement)
	{
		if (cellElement && cellElement.parentNode && cellElement.offsetWidth) try
		{
			cellElement.focus();
		} catch(ex){}
	},

	
	_onMoreRowsReceived: function ()
	{
		for (var actionKey in this._actions)
		{
			var action = this._actions[actionKey];
			this._owner._actionList.remove_transaction(action);
			delete action;
		}
	},

	
	_initializeComplete: function()
	{
		this._activation = this._owner.get_behaviors().getBehaviorFromInterface($IG.IActivationBehavior);
		if (this._activation)
		{
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._activeCellChanged));
			if (this._activation.get_activeCell() && this._get_clientOnlyValue("foc"))
			{
				window.setTimeout($util.createDelegate(this, this._activateCell, [this._activation.get_activeCell().get_element()]), 0);
				
				if (!this._lastActiveRow)
					this._lastActiveRow = this._activation.get_activeCell().get_row();
			}
		}
		this._addNew = this._owner.get_behaviors().getBehaviorFromInterface($IG.IRowAddingBehavior);


		this._selection = this._owner.get_behaviors().getBehaviorFromInterface($IG.ISelectionBehavior);

		
		this._virtualScrolling = this._grid.get_behaviors().get_virtualScrolling();
		if (this._virtualScrolling)
		{
			this._onMoreRowsReceivedHandler = Function.createDelegate(this, this._onMoreRowsReceived);
			this._virtualScrolling._addReceivedMoreRowsEventHandler(this._onMoreRowsReceivedHandler);
		}

		var deletionExemptRowIDs = this._get_clientOnlyValue("der");
		var shouldFireClientDeletedEvent = this._get_clientOnlyValue("fcde");
		if (shouldFireClientDeletedEvent)
		{
			if (this._clientEvents["RowsDeleted"])
			{
				var deletionExemptRows;
				if (deletionExemptRowIDs)
					deletionExemptRows = Sys.Serialization.JavaScriptSerializer.deserialize(deletionExemptRowIDs);
				else
					deletionExemptRows = new Array();

				var RowsDeletedEventArgs = new $IG.RowsDeletedEventArgs(this, deletionExemptRows);
				this._owner._raiseSenderClientEventStart(this, this._clientEvents["RowsDeleted"], RowsDeletedEventArgs);
			}
			
			if (this._hierarchical && !this._addNew && this._grid.get_rows().get_length() == 0)
			{
				var filtering = this._owner.get_behaviors().get_filtering();
				if (!filtering || (filtering && filtering._get_totalRowCount() == 0))
					this._grid.__deleteGrid = true;
			}
		}

		var updatedRowIDs = this._get_clientOnlyValue("urp");
		if (updatedRowIDs && this._clientEvents["RowUpdated"])
		{
			var updRows = Sys.Serialization.JavaScriptSerializer.deserialize(updatedRowIDs);
			for (var i = 0; i < updRows.length; i++)
			{
				var row = this._grid.get_rows().get_rowFromIDPair(updRows[i]);
				var rowUpdatedEventArgs = new $IG.RowUpdatedEventArgs(this, row);
				this._owner._raiseSenderClientEvent(this, this._clientEvents["RowUpdated"], rowUpdatedEventArgs);
			}
		}

		var shouldFireClientAddedEvent = this._get_clientOnlyValue("wri");
		if (shouldFireClientAddedEvent && this._clientEvents["RowAdded"])
		{
			
			var rowAddedIdString = this._get_clientOnlyValue("rai");
			var rowAddedId = (rowAddedIdString != null && rowAddedIdString.length > 0) ? Sys.Serialization.JavaScriptSerializer.deserialize(rowAddedIdString) : null;
			var row = (rowAddedId != null) ? this._grid.get_rows().get_rowFromIDPair(rowAddedId) : null;
			var evtArgs = new $IG.RowAddedEventArgs(row, rowAddedId);
			this._owner._raiseSenderClientEvent(this, this._clientEvents["RowAdded"], evtArgs);
		}

	},

	_responseComplete: function(callbackObject, responseOptions)
	{
		if (responseOptions.updatedRowIdPair && responseOptions.updatedRowValues)
		{
			var row = this._grid.get_rows().get_rowFromIDPair(responseOptions.updatedRowIdPair);
			for (var key in responseOptions.updatedRowValues)
			{
				var column = this._grid.get_columns().get_columnFromKey(key);
				if (!column.get_isTemplated())
				{
					var cell = row.get_cellByColumn(column);
					//cell._set_value_internal(responseOptions.updatedRowValues[key]);
					var updatePair = responseOptions.updatedRowValues[key];

					


					var cellValue = updatePair[0];
					if (column.get_type() == "date")
						cellValue = cell.get_grid()._gridUtil._convertServerDateStringToClientObject(cellValue);

					cell._set_value_internal(cellValue, updatePair[1]);
				}
			}
			this._owner._actionList.remove_transaction(row._actionUpdateRow);
			if (this._clientEvents["RowUpdated"])
			{
				var rowUpdatedEventArgs = new $IG.RowUpdatedEventArgs(this, row);
				this._owner._raiseSenderClientEvent(this, this._clientEvents["RowUpdated"], rowUpdatedEventArgs);
			}
		}
	},

	_createBehaviorCollection: function()
	{
		return new $IG.EditingCoreBehaviorCollection(this._owner);
	},
	

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.dispose">
		/// For internal use.
		/// </summary>
		if (this._grid)
		{
			var util = this._grid._gridUtil;
			if (util)
			{
				util._unregisterEventListener(this._grid, "CellValueChanging", this._cellValueChangingListener);
				this._cellValueChangingListener = null;
				util._unregisterEventListener(this._grid, "TriggerCommit", this._onTriggerCommit);
				this._onTriggerCommit = null;
				util._unregisterEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
				this._cellValueChangedListener = null;
				util._unregisterEventListener(this._grid, "RowsDeleted", this._onRowsDeletingListener);
				this._onRowsDeletingListener = null;
				util._unregisterEventListener(this._grid, "RowAdded", this._onRowAddingListener);
				this._onRowAddingListener = null;
				
				if (this._virtualScrolling)
				{
					this._grid._gridUtil._unregisterEventListener(this._virtualScrolling, "ReceivedMoreRows", this._onMoreRowsReceivedHandler);
					delete this._onMoreRowsReceivedHandler
					delete this._virtualScrolling;
				}
			}
		}
		$IG.EditingCore.callBaseMethod(this, "dispose");
	}
}

$IG.EditingCore.registerClass('Infragistics.Web.UI.EditingCore', $IG.GridBehaviorContainer, $IG.IEditingBehavior);



$IG.EditingCoreBehaviorCollection = function(control)
{
	$IG.EditingCoreBehaviorCollection.initializeBase(this, [control]);
}

$IG.EditingCoreBehaviorCollection.prototype =
{
	_rowDeleting: null,
	get_rowDeleting: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowDeleting">
		/// Returns reference to the row deleting behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowDeleting" mayBeNull="true"></value>
		return this._rowDeleting;
	},

	_rowAdding: null,
	get_rowAdding: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowAdding">
		/// Returns reference to the row adding behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowAdding" mayBeNull="true"></value>
		return this._rowAdding;
	},

	_cellEditing: null,
	get_cellEditing: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.cellEditing">
		/// Returns reference to the cell editing behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.CellEditing" mayBeNull="true"></value>
		return this._cellEditing;
	},

	_rowEditingTemplate: null,
	get_rowEditingTemplate: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.rowEditingTemplate">
		/// Returns reference to the row editing template behavior if one exists in the collection. 
		/// Null if the behavior is not added or not enabled on the server.
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowEditingTemplate" mayBeNull="true"></value>
		return this._rowEditingTemplate;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditingCore.dispose">
		/// For internal use.
		/// </summary>
		this._rowDeleting = null;
		this._rowAdding = null;
		this._cellEditing = null;
		this._rowEditingTemplate = null;
		$IG.EditingCoreBehaviorCollection.callBaseMethod(this, "dispose");
	}

}

$IG.EditingCoreBehaviorCollection.registerClass('Infragistics.Web.UI.EditingCoreBehaviorCollection', $IG.BehaviorCollectionBase);



$IG.UpdateRowAction = function(type, ownerName, object, value, tag)
{
	$IG.UpdateRowAction.initializeBase(this, [type, ownerName, object, value, tag]);
}

$IG.UpdateRowAction.prototype =
{
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.value">
		/// Returns the value of the UpdateAction.
		/// </summary>
		/// <value type="String"></value>
		return this._value._items;
	},

	get_updatedCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.updatedCells">
		/// Returns an array of the updated cells.
		/// </summary>
		/// <value type="Array" elementType=""></value>
		return this._value;
	},

	hasUpdatedCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditingCore.hasUpdatedCells">
		/// Returns true if the row action has at least one updated cell.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._value.get_length() > 0;
	},

	findUpdatedCellRowAction: function (cell)
	{
		var updatedCellAction = null;
		if (cell)
		{
			var colIdPair = cell.get_idPair().columnIDPair;
			var updatedCells = this.get_updatedCells();

			for (var i = 0, len = updatedCells.get_length(); i < len; i++)
			{
				var updCell = updatedCells.getItem(i);
				if (cell.get_grid()._gridUtil.areIdPairsEqual(colIdPair, updCell.colIdPair))
				{
					updatedCellAction = updCell;
					break;
				}
			}
		}
		return updatedCellAction;
	},

	addUpdateCell: function (cell, oldValue)
	{
		var isAdded = true;
		var updatedCellAction = this.findUpdatedCellRowAction(cell);

		if (!updatedCellAction)
		{
			updatedCellAction = { "colIdPair": cell.get_idPair().columnIDPair, "oldValue": oldValue };
			
			if (cell.get_column().get_type() == "number" && isNaN(oldValue))
				updatedCellAction.oldValue = "NaN";
			this.get_updatedCells().add(updatedCellAction);
			updatedCellAction.value = cell.get_value();
			
			if (cell.get_column().get_type() == "number" && isNaN(updatedCellAction.value))
				updatedCellAction.value = "NaN";
			else if (cell.get_column().get_type() == "date")
			{
				updatedCellAction.valueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.value);
				updatedCellAction.oldValueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.oldValue);
			}
			updatedCellAction._commited = false;
		}
		else
		{
			// this cell has beend updated before
			updatedCellAction.value = cell.get_value();
			
			if (cell.get_column().get_type() == "number" && isNaN(updatedCellAction.value))
				updatedCellAction.value = "NaN";
			else if (cell.get_column().get_type() == "date")
			{
				updatedCellAction.valueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.value);
				updatedCellAction.oldValueDateString = cell.get_grid()._gridUtil._convertClientDateToServerString(updatedCellAction.oldValue);
			}
			updatedCellAction._commited = false;

			if (updatedCellAction.oldValue == cell.get_value())
			{
				// we are trying to set a value that was the original value
				var updatedCellActionsList = this.get_updatedCells();
				updatedCellActionsList.remove(updatedCellActionsList.indexOf(updatedCellAction));
				isAdded = false;
			}
		}
		return isAdded;
	}
}

$IG.UpdateRowAction.registerClass('Infragistics.Web.UI.UpdateRowAction', $IG.GridAction);



$IG.GridAffectedItems = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridAffectedItems">
	/// Collection of row and row ID pairs to be deleted.
	/// </summary>
	$IG.GridAffectedItems.initializeBase(this);
	this._lsize = 0;
	this._items = new Array();
} 
 
$IG.GridAffectedItems.prototype=
{
	 add:function(itemID)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.add">
		/// Adds an item to the collection.
		/// </summary>
	 	/// <param name="itemID">
		/// Reference to an item ID.
		///</param>
	 	if (itemID == null) return;

		this._lsize++;
		this._items[(this._lsize - 1)] = itemID;
	 },

	 remove:function (index)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.remove">
		/// Removes an item from the collection by its index.
		/// </summary>
		/// <param name="index" type="Number" integer="true">
		/// Index of the item to be removed from the collection.
		///</param>
		if (index < 0 || index > this._items.length - 1) return;
		this._items[index] = null;


		for (var i = index; i <= this._lsize; i++)
			this._items[i] = this._items[i + 1];

		this._lsize--;
	 },
	 
	 indexOf:function (item)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.indexOf">
		/// Returns the index of the provided item.
		/// </summary>
		/// <param name="item">
		/// Reference to the item to get the index in the collection.
		///</param>
		///<returns type="Number" integer="true"></returns>
		for (var i = 0; i<this._lsize; i++)
		{
			if(item == this._items[i])
				return i;
		}
		return -1;
	 },

	isEmpty:function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.isEmpty">
		/// Indicates whether the collection is empty.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._lsize == 0;
	},     

	get_length:function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridAffectedItems.length">
		/// Gets the length of the collection.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._lsize
	},     
			 
	 getItem:function(index)
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.getItem">
	 	/// Returns an item from the collection by its index.  Can be either a row object
		/// or just a row ID pair if the row is on another page.
		/// </summary>
		/// <param name="index" type="Number" integer="true">
		/// Index of the item in the collection.
		///</param>
		///<returns></returns>
		return this._items[index];
	 },     

	 clear:function ()
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.clear">
		/// Clears the collection.
		/// </summary>
		  for (var i = 0; i < this._lsize; i++)
			   this._items[i] = null;

		  this._lsize = 0;
	 },

	 clone:function ()
	 {
		/// <summary locid="M:J#Infragistics.Web.UI.GridAffectedItems.clone">
		/// Creates and returns a copy of the collection.
		/// </summary>
		  var c = new GridAffectedItems();

		  for (var i = 0; i < this._lsize; i++)
			   c.add(this._items[i]);

		  return c;
	 }
}
$IG.GridAffectedItems.registerClass('Infragistics.Web.UI.GridAffectedItems');




$IG.CancelRowsDeletingEventArgs = function(deleting, rows)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CancelRowsDeletingEventArgs">
	/// Event arguments object that is passed into the RowsDeleting event handler. Provides an option to cancel the event.
	/// </summary>
	$IG.CancelRowsDeletingEventArgs.initializeBase(this, [deleting]);
	this._rows = rows;
}
$IG.CancelRowsDeletingEventArgs.prototype =
{
	get_rows: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelRowsDeletingEventArgs.rows">
		/// Returns the collection of row ID pairs that are about to be deleted.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridAffectedItems"></value>
		return this._rows;
	}
	
}
$IG.CancelRowsDeletingEventArgs.registerClass('Infragistics.Web.UI.CancelRowsDeletingEventArgs', $IG.CancelBehaviorEventArgs);


$IG.RowsDeletedEventArgs = function(deleting, deletionExemptRowIDs)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowsDeletedEventArgs">
	///Event arguments object that is passed into the RowsDeleted event handler.
	///</summary>
	$IG.RowsDeletedEventArgs.initializeBase(this, [deleting]);
	this._deletionExemptRowIDs = deletionExemptRowIDs;
}
$IG.RowsDeletedEventArgs.prototype =
{
	get_canceled_rowIDPairs: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowsDeletedEventArgs.canceled_rowIDPairs">
		///Returns the Id's of any row who's delete event was canceled on the server.
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.IDPair"></value>
		return this._deletionExemptRowIDs;
	}
}
$IG.RowsDeletedEventArgs.registerClass('Infragistics.Web.UI.RowsDeletedEventArgs', $IG.EventArgs);




$IG.CancelAddRowEventArgs = function(addNewRow, row, cellValues)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelAddRowEventArgs">
	///Event arguments object passed into the row adding event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelAddRowEventArgs.initializeBase(this, [addNewRow]);
	this._row = row;
	this._cellValues = cellValues;
}
$IG.CancelAddRowEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelAddRowEventArgs.row">
		/// Returns reference to the add new row behavior's row. The property can be null if the behavior is not present.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AddNewGridRow"></value>
		return this._row;
	},
	get_cellValues: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelAddRowEventArgs.cellValues">
		/// Returns the new row's cell values.
		/// </summary>
		/// <value type="Array" elementType=""></value>
		return this._cellValues;
	}
}
$IG.CancelAddRowEventArgs.registerClass('Infragistics.Web.UI.CancelAddRowEventArgs', $IG.CancelBehaviorEventArgs);





















$IG.CancelUpdateRowEventArgs = function(updating, row, updatedCells)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelUpdateRowEventArgs">
	///Event arguments object passed into the row updating event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelUpdateRowEventArgs.initializeBase(this, [updating]);
	this._row = row;
	this._updatedCells = updatedCells;
}
$IG.CancelUpdateRowEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelUpdateRowEventArgs.row">
		/// Returns reference to the row that is being updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_updatedCells: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelUpdateRowEventArgs.updatedCells">
		/// Returns an array of updated cell helper objects that contain cell's new and old values.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridAffectedItems"></value>
		return this._updatedCells;
	}
}
$IG.CancelUpdateRowEventArgs.registerClass('Infragistics.Web.UI.CancelUpdateRowEventArgs', $IG.CancelBehaviorEventArgs);



$IG.ClientCancelUpdateRowEventArgs = function (updating, row, updatedCells)
{
	///<summary locid="T:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs">
	///Event arguments object passed into the row updating event handler. Provides an option to cancel the event.
	///Has a default setting of 
	///</summary>
	$IG.ClientCancelUpdateRowEventArgs.initializeBase(this, [updating, row, updatedCells]);
	this._selfUpdate = true;
}
$IG.ClientCancelUpdateRowEventArgs.prototype =
{
	get_selfUpdate: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs.selfUpdate">
		/// Indicates if the datasource will process the cells update outside of the grid.
		/// The default value of this setting is true.
		/// </summary>		
		return this._selfUpdate;
	},
	set_selfUpdate: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCancelUpdateRowEventArgs.selfUpdate">
		/// Sets the value of selfUpdate.
		/// </summary>
		/// <param name="value" type="Boolean">The new value that the selfUpdate property will change to</param>
		this._selfUpdate = value;
	}
}
$IG.ClientCancelUpdateRowEventArgs.registerClass('Infragistics.Web.UI.ClientCancelUpdateRowEventArgs', $IG.CancelUpdateRowEventArgs);




$IG.RowUpdatedEventArgs = function(editingCore, row)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowUpdatedEventArgs">
	///Event arguments object that is passed into the RowUpdatedEventArgs event handler.
	///</summary>
	$IG.RowUpdatedEventArgs.initializeBase(this);
	this._editingCore = editingCore;
	this._row = row;
}
$IG.RowUpdatedEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowUpdatedEventArgs.row">
		///Returns the row that has been updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	}
}
$IG.RowUpdatedEventArgs.registerClass('Infragistics.Web.UI.RowUpdatedEventArgs', $IG.EventArgs);




$IG.RowAddedEventArgs = function(row, rowIDPair)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowAddedEventArgs">
	///Event arguments object that is passed into the RowAdded event handler.
	///</summary>
	$IG.RowAddedEventArgs.initializeBase(this);
	this._row = row;
	this._rowIDPair = rowIDPair;
}
$IG.RowAddedEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddedEventArgs.row">
		/// Returns the row that has been added, if the row is currently present on the client.
		/// Otherwise null is returned
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow" mayBeNull="true"></value>
		return this._row;
	},
	get_rowIDPair: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddedEventArgs.rowIDPair">
		/// Returns the IdPair of the row that has been added.
		/// </summary>
		/// <value type="Infragistics.Web.UI.IDPair"></value>
		return this._rowIDPair;
	}
}
$IG.RowAddedEventArgs.registerClass('Infragistics.Web.UI.RowAddedEventArgs', $IG.EventArgs);



$IG.CancelCellValueChangingEventArgs = function(params)//updating, cell, currentValue, newValue)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs">
	///Event arguments object passed into the cell value changing event handler. Provides an option to cancel the event.
	///</summary>
	$IG.CancelCellValueChangingEventArgs.initializeBase(this, [params[0]]);
	this._cell = params[1];
	this._currentValue = params[2];
	this._newValue = params[3];
}
$IG.CancelCellValueChangingEventArgs.prototype =
{
	get_cell: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.cell">
		/// Returns reference to the cell that is being updated.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._cell;
	},
	get_currentValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.oldValue">
		/// Returns the current value of the cell.
		/// </summary>
		/// <value type="String"></value>
		return this._currentValue;
	},
	get_newValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.newValue">
		/// Returns the value that the cell is changing to.
		/// </summary>
		/// <value type="String"></value>
		return this._newValue;
	},
	set_newValue: function(newValue)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CancelCellValueChangingEventArgs.newValue">
		/// Sets the value that the cell is changing to.
		/// </summary>
		/// <param name="newValue" type="String">The new value that the cell will change to</param>
		this._newValue = newValue;
	}
}
$IG.CancelCellValueChangingEventArgs.registerClass('Infragistics.Web.UI.CancelCellValueChangingEventArgs', $IG.CancelBehaviorEventArgs);



$IG.CellValueChangedEventArgs = function(params)//editingCore, cell, oldValue)
{
	///<summary locid="T:J#Infragistics.Web.UI.CellValueChangedEventArgs">
	///Event arguments object that is passed into the CellValueChangedEventArgs event handler.
	///</summary>
	$IG.CellValueChangedEventArgs.initializeBase(this);
	this._editingCore = params[0];
	this._cell = params[1];
	this._oldValue = params[2];
}
$IG.CellValueChangedEventArgs.prototype =
{
	get_cell: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CellValueChangedEventArgs.cell">
		///Returns the cell that has had its value changed.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell"></value>
		return this._cell;
	},
	get_oldValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.CellValueChangedEventArgs.oldValue">
		///Returns the cell's previous value.
		/// </summary>
		/// <value type="String"></value>
		return this._oldValue;
	}
}
$IG.CellValueChangedEventArgs.registerClass('Infragistics.Web.UI.CellValueChangedEventArgs', $IG.EventArgs);


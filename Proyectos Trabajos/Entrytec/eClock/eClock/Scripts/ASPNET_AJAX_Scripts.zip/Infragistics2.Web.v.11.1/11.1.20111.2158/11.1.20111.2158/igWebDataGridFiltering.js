/*
* igWebDataGridFiltering.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


$IG.Filtering = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Filtering">
	/// Filtering behavior object of the grid.
	/// </summary>
	/// <param name="obj" type="String">The name of the behavior.</param>
	/// <param name="objProps" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.WebDataGrid">The grid to which the behavior belongs to.</param>
	/// <param name="parentCollection" type="Infragistics.Web.UI.BehaviorCollectionBase">The collection to which the behavior belongs to.</param>

	$IG.Filtering.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._grid = this._owner;
	this._gridElement = this._grid._element;
	this._gridContainer = control._elements["container"];
	this._clientColumnFilters = [];

	this._hierarchical = hierarchical;

	this._ruleDDSelectedItemCss = this._get_clientOnlyValue("frddsic"); // selected rule item css class
	this._ruleDDHoverItemCss = this._get_clientOnlyValue("frddhic");    // rule item hover css class
	this._ruleDDItemCss = this._get_clientOnlyValue("frddic");          // rule item css class

	

	this.__defaultDate = this._grid._gridUtil._convertServerDateStringToClientObject(Sys.Serialization.JavaScriptSerializer.deserialize(this._get_clientOnlyValue("fdefdate")));

	

	this._onMouseDownHandler = Function.createDelegate(this, this._onMouseDown);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);

	this._onMouseUpHandler = Function.createDelegate(this, this._onMouseUp);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);

	this._onMousewheelHandler = Function.createDelegate(this, this._onMousewheel);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
	// for FF
	if ($util.IsFireFox)
		$addHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
	$addHandler(this._gridContainer, "scroll", this._onMousewheelHandler);

	this._onKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'keydown', this._onKeyDownHandler);

	
	var gridId = this._grid._id;
	var numDropDownUL = $get(gridId + "_NumericRuleDropDown_UL");
	var textDropDownUL = $get(gridId + "_TextRuleDropDown_UL");
	var dateDropDownUL = $get(gridId + "_DateTimeRuleDropDown_UL");
	var boolDropDownUL = $get(gridId + "_BooleanRuleDropDown_UL");

	numDropDownUL.tabIndex = 0;
	textDropDownUL.tabIndex = 0;
	dateDropDownUL.tabIndex = 0;
	boolDropDownUL.tabIndex = 0;

	this._grid.__walkThrough(numDropDownUL, true);
	this._grid.__walkThrough(textDropDownUL, true);
	this._grid.__walkThrough(dateDropDownUL, true);
	this._grid.__walkThrough(boolDropDownUL, true);

	var childLi = numDropDownUL.childNodes;
	var childCount = childLi.length;
	for (var x = 0; x < childCount; ++x)
		childLi[x].tabIndex = 0;
	childLi = textDropDownUL.childNodes;
	childCount = childLi.length;
	for (var x = 0; x < childCount; ++x)
		childLi[x].tabIndex = 0;
	childLi = dateDropDownUL.childNodes;
	childCount = childLi.length;
	for (var x = 0; x < childCount; ++x)
		childLi[x].tabIndex = 0;
	childLi = boolDropDownUL.childNodes;
	childCount = childLi.length;
	for (var x = 0; x < childCount; ++x)
		childLi[x].tabIndex = 0;

	this._onSelectRuleHandler = Function.createDelegate(this, this._onSelectRule);
	$addHandler(numDropDownUL, 'mousedown', this._onSelectRuleHandler);
	$addHandler(textDropDownUL, 'mousedown', this._onSelectRuleHandler);
	$addHandler(dateDropDownUL, 'mousedown', this._onSelectRuleHandler);
	$addHandler(boolDropDownUL, 'mousedown', this._onSelectRuleHandler);


	
	this._onMouseOverRuleHandler = Function.createDelegate(this, this._onMouseOverRule);
	$addHandler(numDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
	$addHandler(textDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
	$addHandler(dateDropDownUL, 'mouseover', this._onMouseOverRuleHandler);
	$addHandler(boolDropDownUL, 'mouseover', this._onMouseOverRuleHandler);

	this._onMouseOutRuleHandler = Function.createDelegate(this, this._onMouseOutRule);
	$addHandler($get(this._grid._id + "_NumericRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
	$addHandler(textDropDownUL, 'mouseout', this._onMouseOutRuleHandler);
	$addHandler(dateDropDownUL, 'mouseout', this._onMouseOutRuleHandler);
	$addHandler(boolDropDownUL, 'mouseout', this._onMouseOutRuleHandler);

	this._onKeyDownRuleHandler = Function.createDelegate(this, this._onKeyDownRule);
	$addHandler($get(gridId + "_NumericRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
	$addHandler($get(gridId + "_TextRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
	$addHandler($get(gridId + "_DateTimeRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
	$addHandler($get(gridId + "_BooleanRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);

	this._row = new $IG.FilterRow(-1, control._elements["filterRow"], [], this._grid, null, this);
	this._row._element.setAttribute("adr", -1);
	this._row._container = this._row._element.parentNode.parentNode.parentNode;

	this._onFilterKeyDownHandler = Function.createDelegate(this, this._onFilterKeyDown);
	$addHandler(this._row._element, 'keydown', this._onFilterKeyDownHandler);

	if ($util.IsOpera)
	{
		
		this._onKeyPressRuleHandler = Function.createDelegate(this, this._onKeyPressRule);
		$addHandler(document, 'keypress', this._onKeyPressRuleHandler);
	}

	this._onGridResizeHandler = Function.createDelegate(this, this._onGridResize);
	this._grid._gridUtil._registerEventListener(this._grid, "Resize", this._onGridResizeHandler);

	this._gridElementSelectStartHandler = Function.createDelegate(this, this._onSelectstartHandler);
	this._grid._gridUtil._registerEventListener(this._grid, "SelectStartContainer", this._gridElementSelectStartHandler);
	
	
	
	this._dropDownBehaviors = [];
	this._dropDownBehaviorsCount = 0;
}

$IG.Filtering.prototype =
{
	
	create_columnFilter: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.create_columnFilter">
		/// Creates a column filter object. Viewstate will not be preserved for this object
		/// until it is added to the column filters' collection
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter will be tied to.
		/// </param>
		/// <returns type="Infragistics.Web.UI.ClientColumnFilter">Newly created column filter </returns>

		var column = this._grid.get_columns().get_columnFromKey(columnKey);
		
		if (!column)
			return null;

		return new $IG.ClientColumnFilter(columnKey, column.get_type(), this._grid.get_id());
	},

	add_columnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.add_columnFilter">
		/// Adds the column filter object to the column filters' collection
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter which to add to the collection this should be created via create_columnFilter
		/// method.
		///</param>

		if (!this.get_columnFilterFromKey(columnFilter.get_columnKey()))
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("AddColumnFilter", this.get_name(), this._grid, columnFilter, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}

	},

	add_columnFilterRange: function (columnFilters)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.add_columnFilterRange">
		/// Adds the column filter objects to the column filters' collection
		/// </summary>
		///<param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filters which to add to the collection.
		///</param>
		if (columnFilters)
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.FilteringAction("AddColumnFilter", this.get_name(), this._grid, columnFilters, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},


	get_columnFilters: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilters">
		/// Gets the column filters array
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.ColumnFilter">Column filters </value>
		return this._columnFilters;
	},

	get_columnFiltersCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFiltersCount">
		/// Gets the number of column filters that are currently in the
		/// column filters array.
		/// </summary>
		/// <value type="Number" integer="true">the number of column filters that are currently in the
		/// column filters array.</value>
		return this._columnFilters.length;
	},

	get_columnFilter: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilter">
		/// Gets the column filter object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter at the specified index</value>
		if (index < 0 || index >= this._columnFilters.length)
			return null;
		else
			return this._columnFilters[index];
	},

	get_columnFilterFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilterFromKey">
		/// Gets the column filter object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter tied to the specified column key</value>
		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i].get_columnKey() === columnKey)
				return this._columnFilters[i];
		}

		return null;

	},

	get_columnFilterIndexOf: function (columnFilter)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFilterIndexOf">
		/// Gets the index of the specified column filter in the column filters array
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter whose index to look for.
		///</param>
		///<value type="Number" > Zero based index </value>

		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i] === columnFilter)
				return i;
		}

		return -1;
	},

	containsColumnFilter: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.containsColumnFilter">
		/// Determines whether a column filter object that is tied to the column with the specified column key
		/// is in the column filters array.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>
		/// <returns type="Boolean">Boolean value indicating whether the column filter currently 
		/// exists in the column filters array </returns>

		for (var i = 0; i < this._columnFilters.length; i++)
		{
			if (this._columnFilters[i].get_columnKey() === columnKey)
				return true;
		}
		return false;
	},

	removeColumnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removeColumnFilter">
		/// Deletes the column filter from the column filters array
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter to delete
		///</param>
		this.removedColumnFilterByKey(columnFilter.get_columnKey());
	},

	removedColumnFilterByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removedColumnFilterByKey">
		/// Deletes the column filter that is tied to the specified column key
		/// from the column filters array
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is tied to.
		///</param>

		
		if (!this.containsColumnFilter(columnKey))
			return;

		var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

		this._grid._actionList.add_transaction(new $IG.FilteringAction("RemoveColumnFilter", this.get_name(), this._grid, columnKey, null));
		this._grid._raiseClientEventEnd(eventArgs);


	},

	clearColumnFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.clearColumnFilters">
		/// Deletes all column filter from the column filters array
		/// </summary>

		if (this._columnFilters.length > 0)
		{
			var eventArgs = new $IG.ColumnFilterAddingRemovingEventArgs(this);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("ClearColumnFilters", this.get_name(), this._grid, null, null));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},


	get_columnFiltersInfo: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnFiltersInfo">
		/// Returns a json array, with the column names, column types, filtering
		/// rules and the filtering values the WebDataGrid is being filtered by. 
		/// Could be used only for client-side filtering when 
		/// EnableClientRendering property is set to true.
		/// </summary>
		/// <value type="Array"></value>

		if (!this._grid.get_enableClientRendering())
			return;

		var filters = [];
		var filter;

		
		this._clientColumnFilters = $.grep(this._clientColumnFilters, function (item)
		{
			return (item.get_condition().get_rule() != 0);
		});

		filters = this._createFilterInfo(filters, this._clientColumnFilters);
		filters = this._createFilterInfo(filters, this._columnFilters);

		return filters;
	},


	addClientColumnFilter: function (columnFilter)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.addClientColumnFilter">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Adds the column filter object to the column filters' collection		
		/// </summary>
		///<param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"  optional="false" mayBeNull="false">
		/// The column filter which to add to the collection this should be created via create_columnFilter
		/// method.
		///</param>

		if (this._grid.get_enableClientRendering() && !this.get_columnFilterFromKey(columnFilter.get_columnKey()))
			this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
	},

	removeClientColumnFilterByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.removeClientColumnFilterByKey">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Removes the column filter object from the column filters' collection, if it was created on the client,
		/// if the column filter came down from the server, its Rule just gets set to "Clear"  and its value to empty.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter is to be removed for.
		///</param>

		if (this._grid.get_enableClientRendering())
		{
			var columnFilter = this.get_columnFilterFromKey(columnKey);
			var deleteFilter = false;
			if (!columnFilter)
			{
				columnFilter = this._get_clientColumnFilterFromKey(columnKey);
				deleteFilter = true;
			}

			if (columnFilter)
			{
				this._clearClientColumnFilter(columnFilter);
				if (deleteFilter)
				{
					this._clientColumnFilters = $.grep(this._clientColumnFilters, function (colFilter, i)
					{
						return colFilter.get_columnKey() != columnKey;
					});
				}

			}

		}
	},
	_clearClientColumnFilter: function (columnFilter)
	{
		columnFilter.get_condition().set_rule(0);
		var column = this._grid.get_columns().get_columnFromKey(columnFilter.get_columnKey());
		if (column && column.get_type() != "boolean")
			columnFilter.get_condition().set_value("");
	},
	clearClientColumnFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.clearClientColumnFilters">
		/// This method should only be used when EnableClientRendering is set to true.
		/// Removes all the column filter objects from the column filters' collection, if they were created on the client,
		/// if the column filter came down from the server, its Rule just gets set to "Clear" and its value to empty.
		/// </summary>		

		if (this._grid.get_enableClientRendering())
		{
			var filtering = this;
			$.each(this._columnFilters, function ()
			{
				filtering._clearClientColumnFilter(this);
			});

			$.each(this._clientColumnFilters, function ()
			{
				filtering._clearClientColumnFilter(this);
			});
			this._clientColumnFilters = [];
		}
	},

	_createFilterInfo: function (filterInfo, columnFilters)
	{
		$.each(columnFilters, function ()
		{
			var value = this.get_condition().get_value();
			var rule = this.get_condition().get_rule();

			if (rule != 0)
			{
				if (this.get_columnType() == "boolean")
					value = (rule == 2 ? "false" : "true");
				filterInfo[filterInfo.length] = { "ColumnType": this.get_columnType(), "KeyColumn": this.get_columnKey(), "Rule": rule, "Value": value };
			}
		});
		return filterInfo;
	},

	

	
	get_columnSettings: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSettings">
		/// Gets the column filters settings collection
		/// </summary>
		/// <value type="Infragistics.Web.UI.ObjectCollection">column filters settings collection </value>
		return this._columnSettings;
	},
	

	

	get_columnSetting: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSetting">
		/// Gets the column filter setting object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilterSettings">The column filter setting at the specified index</value>
		if (index >= 0 && index < this._columnSettings._items.length)
			return this._columnSettings._items[index];
		else
			return null;
	},

	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.columnSettingFromKey">
		/// Gets the column filter setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column filter setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnFilterSettings">The column filter setting tied to the specified column key</value>

		for (var i = 0; i < this._columnSettings._items.length; i++)
		{
			if (this._columnSettings._items[i].get_columnKey() === columnKey)
				return this._columnSettings._items[i];
		}

		return null;
	},
	

	
	applyFilters: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.applyFilters">
		/// Filters the data by the current column filters.
		/// </summary>
		this._apply_filters(false);
	},

	get_caseSensitive: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.caseSensitive">
		/// Indicated whether filtering will be case sensitive or not.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("fcs");
	},

	get_alignment: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.alignment">
		/// Determines the location of the filter row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringAlignment">Location of the filter row</value>    
		return this._get_clientOnlyValue("fra");
	},

	get_filtered: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filtered">
		/// Indicated whether the grid data is currently filtered.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("fa");
	},

	get_visibility: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.visibility">
		/// Indicated whether the user interface (filter row) is visible.
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringVisibility">Visibility indicator</value>
		return this._get_value($IG.GridFilteringProps.Visibility);
	},

	set_visibility: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.visibility">
		/// Hides or displays the user interface (filter row).
		/// </summary>
		///<param name="value" type="Infragistics.Web.UI.FilteringVisibility"  optional="false" mayBeNull="false">
		/// An indicator that the filter row needs to be hidden or shown.
		///</param>

		this._set_value($IG.GridFilteringProps.Visibility, value);
		var scrollIntersection = this._grid._elements["filterInter"];
		if (value == $IG.FilteringVisibility.Visible)
		{
			this._row._element.style.display = "";
			if (scrollIntersection)
				scrollIntersection.style.display = "";

			




			if ($util.IsFireFox2 && this.get_alignment() == $IG.FilteringAlignment.Bottom)
			{
				var width = this._row._element.childNodes[0].style.width;
				elm = this._row._element.childNodes[0];
				elm.style.width = "0px";
				setTimeout($util.createDelegate(this, this._adjFootVisibility, [elm, width]), 1);
			}
			else
			{
				this._row._element.style.visibility = "visible";
				if (scrollIntersection)
				{
					scrollIntersection.style.visibility = "visible";
					this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
				}

			}
		}
		else
		{
			this._row._element.style.display = "none";
			this._row._element.style.visibility = "hidden";
			if (scrollIntersection)
			{
				scrollIntersection.style.display = "none";
				scrollIntersection.style.visibility = "hidden";
				this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
			}
		}
	},

	get_filterRuleDropdownZIndex: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filterRuleDropdownZIndex">
		/// Retruns the Z-Index of the filter rule dropdown element.  The default Z-Index is 100100
		/// </summary>
		/// <value type="Number">Z-Index of the filter rule dropdown element.</value>
		return this._get_value($IG.GridFilteringProps.RuleDropdownZIndex);
	},

	set_filterRuleDropdownZIndex: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.filterRuleDropdownZIndex">
		/// Sets the Z-Index of the filter rule dropdown element.
		/// </summary>
		///<param name="value" type="Number"  optional="false" mayBeNull="false">
		/// Z-Index of the filter rule dropdown element.
		///</param>

		if (value == null || value == undefined)
			return;

		this._set_value($IG.GridFilteringProps.RuleDropdownZIndex, value);

		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
				this._dropDownBehaviors[i].set_zIndex(value);
		}
	},

	get_animationEnabled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationEnabled">
		/// Indicates whether the filter rule dropdown will play an animation while it is displaying and hiding
		/// </summary>
		/// <value type="Boolean">True if an animation will play, false otherwise</value>
		return this._get_clientOnlyValue("fae");
	},

	get_animationType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationType">
		/// The type of animation that the filter rule dropdown will play when it is displaying and hiding.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AnimationEquationType">The animation type</value>
		return this._get_clientOnlyValue("fat");
	},

	get_animationDurationMs: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Filtering.animationDurationMs">
		/// The duration of the animation that the filter rule dropdown will play while its displaying or hiding 
		/// in milliseconds
		/// </summary>
		/// <value type="Number">Animation duration in milliseconds</value>
		return this._get_clientOnlyValue("fad");
	},

	updateFilterUI: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.updateFilterUI">
		/// This method should only be used if the EnableClientRendering property
		/// is set to true.  The method will go through all the exising columnFilters
		/// and update the filter buttons for the matching columns as filtered. 
		/// </summary>

		if (this._grid.get_enableClientRendering() && this._row)
		{
			var defaultAfterUrl = this._get_clientOnlyValue("defAftImg");
			var defaultBeforeUrl = this._get_clientOnlyValue("defBefImg");
			var beforeAltTxt = this._get_clientOnlyValue("defBefAlt");
			var filtering = this;

			

			$(this._row.get_element()).find("img[mkr = 'aftapp']").each(function ()
			{
				var cellElement = $($(this).parent()).parent();
				var adr = parseInt(cellElement.attr("adr"));
				adr = (isNaN(adr) ? filtering._grid._gridUtil._getColumnAdrFromVisibleIndex(filtering._grid._gridUtil.getCellIndexFromElem(cellElement.get(0))) : adr);
				var cell = filtering._row.get_cell(adr);
				var key = cell.get_column().get_key();

				var columnFilter = filtering.get_columnFilterFromKey(key);
				columnFilter = columnFilter ? columnFilter : filtering._get_clientColumnFilterFromKey(key);
				if (!columnFilter || columnFilter.get_condition().get_rule() == 0)
				{
					var setting = filtering.get_columnSettingFromKey(key);
					var beforeUrl = (setting ? setting._get_clientOnlyValue("befImg") : defaultBeforeUrl);
					var altText = (setting ? setting._get_clientOnlyValue("befAlt") : beforeAltTxt);

					$(($(this).attr("src", beforeUrl).attr("mkr", "befapp").attr("alt", altText).attr("title", altText)).parent()).attr("title", altText);
				}
			});

			

			$.each(this._columnFilters, function ()
			{
				filtering._updateColumnFilterUI(this, defaultAfterUrl);
			});

			

			$.each(this._clientColumnFilters, function ()
			{
				filtering._updateColumnFilterUI(this, defaultAfterUrl);
			});

			this._grid._onDataTblResize({ "clientHeight": this._grid._elements.dataTbl.clientHeight }, null);
			this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
		}
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Filtering.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the Filtering behavior removes all the event handlers that it
		/// had attached.
		/// </summary>

		if (!this._grid)
			return;

		delete this._hierarchical;

		

		
		this._closeRuleDropdown(this._visibleDropdownCell, 1);

		var targetsToDelete = [];
		var animationContainerToDelete = [];
		
		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
			{
				targetsToDelete[targetsToDelete.length] = this._dropDownBehaviors[i].get_targetContainer();
				animationContainerToDelete[animationContainerToDelete.length] = this._dropDownBehaviors[i].get_animationsContainer();
				this._dropDownBehaviors[i].dispose();
			}
			this._dropDownBehaviors[i] = null;
		}
		this._dropDownBehaviors = null;
		this._dropDownBehaviorsCount = 0;

		if (this._onMouseDownHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);
			delete this._onMouseDownHandler;
		}

		if (this._onMouseUpHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);
			delete this._onMouseUpHandler;
		}

		if (this._onMousewheelHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
			if ($util.IsFireFox)
				$removeHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
			try	
			{
				$removeHandler(this._gridContainer, "scroll", this._onMousewheelHandler);
			} catch (e) { }
			
			if (this._initializedParentGrids)
			{
				for (var x = 0; this._ancestorGridElements != null && x < this._ancestorGridElements.length; ++x)
				{
					try
					{
						$removeHandler(this._ancestorGridElements[x], "scroll", this._onMousewheelHandler);
					} catch (e) { }
					this._ancestorGridElements[x] = null;
				}
				delete this._ancestorGridElements;
				delete this._initializedParentGrids;
			}


			delete this._onMousewheelHandler;
		}

		if (this._onKeyDownHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'keydown', this._onKeyDownHandler);
			delete this._onKeyDownHandler;
		}

		if (this._onFilterKeyDownHandler)
		{
			$removeHandler(this._row._element, 'keydown', this._onFilterKeyDownHandler);
			delete this._onFilterKeyDownHandler;
		}

		var gridId = this._grid._id;
		var dropDown = $get(gridId + "_NumericRuleDropDown_UL");
		if (this._onSelectRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mousedown', this._onSelectRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mousedown', this._onSelectRuleHandler);
				} catch (e) { }
			}


			delete this._onSelectRuleHandler;
		}

		if (this._onMouseOverRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mouseover', this._onMouseOverRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mouseover', this._onMouseOverRuleHandler);
				} catch (e) { }
			}
			delete this._onMouseOverRuleHandler;
		}

		if (this._onMouseOutRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown_UL"), 'mouseout', this._onMouseOutRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mouseout', this._onMouseOutRuleHandler);
				} catch (e) { }
			}
			delete this._onMouseOutRuleHandler;
		}

		if (this._onKeyDownRuleHandler)
		{
			if (dropDown)
			{
				try
				{
					$removeHandler($get(gridId + "_NumericRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_TextRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_DateTimeRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
					$removeHandler($get(gridId + "_BooleanRuleDropDown"), 'keydown', this._onKeyDownRuleHandler);
				} catch (e) { }
			}
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'keydown', this._onKeyDownRuleHandler);
				} catch (e) { }
			}
			delete this._onKeyDownRuleHandler;
		}

		if (this._onKeyPressRuleHandler)
		{
			$removeHandler(document, 'keypress', this._onKeyPressRuleHandler);
			delete this._onKeyPressRuleHandler;
		}

		if (this._onGridResizeHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "Resize", this._onGridResizeHandler);
			delete this._onGridResizeHandler;
		}
		
		if (this._onpostnotify)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "PostBackStart", this._onpostnotify);
			delete this._onpostnotify;
		}

		if (!Sys.Application._disposing)
		{
			if (this._columnFilters && this._columnFilters.length)
			{
				for (var i = 0; i < this._columnFilters.length; i++)
				{
					if (this._columnFilters[i])
						this._columnFilters[i].dispose();
					this._columnFilters[i] = null;
				}
			}
		}
		this._columnFilters = null;

		if (this._clientColumnFilters && this._clientColumnFilters.length)
		{
			for (var i = 0; i < this._clientColumnFilters.length; i++)
			{
				if (this._clientColumnFilters[i])
					this._clientColumnFilters[i].dispose();
				this._clientColumnFilters[i] = null;
			}
		}
		this._clientColumnFilters = null;

		for (var i = 0; i < targetsToDelete.length; i++)
		{
			if (targetsToDelete[i] && targetsToDelete[i].parentNode)
			{
				targetsToDelete[i].parentNode.removeChild(targetsToDelete[i]);
				targetsToDelete[i] = null;
			}
		}
		targetsToDelete = null;

		for (var i = 0; i < animationContainerToDelete.length; i++)
		{
			if (animationContainerToDelete[i] && animationContainerToDelete[i].parentNode)
			{
				animationContainerToDelete[i].parentNode.removeChild(animationContainerToDelete[i]);
				animationContainerToDelete[i] = null;
			}
		}
		animationContainerToDelete = null;

		this._objectManager = null;
		this._activation = null;
		this._columnResizing = null;
		this._rowSelectors = null;
		this.editSpan = null;
		this.editFilterButton = null;
		this._visibleDropdownCell = null;
		this.__defaultDate = null;

		$IG.Filtering.callBaseMethod(this, "dispose");
		this._grid = null;
		this._gridElement = null;
		this._gridContainer = null;
		this._container = null;
		this._row.dispose();
		this._row = null;
	},

	

	
	_updateColumnFilterUI: function (columnFilter, defaultAfterUrl, afterUrl)
	{
		var condition = columnFilter.get_condition();
		var cell = condition._get_filterCell();
		if (cell)
		{
			var rule = condition.get_rule();
			var type = condition._type;

			if (rule != 0)
			{
				var setting = this.get_columnSettingFromKey(columnFilter.get_columnKey());
				var afterUrl = (setting ? setting._get_clientOnlyValue("aftImg") : defaultAfterUrl);
				var filterButton = cell.get_element().firstChild;

				$(filterButton.firstChild).attr("src", afterUrl).attr("mkr", "aftapp");

				var ruleElm = this._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
				if (ruleElm != null)
				{
					var title = ruleElm.innerHTML;
					$(filterButton).attr("title", title);
					$(filterButton.firstChild).attr("alt", title).attr("title", title);
				}
			}
		}
	},
	_adjFootVisibility: function (elm, width)
	{
		elm.style.width = width;
		this._row._element.style.visibility = "visible";
		var scrollIntersection = this._grid._elements["filterInter"];

		if (scrollIntersection)
		{
			scrollIntersection.style.visibility = "visible";
			this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
		}
	},

	_createObjects: function (objectManager)
	{
		objectManager.__createdObjectCount = 0;

		$IG.Filtering.callBaseMethod(this, "_createObjects", [objectManager]);
		var cos = objectManager.__createdObjectCount;
		this._objectManager = objectManager;
		this._columnFilters = [];
		var columnFiltersCount = parseInt(this._get_clientOnlyValue("cfc"));
		for (var i = 0; i < columnFiltersCount; i++)
		{
			var obj = new $IG.ColumnFilter("ColumnFilter", null, objectManager.get_objectProps(cos + i), this);
			objectManager.register_object(cos + i, obj);
			
			if (obj.get_columnType() == "number" && obj.get_condition() && isNaN(obj.get_condition().get_value()))
				obj.get_condition()._set_value($IG.FilteringNodeObjectProps.Value, "");
			this._columnFilters[i] = obj;
			obj = null;
		}
	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.ColumnFilterSettings, null, columnKey);

	},

	_enteringEditMode: function (eventArgs)
	{
		if (eventArgs.cell.get_row() === this._row)
		{
			if (this._grid._get_isAjaxCallInProgress())
			{
				eventArgs.customDisplay.cancel = true;
				return;
			}

			var filterSettings = this.get_columnSettingFromKey(eventArgs.cell._column._key);
			if ((filterSettings != null && !filterSettings.get_enabled()) || !this._allowEdit(eventArgs.cell) || eventArgs.cell._column.get_isTemplated())
			{
				eventArgs.customDisplay.cancel = true;
				return;
			}

			var left = eventArgs.cell._element.childNodes[0].offsetLeft + eventArgs.cell._element.childNodes[0].offsetWidth;
			eventArgs.customDisplay.width = eventArgs.cell._element.offsetWidth - left;
			eventArgs.customDisplay.width = (eventArgs.customDisplay.width < 0) ? 0 : eventArgs.customDisplay.width;

			eventArgs.customDisplay.height = eventArgs.cell._element.offsetHeight;
			eventArgs.customDisplay.left = (eventArgs.cell._element.offsetLeft + left);
			eventArgs.customDisplay.top = eventArgs.cell._element.offsetTop;

			this.editFilterButton = eventArgs.cell._element.childNodes[0].cloneNode(true);
			this.editSpan = eventArgs.cell._element.childNodes[1].cloneNode(true);

			

			if (eventArgs.cell._element.getAttribute("val") != null && eventArgs.cell._element.getAttribute("val") != "null")
				eventArgs.customDisplay.text = eventArgs.cell.get_value();
			else
			{
				var txtElem = eventArgs.cell._element.childNodes[1];
				if ($util.IsIE && txtElem.childNodes && txtElem.childNodes.length == 1 && txtElem.childNodes[0].nodeName == "#comment")
					eventArgs.customDisplay.text = "";
				else
					eventArgs.customDisplay.text = $util.htmlUnescapeCharacters(txtElem.innerHTML);
			}

			this._grid._gridUtil._fireEvent(this._grid, "FilterCellEnteringEdit", eventArgs);
		}
	},

	_allowEdit: function (cell)
	{
		var column = cell._column;
		var type = column.get_type();
		var key = column._key;
		var columnFilter = this.get_columnFilterFromKey(key);
		columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(key);

		var rule = (columnFilter ? columnFilter.get_condition().get_rule() : null);

		if (type === "boolean")
			return false;
		else if (type === "date" && columnFilter &&
            !(rule === $IG.DateTimeFilterRules.All ||
            rule === $IG.DateTimeFilterRules.Equals ||
            rule === $IG.DateTimeFilterRules.Before ||
            rule === $IG.DateTimeFilterRules.After))
			return false;
		else if (type === "number" && (rule === $IG.NumericFilterRules.IsNull || rule === $IG.NumericFilterRules.IsNotNull))
			return false;
		else if (type === "string" && (rule === $IG.TextFilterRules.IsNull || rule === $IG.TextFilterRules.IsNotNull))
			return false;

		return true;

	},

	_exitedEditMode: function (eventArgs)
	{
		if (eventArgs.cell.get_row() === this._row && eventArgs.update)
		{			
			var value = eventArgs.inputValue;
			var text = eventArgs.cell._element.innerHTML;

			

			if (eventArgs.valueChanged && !(eventArgs.cell._element.childNodes.length == 2 &&
				eventArgs.cell._element.firstChild.tagName == "BUTTON" && eventArgs.cell._element.lastChild.tagName == "SPAN"))
			{
				

				if (text.toLowerCase().indexOf("<button") == 0)
				{
					eventArgs.cell._element.innerHTML = "";
					eventArgs.cell._set_value_internal(value);
				}
				if (eventArgs.cell._element.lastChild)
					eventArgs.cell._element.removeChild(eventArgs.cell._element.lastChild);
				eventArgs.cell._element.appendChild(this.editFilterButton);
				this.editSpan.innerHTML = text;
				eventArgs.cell._element.appendChild(this.editSpan);
				eventArgs.cell._dropDownBehaviour._sourceElement = this.editFilterButton;
			}

			
			var colKey = eventArgs.cell._column._key;
			var columnFilter = this.get_columnFilterFromKey(colKey);
			var saveFilterNeeded = columnFilter ? false : true;

			columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(colKey);

			if (!columnFilter)
			{
				columnFilter = this.create_columnFilter(colKey);
				this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
			}
			

			var oldVal = columnFilter.get_condition().get_value();
			if (eventArgs.valueChanged)
				columnFilter.get_condition().set_value(value);
			var newVal = columnFilter.get_condition().get_value();
			var type = eventArgs.cell._column.get_type();
			
			var valueChanged = ((oldVal != newVal) || (typeof (oldVal) != typeof (newVal)));
			
			valueChanged = (type != "date") ? valueChanged : valueChanged && !((oldVal == null || oldVal == this.__defaultDate) && (newVal == "" || newVal == null));
			this.editSpan = null;
			this.editFilterButton = null;
			






			if ((saveFilterNeeded && valueChanged) ||
				(columnFilter.get_condition().get_rule() != 0 && (newVal !== "" || valueChanged)))
				this._apply_filters(true);

		}

	},


	_apply_filters: function (addClientFilters)
	{
		var columnFilterToAdd = null;
		if (addClientFilters && this._clientColumnFilters && this._clientColumnFilters.length > 0)
			columnFilterToAdd = this._clientColumnFilters;

		var eventArgs = new $IG.CancelApplyFiltersEventArgs(this, this._columnFilters, columnFilterToAdd);
		eventArgs = this._grid._raiseSenderClientEventStart(this, this._clientEvents["DataFiltering"], eventArgs);

		if (!eventArgs.get_cancel())
		{
			var noPost = (eventArgs._props[1] == 2);

			this._grid._actionList.add_transaction(new $IG.FilteringAction("ApplyFilter", this.get_name(), this._grid, columnFilterToAdd, null));
			if (!noPost)
				this._owner._postAction(1);
			else
				this._owner._raiseClientEventEnd(eventArgs);
		}

		if (!this._grid.get_enableClientRendering())
			eventArgs._dispose();
	},
	_onClickHandler: function (evnt)
	{
		if (this._grid._get_isAjaxCallInProgress())
			return;

		if (this.get_cellInEditMode() && this.get_cellInEditMode().get_row() === this._row)
		{
			this.exitEditMode(true);
			return;
		}
		var element;
		var td;

		if ($util.IsSafari && evnt.target.getAttribute("mkr") == "befapp"
			|| evnt.target.getAttribute("mkr") == "aftapp")
		{
			element = evnt.target;
			td = evnt.target.parentNode.parentNode;
		}
		else
		{
			element = evnt.target.firstChild;
			td = evnt.target.parentNode;
		}
		
		this._getParentGridElements();

		if (element && element.nodeName == "IMG" &&
            (element.getAttribute("mkr") == "befapp" || element.getAttribute("mkr") == "aftapp"))
		{
			var cell = this._grid._gridUtil.getCellFromElem(td);
			if (!cell)
			{
				var cellIndex = this._grid._gridUtil.getCellIndexFromElem(td);
				var filterRow = this._row;
				
				var cellAdr = this._grid._gridUtil._getColumnAdrFromVisibleIndex(cellIndex);
				cell = filterRow.get_cell(cellAdr);
			}

			if (cell != null)
			{

				if ($util.IsSafari && this._visibleDropdownCell)
				{
					if (cell != this._visibleDropdownCell)
						this._closeRuleDropdown(this._visibleDropdownCell);
				}

				if (cell._dropDownBehaviour.get_visible())
				{
					this._closeRuleDropdown(cell);
				}
				else
				{
					if (this._visibleDropdownCell && !this._visibleDropdownCell._dropDownBehaviour.get_visible())
						this._visibleDropdownCell = null;

					if (!this._visibleDropdownCell) // this will prevent another filter rule dropdown from being opened if the FilterDropdownHiding event was canceled
					{
						cell._dropDownBehaviour.set_visible(true);
						

						var cancelledOrHidden = cell._dropDownBehaviour.get_enableAnimations() ? !cell._dropDownBehaviour.get_isAnimating() : !cell._dropDownBehaviour.get_visible();
						if (!cancelledOrHidden)
						{
							var columnFilter = this.get_columnFilterFromKey(cell._column._key);
							columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(cell._column._key);
							if (columnFilter)
							{
								var item = this._getRuleElement(columnFilter.get_condition().get_rule(), cell._dropDownBehaviour.get_targetContainer());
								if (item != null)
									item.className = this._ruleDDSelectedItemCss;
							}
							this._currentRuleItem = null;
							


							if ($util.IsFireFox)
								cell._dropDownBehaviour.get_targetContainer().firstChild.firstChild.focus();
							else
								cell._dropDownBehaviour.get_targetContainer().firstChild.focus();
							this._visibleDropdownCell = cell;
						}
					}
				}
			}


		}
		else
			$IG.Filtering.callBaseMethod(this, "_onClickHandler", [evnt]);

	},



	


	_onDblclickHandler: function (evnt)
	{
		if (evnt.target.firstChild && evnt.target.firstChild.nodeName == "IMG" &&
            (evnt.target.firstChild.getAttribute("mkr") == "befapp" || evnt.target.firstChild.getAttribute("mkr") == "aftapp"))
			this._onClickHandler(evnt);
		else
			$IG.Filtering.callBaseMethod(this, "_onDblclickHandler", [evnt]);
	},

	_closeRuleDropdown: function (cell, ifVisible)
	{
		
		var ddb = cell ? cell._dropDownBehaviour : null;
		if (!ddb || (ifVisible && !ddb.get_visible()))
			return true;
		ddb.set_visible(false);

		

		var cancelledOrHidden = ddb.get_enableAnimations() ? !ddb.get_isAnimating() : ddb.get_visible();
		if (!cancelledOrHidden)
		{
			
			var item = this._getSelectedRuleElement(ddb.get_targetContainer());
			if (item != null)
				item.className = this._ruleDDItemCss;

			this._visibleDropdownCell = null;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");
		}
		return cancelledOrHidden;
	},

	_getRuleElement: function (rule, dropdownDiv)
	{
		var lu = dropdownDiv.firstChild;
		if (lu && lu.childNodes && lu.childNodes.length > 0)
		{
			for (var i = 0; i < lu.childNodes.length; i++)
			{
				if (lu.childNodes[i].getAttribute("val") == rule)
				{
					return lu.childNodes[i];
				}
			}
		}
		return null;
	},
	_getSelectedRuleElement: function (dropdownDiv)
	{
		var lu = dropdownDiv.firstChild;
		if (lu && lu.childNodes && lu.childNodes.length > 0)
		{
			for (var i = 0; i < lu.childNodes.length; i++)
			{
				if (lu.childNodes[i].className == this._ruleDDSelectedItemCss)
				{
					return lu.childNodes[i];
				}
			}
		}
		return null;
	},

	_onSelectRule: function (evnt)
	{
		
		if (!this._visibleDropdownCell || (evnt.button != 0 && evnt.keyCode != Sys.UI.Key.enter))
			return;

		var rule = parseInt(evnt.target.getAttribute("val"));
		var column = this._visibleDropdownCell._column;
		var key = column._key;
		var type = column.get_type();
		var columnFilter = this.get_columnFilterFromKey(key);
		columnFilter = columnFilter ? columnFilter : this._get_clientColumnFilterFromKey(key);

		if (!columnFilter)
		{
			columnFilter = this.create_columnFilter(key);
			this._clientColumnFilters[this._clientColumnFilters.length] = columnFilter;
		}
		var oldRule = columnFilter.get_condition().get_rule();
		columnFilter.get_condition().set_rule(rule);

		if (type != "boolean" && rule == 0) // ALL or Clear Filter rule is being applied so we have to clear the value
			columnFilter.get_condition().set_value("");
		
		if (type == "number" && columnFilter.get_condition().get_rule() >= $IG.NumericFilterRules.IsNull)
			columnFilter.get_condition().set_value("");

		var allowEdit = this._allowEdit(this._visibleDropdownCell);
		if ((type == "boolean" && oldRule != rule) || (!allowEdit && oldRule != rule) || (rule == 0 && oldRule != rule))
		{
			if (!this._closeRuleDropdown(this._visibleDropdownCell)) // if the dropdown hiding was not canceled then filter
			{
				this._apply_filters(true);
			}
		}
		else if (allowEdit)
		{
			var cell = this._visibleDropdownCell;
			if (!this._closeRuleDropdown(this._visibleDropdownCell) && rule != 0)
			{
				this.enterEditMode(cell);
			}
			else
			{
				if (this._grid.get_enableClientRendering())
					this._apply_filters(true);
			}
		}

		if (this._grid.get_enableClientRendering())
			if ((type == "boolean") && (rule == 0))
				this._apply_filters(true);
	},

	_get_clientColumnFilterFromKey: function (columnKey)
	{
		/// <returns type="ColumnFilter">The column filter tied to the specified column key</returns>
		for (var i = 0; i < this._clientColumnFilters.length; i++)
		{
			if (this._clientColumnFilters[i].get_columnKey() === columnKey)
				return this._clientColumnFilters[i];
		}

		return null;

	},

	_onMouseOverRule: function (evnt)
	{
		if (evnt.target.tagName === "LI")
		{
			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			// add the hover class to the item
			evnt.target.className = evnt.target.className + " " + this._ruleDDHoverItemCss;
			this._currentRuleItem = evnt.target;
		}
	},

	_onMouseOutRule: function (evnt)
	{
		if (evnt.target.tagName === "LI")
		{
			
			evnt.target.className = evnt.target.className.replace(" " + this._ruleDDHoverItemCss, "");
			
			if (this._currentRuleItem && this._currentRuleItem != evnt.target)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");
			this._currentRuleItem = null;
		}
	},

	_onMouseDown: function (evnt)
	{
		this._closeDropdownOnscroll(evnt);
	},

	_onMouseUp: function (evnt)
	{
		this._closeDropdownOnscroll(evnt);
	},

	_onGridResize: function (evnt)
	{
		
		this._closeRuleDropdown(this._visibleDropdownCell, 1);
	},

	_onKeyDown: function (evnt)
	{
		if ((this._visibleDropdownCell != null) && (evnt.keyCode == Sys.UI.Key.left || evnt.keyCode == Sys.UI.Key.right ||
            evnt.keyCode == Sys.UI.Key.up || evnt.keyCode == Sys.UI.Key.down || evnt.keyCode == Sys.UI.Key.pageUp
            || evnt.keyCode == Sys.UI.Key.pageDown))
		{
			this._closeRuleDropdown(this._visibleDropdownCell);
		}
	},

	_onFilterKeyDown: function (evnt)
	{
		if (this._activation)
		{
			var activeCell = this._activation.get_activeCell();
			if (activeCell && activeCell.get_row() == this._row)
			{
				if (evnt.target.nodeName != "BUTTON" && evnt.keyCode == Sys.UI.Key.tab)
				{
					if (!evnt.shiftKey)
					{
						

						try
						{
							activeCell._element.childNodes[0].focus();
							$util.cancelEvent(evnt);
							if ($util.IsOpera)
								this._OperaCancelEvent = true;
						}
						catch (e) { }
					}
					else
					{
						var prevCell = this._grid._gridUtil.getPrevCell(activeCell);

						if (prevCell && prevCell.get_row() === this._row)
						{
							this._activation.set_activeCell(prevCell, false);

							

							try
							{
								prevCell._element.childNodes[0].focus();
								$util.cancelEvent(evnt);
								if ($util.IsOpera)
									this._OperaCancelEvent = true;
							}
							catch (e) { }
						}

					}
				}
				else if (evnt.target.nodeName == "BUTTON")
				{
					if (evnt.keyCode == Sys.UI.Key.enter)
					{
						this._onClickHandler(evnt);
						$util.cancelEvent(evnt);
						if ($util.IsOpera)
							this._OperaCancelEvent = true;
					}
					else if (evnt.keyCode == Sys.UI.Key.tab && evnt.shiftKey)
					{
						if ($util.IsIE || $util.IsOpera)
							this._grid._gridUtil.scrollCellIntoViewIE(activeCell);
						else
							activeCell._element.focus();
						$util.cancelEvent(evnt);
						if ($util.IsOpera)
							this._OperaCancelEvent = true;
					}
				}
			}
		}

	},

	_onKeyDownRule: function (evnt)
	{
		var items = evnt.target.tagName == "LI" ? evnt.target.parentNode : evnt.target;
		if (evnt.keyCode == Sys.UI.Key.up)
		{
			var nextItem = (!this._currentRuleItem) ? items.firstChild : this._currentRuleItem.previousSibling;

			if (!nextItem)
				nextItem = items.lastChild;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			nextItem.focus();
			nextItem.className = nextItem.className + " " + this._ruleDDHoverItemCss;

			this._currentRuleItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.down)
		{
			var nextItem = (!this._currentRuleItem) ? items.firstChild : this._currentRuleItem.nextSibling;

			if (!nextItem)
				nextItem = items.firstChild;

			
			if (this._currentRuleItem && this._currentRuleItem.className)
				this._currentRuleItem.className = this._currentRuleItem.className.replace(" " + this._ruleDDHoverItemCss, "");

			nextItem.focus();
			nextItem.className = nextItem.className + " " + this._ruleDDHoverItemCss;

			this._currentRuleItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.enter)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;

			if (this._currentRuleItem)
			{
				evnt.target = this._currentRuleItem;
				this._onSelectRule(evnt);
			}
			else
			{
				var button = this._visibleDropdownCell._element.firstChild;
				this._closeRuleDropdown(this._visibleDropdownCell);
				button.focus();
			}

		}
		else if (evnt.keyCode == Sys.UI.Key.esc)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;

			var button = this._visibleDropdownCell._element.firstChild;
			this._closeRuleDropdown(this._visibleDropdownCell);
			button.focus();
		}

	},

	_onKeyPressRule: function (evnt)
	{
		
		if (this._OperaCancelEvent)
		{
			$util.cancelEvent(evnt);
			this._OperaCancelEvent = false;
		}
	},

	_onMousewheel: function (evnt)
	{
		this._closeDropdownOnscroll(evnt);
	},

	_onColumnResize: function (evnt)
	{
		
		this._closeRuleDropdown(this._visibleDropdownCell);
	},

	_closeDropdownOnscroll: function (evnt)
	{
		if (this._visibleDropdownCell != null)
		{
			
			
			var target = btn = evnt.target;
			if (btn && btn.nodeName == "IMG" && (btn.getAttribute("mkr") == "befapp" || btn.getAttribute("mkr") == "aftapp"))
				btn = btn.parentNode;

			if (target != this._visibleDropdownCell._dropDownBehaviour.get_targetContainer()
	            && btn != this._visibleDropdownCell._dropDownBehaviour.get_sourceElement())
				if (this._visibleDropdownCell._dropDownBehaviour.get_visible())
				{
					


					this._closeRuleDropdown(this._visibleDropdownCell);
					return false;
				}
		}
	},

	_onActiveCellChanging: function (evnt)
	{
		if (evnt.activeCell && evnt.cell)
		{
			var newRow = evnt.cell.get_row();
			if (newRow === this._row && evnt.keyCode == Sys.UI.Key.tab
			&& this._row !== evnt.activeCell.get_row() && evnt.cell === this._grid._gridUtil.getPrevCell(evnt.activeCell))
				this.focusOnBtn = true;
		}
	},

	_onActiveCellChanged: function (evnt)
	{
		if (this._visibleDropdownCell != null)
			this._closeDropdownOnscroll(evnt);
		else if (this.focusOnBtn)
		{
			this.focusOnBtn = false;
			

			try
			{
				evnt.cell._element.childNodes[0].focus();
			}
			catch (e) { }
		}
	},

	_onSelectstartHandler: function (evnt)
	{
		
		var currentElement = evnt.target;
		
		while (currentElement != null && currentElement.mkr != "filterRow")
			currentElement = currentElement.parentNode;

		if (currentElement != null && currentElement.mkr == "filterRow")
			$util.cancelEvent(evnt);
	},
	
	_initializeComplete: function ()
	{
		this._container = this._row._element;

		$IG.Filtering.callBaseMethod(this, "_initializeComplete");

		
		var cellCount = this._row.get_cellCount();
		var offset = this._grid._get_cellIndexOffset();
		for (var x = 0; x < cellCount; ++x)
		{
			var cellEl = this._row._get_cellElementByIndex(this._row._element, x + offset);
			var btn = cellEl ? cellEl.firstChild : null;
			if (btn && btn.tagName == "BUTTON")
				btn.tabIndex = -1;
		}

		this._addEnteringEditEventListener(Function.createDelegate(this, this._enteringEditMode));
		this._addExitedEditEventListener(Function.createDelegate(this, this._exitedEditMode));

		this._grid._registerAuxRow(this._row, (this.get_alignment() == $IG.FilteringAlignment.Top ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom))
		this._activation = this._grid.get_behaviors().get_activation();

		if (this._activation)
		{
			this._activation._addActiveCellChangingEventHandler(Function.createDelegate(this, this._onActiveCellChanging));
			this._activation._addActiveCellChangedEventHandler(Function.createDelegate(this, this._onActiveCellChanged));
		}

		this._columnResizing = this._grid.get_behaviors().get_columnResizing();
		if (this._columnResizing)
		{
			this._columnResizing._addStartColumnResizingEventListener(Function.createDelegate(this, this._onColumnResize));
		}
		this._rowSelectors = this._grid.get_behaviors().get_rowSelectors();
		if (this._rowSelectors)
			this._rowSelectors.addSelectorImage(this._row, this._get_clientOnlyValue("frsic"));

		
		
		var addedFilterKeys = this._get_clientOnlyValue("ack");
		if (addedFilterKeys && this._clientEvents["ColumnFilterAdded"])
		{
			var columnKeys = Sys.Serialization.JavaScriptSerializer.deserialize(addedFilterKeys);
			for (var i = 0; i < columnKeys.length; i++)
			{
				var columnFilter = this.get_columnFilterFromKey(columnKeys[i]);
				this._grid._raiseSenderClientEvent(this, this._clientEvents['ColumnFilterAdded'], new $IG.ColumnFilterAddedArgs(columnFilter));
			}
		}

		
		if (this.get_filtered())
		{

			if ($util.IsIE8 && this._hierarchical)
				this._grid._forceParentResize = true;
			if (this._clientEvents["DataFiltered"])
				this._grid._raiseSenderClientEvent(this, this._clientEvents['DataFiltered'], new $IG.DataFilteredArgs(this.get_columnFilters()));
		}

		
		
		if ($util.IsFireFox4Plus)
		{
			this._onpostnotify = Function.createDelegate(this, this._onPostNotify);
			this._grid._gridUtil._registerEventListener(this._grid, "PostBackStart", this._onpostnotify);
		}

	},

	_get_editContainer: function ()
	{
		return this._row._element;
	},

	_get_totalRowCount: function ()
	{
		



		return this._get_clientOnlyValue("ftrowcnt");
	},

	
	_getParentGridElements: function ()
	{
		if (this._initializedParentGrids || !this._hierarchical)
			return;
		this._initializedParentGrids = true;
		if (this._ancestorGridElements == null)
			this._ancestorGridElements = [];
		var parentRow = this._grid.get_parentRow();
		while (parentRow != null)
		{
			var grid = parentRow.get_grid();
			this._ancestorGridElements[this._ancestorGridElements.length] = grid._elements["container"];
			$addHandler(grid._elements["container"], "scroll", this._onMousewheelHandler);
			parentRow = grid.get_parentRow();
		}
	},

	
	_onPostNotify: function ()
	{
		if (!this.get_cellInEditMode() || this._isExitingEditMode)
			return;
		this.exitEditMode(false);
	}
}
$IG.Filtering.registerClass('Infragistics.Web.UI.Filtering', $IG.GridEditBase);




$IG.FilterRow = function (adr, element, props, owner, csm, filteringBehavior)
{
	///<summary locid="T:J#Infragistics.Web.UI.FilterRow">
	///Override of the GridRow object. Adds functionality for the filter row off the grid.
	///</summary>
	/// <param name="adr" type="Number">The row index at which the HTML element of the row appears.</param>
	/// <param name="element" domElement="true">The html element of the row.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.GridRowCollection" mayBeNull="true">The rows collection to which the row belongs.</param>
	/// <param name="csm" type="Infragistics.Web.UI.ObjectClientStateManager">The clientStateManager for the object.</param>
	/// <param name="filteringBehavior" type="Infragistics.Web.UI.Filtering">The filtering behavior that the row belongs to.</param>

	$IG.FilterRow.initializeBase(this, [adr, element, props, owner, csm]);
	this._filteringBehavior = filteringBehavior;

}

$IG.FilterRow.prototype =
{
	

	_create_item: function (adr, index)
	{
		var cell = $IG.FilterRow.callBaseMethod(this, '_create_item', [adr, index]);
		var filterSettings = this._filteringBehavior.get_columnSettingFromKey(cell._column._key);
		if ((filterSettings == null || filterSettings.get_enabled()) && !cell._column.get_isTemplated())
		{
			cell.__set_overrideCellUpdate(true);
			cell.__set_alwaysSetText(true);
			var btn = cell.get_element().childNodes[0];
			cell._dropDownBehaviour = new $IG.DropDownBehavior(btn, false);

			
			this._filteringBehavior._dropDownBehaviors[this._filteringBehavior._dropDownBehaviorsCount++] = cell._dropDownBehaviour;

			var columnType = cell._column.get_type();
			var elmClone;
			if (columnType == "number")
				elmClone = $get(cell._owner._id + "_NumericRuleDropDown").cloneNode(true);
			else if (columnType == "date")
				elmClone = $get(cell._owner._id + "_DateTimeRuleDropDown").cloneNode(true);
			else if (columnType == "boolean")
			{
				elmClone = $get(cell._owner._id + "_BooleanRuleDropDown").cloneNode(true);
				if (cell._column._isCheck)
				{
					var trueOption = elmClone.firstChild.firstChild.nextSibling;
					var falseOption = trueOption.nextSibling;
					var partialOption = falseOption.nextSibling;
					trueOption.innerHTML = cell._column._checkedAlt.replace("{0}", trueOption.innerHTML);
					falseOption.innerHTML = cell._column._uncheckedAlt.replace("{0}", falseOption.innerHTML);
					partialOption.innerHTML = cell._column._partialAlt.replace("{0}", "Null");
				}
			}
			else
				elmClone = $get(cell._owner._id + "_TextRuleDropDown").cloneNode(true);
			elmClone.id = elmClone.id + "_" + cell._column._key;

			
			if (!$util.IsIE || $util.IsIE9Plus)
			{
				
				$addHandler(elmClone.firstChild, 'mousedown', this._filteringBehavior._onSelectRuleHandler);
				$addHandler(elmClone.firstChild, 'mouseover', this._filteringBehavior._onMouseOverRuleHandler);
				$addHandler(elmClone.firstChild, 'mouseout', this._filteringBehavior._onMouseOutRuleHandler);
				$addHandler(elmClone, 'keydown', this._filteringBehavior._onKeyDownRuleHandler);
			}
			cell._dropDownBehaviour.set_targetContainer(elmClone);
			cell._dropDownBehaviour.set_zIndex(this._filteringBehavior.get_filterRuleDropdownZIndex());
			cell._dropDownBehaviour.set_animationDurationMs(this._filteringBehavior.get_animationDurationMs());
			cell._dropDownBehaviour.set_enableAnimations(this._filteringBehavior.get_animationEnabled());
			cell._dropDownBehaviour.set_animationType(this._filteringBehavior.get_animationType());

			cell._dropDownBehaviour.set_visibleOnBlur(false);

			if (this._filteringBehavior.get_alignment() == $IG.FilteringAlignment.Top)
				cell._dropDownBehaviour.set_position($IG.DropDownPopupPosition.Default);
			else
				cell._dropDownBehaviour.set_position($IG.DropDownPopupPosition.TopLeft);

			
			if (this._filteringBehavior._clientEvents['FilterDropdownDisplaying'])
			{
				// this will be invoked before the dropdown is physically shown on the screen
				cell._dropDownBehaviour.get_Events().addSettingVisibleHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownDisplaying"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownDisplayed'])
			{
				// this will be invoked after the dropdown container has been shown
				cell._dropDownBehaviour.get_Events().addSetVisibleHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownDisplayed"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownHiding'])
			{
				// this will be invoked before the dropdown is physically hidden on the screen
				cell._dropDownBehaviour.get_Events().addSettingHiddenHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownHiding"));
			}
			if (this._filteringBehavior._clientEvents['FilterDropdownHidden'])
			{
				// this will be invoked after the dropdown container has been hidden
				cell._dropDownBehaviour.get_Events().addSetHiddenHandler(this._filteringBehavior.get_events().getHandler("FilterDropdownHidden"));
			}

			elmClone = null;
			cell._dropDownBehaviour.init();
		}

		return cell;
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.FilterRow.dispose">
		/// Disposes of the object.
		///</summary>
		for (var i = 0; i < this._cells.length; i++)
		{
			if (this._cells[i] && this._cells[i]._dropDownBehaviour)
			{
				this._cells[i]._dropDownBehaviour = null;
				this._cells[i].dispose();
			}
		}
		this._filteringBehavior = null;
		$IG.FilterRow.callBaseMethod(this, "dispose");
	}

}

$IG.FilterRow.registerClass('Infragistics.Web.UI.FilterRow', $IG.GridRow);


$IG.ColumnFilterSettings = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFilterSettings">
	/// Object that defines a column filter setting for the grid column.
	/// </summary>
	/// <param name="adr" type="Number">The index of the object in the collection.</param>
	/// <param name="element" domElement="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.ObjectCollection">The collection to which the setting belongs.</param>
	/// <param name="csm" type="Infragistics.Web.UI.ObjectClientStateManager">The clientStateManager for the object.</param>
	$IG.ColumnFilterSettings.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnFilterSettings.prototype =
{
	get_enabled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilterSettings.enabled">
		/// Indicates whether filtering is enabled on the particular column.
		/// </summary>
		/// <value type="Boolean">True if filtering is enabled for the column, false otherwise</value>
		return this._get_clientOnlyValue("fse");
	}
}
$IG.ColumnFilterSettings.registerClass('Infragistics.Web.UI.ColumnFilterSettings', $IG.ColumnEditableSetting);




$IG.ColumnFilter = function (obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFilter">
	/// Object that defines a column filter for the grid column.
	/// </summary>
	/// <param name="obj" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.Filtering">The filtering behavior to which the column filter belongs.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]);
	$IG.ColumnFilter.initializeBase(this, [obj, element, props, control, csm]); //(this, [adr, element, props, owner, csm]); 

}

$IG.ColumnFilter.prototype =
{
	get_columnKey: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.columnKey">
		/// Gets the key of the column that the column filter is tied to.
		/// </summary>
		/// <value type="String">Column key</value>
		return this._get_clientOnlyValue("cfk");
	},

	get_columnType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.columnType">
		/// Gets the data type of the grid column that the column filter is tied to.		
		/// </summary>
		/// <value type="String">Column type could be one of the following: date, boolean, number or string </value>
		return this._get_clientOnlyValue("cft");
	},

	get_condition: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFilter.condition">
		/// Rule and value based filtering condition that will apply to the ControlDataField which 
		/// the ColumnFilter is tied to.		
		/// </summary>
		/// <value type="Infragistics.Web.UI.FilteringNodeObject">Filtering condition</value>

		if (this._condition == null)
		{
			this._condition = new $IG.FilteringNodeObject("FilteringNodeObject", this._element, this._objectManager.get_objectProps(0), this);
			this._objectManager.register_object(0, this._condition);
		}
		return this._condition;
	},

	_createObjects: function (objectManager)
	{
		this._objectManager = objectManager;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFilter.dispose">
		/// Disposes of the object.
		/// </summary>

		this._objectManager = null;
		$IG.ColumnFilter.callBaseMethod(this, "dispose");
	}

}
$IG.ColumnFilter.registerClass('Infragistics.Web.UI.ColumnFilter', $IG.ObjectBase);




$IG.FilteringNodeObject = function (obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringNodeObject">
	/// Object that defines rule and value based filtering condition.
	/// </summary>
	/// <param name="obj" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.ColumnFilter">The column filter to which the object belongs.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]);
	$IG.FilteringNodeObject.initializeBase(this, [obj, element, props, control, csm]);
	this._columnFilter = this._owner;
	this._gridFiltering = this._columnFilter._owner;
	this._grid = this._gridFiltering._owner;
	
}
$IG.FilteringNodeObject.prototype =
{
	get_rule: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.rule">
		/// Gets the filter condition rule. The return type will be one of the following, based on the column type: 
		/// TextFilterRules, NumericFilterRules, DateTimeFilterRules, or BooleanFilterRules
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// TextFilterRules, NumericFilterRules, DateTimeFilterRules, or BooleanFilterRules
		/// </value>

		return this._get_value($IG.FilteringNodeObjectProps.Rule);
	},

	set_rule: function (rule)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.rule">
		/// Sets the filter condition rule.
		/// </summary>
		/// <param name="rule" optional="false" mayBeNull="false">
		/// The type of the rule will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules,
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </param> 

		this._set_value($IG.FilteringNodeObjectProps.Rule, rule);

		
		var cell = this._get_filterCell();
		var ruleElm = this._gridFiltering._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
		if (ruleElm != null)
		{
			cell.get_element().childNodes[0].childNodes[0].alt = ruleElm.innerHTML;
			cell.get_element().childNodes[0].childNodes[0].title = ruleElm.innerHTML;
			cell.get_element().childNodes[0].title = ruleElm.innerHTML;
		}
	},

	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.value">
		/// Gets the filter condition value. The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </value>
		var columnType = this._columnFilter.get_columnType();
		var value = this._get_value($IG.FilteringNodeObjectProps.Value);

		if (columnType == "date")					
			value = this._grid._gridUtil._convertServerDateStringToClientObject(value);
		return value;
	},

	set_value: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FilteringNodeObject.value">
		/// Sets the filter condition value.
		/// </summary>
		/// <param name="value" optional="false" mayBeNull="false">
		/// The type of the value will be one of the following, based on the column type: 
		/// String, Number, Date
		/// </param>
		var columnType = this._columnFilter.get_columnType();
		if (columnType == "boolean")
			return;

		var column = this._grid.get_columns().get_columnFromKey(this._columnFilter.get_columnKey());
		var cell = this._get_filterCell();
		var valueToSave = cell.__parseValue(value);
		var text = column._formatValue(valueToSave);

		if (columnType == "number")
		{
			var parsedValue = parseFloat(value);
			if (isNaN(parsedValue))
			{
				valueToSave = "";
				text = "";
			}
		}
		else if (columnType == "date")
		{
			cell.__dateAdjusted = true;
			if (value == null)
			{
				valueToSave = "";
				text = "";
			}
			else if (typeof (value) != "object" || typeof (value.getMonth) == "undefined")
			{
				
				var parsedValue = Date.parseLocale(value);
				if (isNaN(parsedValue) || parsedValue == null || parsedValue == undefined)
				{
					valueToSave = "";
					text = "";
				}
				else				
					valueToSave = this._grid._gridUtil._convertClientDateToServerString(parsedValue);
			}
			else
				valueToSave = this._grid._gridUtil._convertClientDateToServerString(valueToSave);
		}
		this._set_value($IG.FilteringNodeObjectProps.Value, valueToSave);
		cell.get_element().childNodes[1].innerHTML = $util.htmlEscapeCharacters(text);
		if (text == "" && $util.IsIE)
		{
			cell.get_element().childNodes[1].appendChild(document.createComment(""));
		}


	},
	_get_filterCell: function ()
	{
		var column = this._grid.get_columns().get_columnFromKey(this._columnFilter.get_columnKey());
		var cell = this._gridFiltering._row.get_cellByColumn(column);
		return cell;
	},
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.FilteringNodeObject.dispose">
		/// Disposes of the object.
		/// </summary>

		this._columnFilter = null;
		this._gridFiltering = null;
		this._grid = null;
		$IG.FilteringNodeObject.callBaseMethod(this, "dispose");

	}


}
$IG.FilteringNodeObject.registerClass('Infragistics.Web.UI.FilteringNodeObject', $IG.ObjectBase);


$IG.ClientColumnFilter = function (columnKey, columnType, gridID)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientColumnFilter">
	/// Object that defines rule and value based filtering condition. This object does not preserve its state.
	/// </summary>
	/// <param name="columnKey" type="String"> The key of the column that the column filter is tied to. </param>
	/// <param name="columnType" type="String"> The data type of the grid column that the column filter is tied to.
	/// Column type could be one of the following: date, boolean, number or string.
	/// </param>
	/// <param name="gridID" type="String"> The id for the grid to which the column filter belongs. </param>

	this._columnKey = columnKey;
	this._columnType = columnType;
	this._gridID = gridID;
	this._condition = new $IG.ClientCondition($IG.FilteringNodeObjectProps.Rule[1], "", this._columnType, this);
}
$IG.ClientColumnFilter.prototype =
{
	get_columnKey: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.columnKey">
		/// Gets the key of the column that the column filter is tied to.
		/// </summary>
		/// <value type="String">Column key</value>
		return this._columnKey;
	},

	get_condition: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.condition">
		/// Rule and value based filtering condition that will apply to the ControlDataField which 
		/// the column filter is tied to.		
		/// </summary>
		/// <value type="Infragistics.Web.UI.ClientCondition">Filtering condition</value>
		return this._condition;
	},

	get_columnType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientColumnFilter.columnType">
		/// Gets the data type of the grid column that the column filter is tied to.
		/// Column type could be one of the following: date, boolean, number or string.
		/// </summary>
		/// <value type="String">Column type could be one of the following: date, boolean, number or string </value>
		return this._columnType;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnFilter.dispose">
		/// Disposes of the object.
		/// </summary>

		if (this._condition)
			this._condition.dispose();
		this._condition = null;
		this._columnKey = null;
		this._columnType = null;
		this._gridID = null;
	}
}
$IG.ClientColumnFilter.registerClass('Infragistics.Web.UI.ClientColumnFilter');



$IG.ClientCondition = function (rule, value, type, columnFilter)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientCondition">
	/// Object that defines rule and value based filtering condition. This object does not preserve its state.
	/// </summary>
	/// <param name="rule"> 
	/// The filter condition rule. type will be one of the following, based on the column type:
	/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
	/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
	/// </param>
	/// <param name="value">
	/// The filter condition value. type will be one of the following, based on the
	/// column type: String, Number, Date, or Boolean	
	/// </param>
	/// <param name="type" type="String"> 
	/// The data type of the grid column that the column filter is tied to.
	/// Column type could be one of the following: date, boolean, number or string. 
	/// </param>
	/// <param name="columnFilter" type="Infragistics.Web.UI.ClientColumnFilter"> The column filter to which the object belongs. </param>

	this._type = type;
	this._rule = rule;
	this._value = value;
	this._colKey = columnFilter.get_columnKey();
	this._gridID = columnFilter._gridID;

}
$IG.ClientCondition.prototype =
{
	get_rule: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.rule">
		/// Gets the filter condition rule. The return type will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </value>
		return this._rule;
	},

	set_rule: function (rule)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.rule">
		/// Sets the filter condition rule.
		/// </summary>
		/// <param name="rule" optional="false" mayBeNull="false">
		/// The type of the rule will be one of the following, based on the column type:
		/// Infragistics.Web.UI.TextFilterRules, Infragistics.Web.UI.NumericFilterRules, 
		/// Infragistics.Web.UI.DateTimeFilterRules, or Infragistics.Web.UI.BooleanFilterRules
		/// </param>
		this._rule = rule;
		var grid = ig_controls[this._gridID];
		if (grid && grid.Filtering)
		{
			
			var cell = this._get_filterCell();
			var ruleElm = grid.get_behaviors().get_filtering()._getRuleElement(rule, cell._dropDownBehaviour._targetContainer);
			if (ruleElm != null)
			{
				var elm = cell.get_element().childNodes[0].childNodes[0];
				elm.alt = ruleElm.innerHTML;
				elm.title = ruleElm.innerHTML;
				cell.get_element().childNodes[0].title = ruleElm.innerHTML;
			}
		}
		cell = null;
		grid = null;
		ruleElm = null;
	},

	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.value">
		/// Gets the filter condition value. The return type will be one of
		/// the following, based on the column type: String, Number, Date, or Boolean
		/// </summary>
		/// <value>The return type will be one of the following, based on the column type: 
		/// String, Number, Date, or Boolean
		/// </value>
		var grid = ig_controls[this._gridID];
		if (this._type == "date" && grid)
			return grid._gridUtil._convertServerDateStringToClientObject(this._value);
		return this._value;
	},

	set_value: function (value)
	{	
		/// <summary locid="P:J#Infragistics.Web.UI.ClientCondition.value">
		/// Sets the filter condition value.
		/// </summary>
		/// <param name="value" optional="false" mayBeNull="false">
		/// The type of the value will be one of the following, based on the column type: 
		/// String, Number, Date, or Bool
		/// </param>

		if (this._type == "boolean")
			return;

		var grid = ig_controls[this._gridID];
		var column = grid.get_columns().get_columnFromKey(this._colKey);
		var cell = this._get_filterCell();
		var valueToSave = cell.__parseValue(value);
		var text = column._formatValue(valueToSave);

		if (this._type == "number")
		{
			var parsedValue = parseFloat(value);
			if (isNaN(parsedValue))
			{
				valueToSave = "";
				text = "";
			}
		}
		else if (this._type == "date")
		{
			if (value == null)
			{
				valueToSave = "";
				text = "";
			}
			else if (typeof (value) != "object" || typeof (value.getMonth) == "undefined")
			{
				
				var parsedValue = Date.parseLocale(value);
				if (isNaN(parsedValue) || parsedValue == null || parsedValue == undefined)
				{
					valueToSave = "";
					text = "";
				}
				else
					valueToSave = grid._gridUtil._convertClientDateToServerString(parsedValue);
			}
			else
				valueToSave = grid._gridUtil._convertClientDateToServerString(valueToSave);
		}

		this._value = valueToSave;
		cell.get_element().childNodes[1].innerHTML = $util.htmlEscapeCharacters(text);
		if (text == "" && $util.IsIE)
		{
			cell.get_element().childNodes[1].appendChild(document.createComment(""));
		}
		cell = null;
		column = null;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientCondition.dispose">
		/// Disposes of the object.
		/// </summary>

		
	},

	_get_filterCell: function ()
	{
		var grid = ig_controls[this._gridID];
		var column = grid.get_columns().get_columnFromKey(this._colKey);
		var cell = grid.get_behaviors().get_filtering()._row.get_cellByColumn(column);
		grid = null;
		column = null;
		return cell;
	}
}
$IG.ClientCondition.registerClass('Infragistics.Web.UI.ClientCondition');






$IG.FilteringAction = function (type, ownerName, object, value, tag)
{
	///<summary locid="T:J#Infragistics.Web.UI.FilteringAction">
	///Object for event arguments used in the Filtering behaviors to make full or partial postbacks.
	///</summary>

	

	var d = new Date()
	
	var timeOffset = -(d.getTimezoneOffset() * 60000);
	$IG.FilteringAction.initializeBase(this, [type, ownerName, object, value, timeOffset]);
}

$IG.FilteringAction.prototype =
{


}


$IG.FilteringAction.registerClass('Infragistics.Web.UI.FilteringAction', $IG.GridAction);











$IG.ColumnFilterAddedArgs = function (columnFilter)
{


	/// <summary>

	/// Class used as EventArgs while raising ColumnFilterAdded event

	/// </summary>

	/// <param name="columnFilter" type="Infragistics.Web.UI.ColumnFilter">The column filter that was added. </param>


	this._columnFilter = columnFilter;


	$IG.ColumnFilterAddedArgs.initializeBase(this);


}


$IG.ColumnFilterAddedArgs.prototype =
{


	get_columnFilter: function ()
	{


		/// <summary>

		/// Gets the column filter object that needs to be added.

		/// </summary>

		/// <value type="Infragistics.Web.UI.ColumnFilter">The column filter that was added. </value>


		return this._columnFilter;


	}


}


$IG.ColumnFilterAddedArgs.registerClass('Infragistics.Web.UI.ColumnFilterAddedArgs', $IG.EventArgs);











$IG.DataFilteredArgs = function (columnFilters)
{


	/// <summary>

	/// Class used as EventArgs while raising DataFiltered event

	/// </summary>

	/// <param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ColumnFilter">

	/// The column filter array that was used to filter the grid's data. 

	/// </param>


	this._columnFilters = columnFilters;


	$IG.DataFilteredArgs.initializeBase(this);


}


$IG.DataFilteredArgs.prototype =
{


	get_columnFilters: function ()
	{


		/// <summary>

		/// Gets the column filter array that was used to filter the grid's data.

		/// </summary>

		/// <value type="Array" elementType="Infragistics.Web.UI.ColumnFilter">Column filters </value>


		return this._columnFilters;


	}


}


$IG.DataFilteredArgs.registerClass('Infragistics.Web.UI.DataFilteredArgs', $IG.EventArgs);






$IG.CancelApplyFiltersEventArgs = function (behavior, columnFilters, columnFilterToAdd)
{


	///<summary>

	///Object for cancelable event arguments used in the Filtering behavior for the DataFiltering event.

	///</summary>

	/// <param name="behavior" type="Infragistics.Web.UI.Filtering">The filtering behavior. </param>

	/// <param name="columnFilters" type="Array" elementType="Infragistics.Web.UI.ColumnFilter">The column filter which originated on the server, but could have been changed, by which to filter. </param>

	/// <param name="columnFilterToAdd" type="Array" elementType="Infragistics.Web.UI.ClientColumnFilter">The column filter which were created on the client by which to filter. </param>


	$IG.CancelApplyFiltersEventArgs.initializeBase(this, [behavior]);



	this._columnFilters = [];


	


	if (columnFilters)
	{

		for (var i = 0; i < columnFilters.length; i++)

			this._columnFilters[i] = columnFilters[i];

	}


	



	if (columnFilterToAdd)
	{


		for (var i = 0; i < columnFilterToAdd.length; i++)

			this._columnFilters[this._columnFilters.length] = columnFilterToAdd[i];


	}


}


$IG.CancelApplyFiltersEventArgs.prototype =
{


	get_columnFilters: function ()
	{


		/// <summary>

		/// Gets the column filters array which will be used to filter the data in the grid.

		/// </summary>

		/// <value type="Array"></value>



		return this._columnFilters;


	},


	_dispose: function ()
	{

		if (this._columnFilters && this._columnFilters.length)
		{

			for (var i = 0; i < this._columnFilters.length; i++)
			{

				


				this._columnFilters[i] = null;

			}

		}

		this._columnFilters = null;

	}


}


$IG.CancelApplyFiltersEventArgs.registerClass('Infragistics.Web.UI.CancelApplyFiltersEventArgs', $IG.CancelBehaviorEventArgs);







$IG.ColumnFilterAddingRemovingEventArgs = function (behavior)
{


	///<summary>

	///Object for event arguments used in the Filtering behavior for Adding/Removing column filters.

	///</summary>

	/// <param name="behavior" type="Infragistics.Web.UI.Filtering">The filtering behavior. </param>


	$IG.ColumnFilterAddingRemovingEventArgs.initializeBase(this, [behavior]);


	

	this._props[1] = 2;


}


$IG.ColumnFilterAddingRemovingEventArgs.prototype =
{
}
$IG.ColumnFilterAddingRemovingEventArgs.registerClass('Infragistics.Web.UI.ColumnFilterAddingRemovingEventArgs', $IG.CancelBehaviorEventArgs);






$IG.FilteringAlignment = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringAlignment">
	/// The enumeration defines where the filter row is displayed.
	/// </summary>
	/// <field name="Top" type="Number" integer="true" static="true">
	/// Filter row is displayed in the header.
	/// </field>
	/// <field name="Bottom" type="Number" integer="true" static="true">
	/// Filter row is displayed in the footer.
	/// </field>
}
$IG.FilteringAlignment.prototype =
{
	Top: 0,
	Bottom: 1
};
$IG.FilteringAlignment.registerEnum("Infragistics.Web.UI.FilteringAlignment");


$IG.FilteringVisibility = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FilteringVisibility">
	/// The enumeration defines whether the filter row is displayed.
	/// </summary>
	/// <field name="Visible" type="Number" integer="true" static="true">
	/// Filter row is visible.
	/// </field>
	/// <field name="Hidden" type="Number" integer="true" static="true">
	/// Filter row is hidden.
	/// </field>
}
$IG.FilteringVisibility.prototype =
{
	Visible: 0,
	Hidden: 1
};
$IG.FilteringVisibility.registerEnum("Infragistics.Web.UI.FilteringVisibility");



$IG.TextFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for string type columns
	/// </summary>

	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="DoesNotEqual" type="Number" integer="true" static="true">
	/// Does not equal.
	/// </field>
	/// <field name="BeginsWith" type="Number" integer="true" static="true">
	/// Begins with.
	/// </field>	
	/// <field name="EndsWith" type="Number" integer="true" static="true">
	/// Ends with.
	/// </field>
	/// <field name="Contains" type="Number" integer="true" static="true">
	/// Contains.
	/// </field>
	/// <field name="DoesNotContain" type="Number" integer="true" static="true">
	/// Does not contain.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>
}
$IG.TextFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	DoesNotEqual: 2,
	BeginsWith: 3,
	EndsWith: 4,
	Contains: 5,
	DoesNotContain: 6,
	IsNull: 7,
	IsNotNull: 8
};
$IG.TextFilterRules.registerEnum("Infragistics.Web.UI.TextFilterRules");



$IG.NumericFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.NumericFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for numeric type columns
	/// </summary>

	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="DoesNotEqual" type="Number" integer="true" static="true">
	/// Does not equal.
	/// </field>
	/// <field name="GreaterThan" type="Number" integer="true" static="true">
	/// Greater than.
	/// </field>
	/// <field name="GreaterThanOrEqualTo" type="Number" integer="true" static="true">
	/// Greater than or equal to.
	/// </field>
	/// <field name="LessThan" type="Number" integer="true" static="true">
	/// Less than.
	/// </field>
	/// <field name="LessThanOrEqualTo" type="Number" integer="true" static="true">
	/// Less than or equal to.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>
}
$IG.NumericFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	DoesNotEqual: 2,
	GreaterThan: 3,
	GreaterThanOrEqualTo: 4,
	LessThan: 5,
	LessThanOrEqualTo: 6,
	IsNull: 7,
	IsNotNull: 8
};
$IG.NumericFilterRules.registerEnum("Infragistics.Web.UI.NumericFilterRules");



$IG.DateTimeFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.DateTimeFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for date type columns
	/// </summary>
	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="Equals" type="Number" integer="true" static="true">
	/// Equals.
	/// </field>
	/// <field name="Before" type="Number" integer="true" static="true">
	/// Before.
	/// </field>
	/// <field name="After" type="Number" integer="true" static="true">
	/// After.
	/// </field>
	/// <field name="Tomorrow" type="Number" integer="true" static="true">
	/// Tomorrow.
	/// </field>
	/// <field name="Today" type="Number" integer="true" static="true">
	/// Today.
	/// </field>
	/// <field name="Yesterday" type="Number" integer="true" static="true">
	/// Yesterday.
	/// </field>
	/// <field name="NextWeek" type="Number" integer="true" static="true">
	/// Next week.
	/// </field>
	/// <field name="ThisWeek" type="Number" integer="true" static="true">
	/// This week.
	/// </field>
	/// <field name="LastWeek" type="Number" integer="true" static="true">
	/// Last week.
	/// </field>
	/// <field name="NextMonth" type="Number" integer="true" static="true">
	/// Next month.
	/// </field>
	/// <field name="ThisMonth" type="Number" integer="true" static="true">
	/// This month.
	/// </field>
	/// <field name="LastMonth" type="Number" integer="true" static="true">
	/// Last month.
	/// </field>
	/// <field name="NextQuarter" type="Number" integer="true" static="true">
	/// Next quarter.
	/// </field>
	/// <field name="ThisQuarter" type="Number" integer="true" static="true">
	/// This quarter.
	/// </field>
	/// <field name="LastQuarter" type="Number" integer="true" static="true">
	/// Last quarter.
	/// </field>
	/// <field name="NextYear" type="Number" integer="true" static="true">
	/// Next year.
	/// </field>
	/// <field name="ThisYear" type="Number" integer="true" static="true">
	/// This year.
	/// </field>
	/// <field name="LastYear" type="Number" integer="true" static="true">
	/// Last year.
	/// </field>
	/// <field name="YearToDate" type="Number" integer="true" static="true">
	///Year to date.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>

}
$IG.DateTimeFilterRules.prototype =
{
	All: 0,
	Equals: 1,
	Before: 2,
	After: 3,
	Tomorrow: 4,
	Today: 5,
	Yesterday: 6,
	NextWeek: 7,
	ThisWeek: 8,
	LastWeek: 9,
	NextMonth: 10,
	ThisMonth: 11,
	LastMonth: 12,
	NextQuarter: 13,
	ThisQuarter: 14,
	LastQuarter: 15,
	NextYear: 16,
	ThisYear: 17,
	LastYear: 18,
	YearToDate: 19,
	IsNull: 20,
	IsNotNull: 21
};
$IG.DateTimeFilterRules.registerEnum("Infragistics.Web.UI.DateTimeFilterRules");



$IG.BooleanFilterRules = function ()
{
	/// <summary locid="T:J#Infragistics.Web.UI.BooleanFilterRules">
	/// Allowable values for the FilteringNodeObject.set_rule method for boolean type columns
	/// </summary>
	/// <field name="All" type="Number" integer="true" static="true">
	/// All.
	/// </field>
	/// <field name="True" type="Number" integer="true" static="true">
	/// True.
	/// </field>
	/// <field name="False" type="Number" integer="true" static="true">
	/// False.
	/// </field>
	/// <field name="IsNull" type="Number" integer="true" static="true">
	///  All null values.
	/// </field>
	/// <field name="IsNotNull" type="Number" integer="true" static="true">
	/// All values which are not null.
	/// </field>  
}
$IG.BooleanFilterRules.prototype =
{
	All: 0,
	True: 1,
	False: 2,
	IsNull: 3,
	IsNotNull: 4
};
$IG.BooleanFilterRules.registerEnum("Infragistics.Web.UI.BooleanFilterRules");






$IG.GridFilteringProps = new function ()
{
	this.Visibility = [$IG.GridBehaviorProps.Count + 0, $IG.FilteringVisibility.Visible];
	this.RuleDropdownZIndex = [$IG.GridBehaviorProps.Count + 1, 100100];
	this.Count = $IG.GridBehaviorProps.Count + 2;
};


$IG.ColumnFilterSettingsProps = new function ()
{
	this.ColumnKey = [$IG.ObjectBaseProps.Count + 0, ""];
	this.Count = $IG.ObjectBaseProps.Count + 1;
};


$IG.ColumnFilterProps = new function ()
{
	this.ColumnKey = [$IG.ObjectBaseProps.Count + 0, ""];
	this.ColumnType = [$IG.ObjectBaseProps.Count + 1, ""];
	this.Count = $IG.ObjectBaseProps.Count + 2;
};


$IG.FilteringNodeObjectProps = new function ()
{
	this.Rule = [$IG.ObjectBaseProps.Count + 0, 0];
	this.Value = [$IG.ObjectBaseProps.Count + 1];	
	this.Count = $IG.ObjectBaseProps.Count + 2;
};


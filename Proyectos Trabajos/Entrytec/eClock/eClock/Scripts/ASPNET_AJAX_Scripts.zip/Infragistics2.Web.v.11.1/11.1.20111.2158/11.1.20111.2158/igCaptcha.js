/*
* igCaptcha.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');

$IG.WebCaptcha = function(element)
{
	///<summary locid="T:J#Infragistics.Web.UI.WebCaptcha">
	/// WebCaptcha control 
	///</summary>
	$IG.WebCaptcha.initializeBase(this, [element]);
}

$IG.WebCaptcha.prototype =
{
    _thisType: 'webCaptcha',

    
    initialize: function() 
    {
		/// <summary locid="M:J#Infragistics.Web.UI.WebCaptcha.initialize">
		/// for internal use only 
		///</summary>
		
		$IG.WebCaptcha.callBaseMethod(this, 'initialize');
        
		// if protection mode is timeout, register timeout counter 
		if (this.get_protectionMode() == $IG.CaptchaProtectionMode.FormSubmissionTimeout)
		{
			this.__formSubmissionIntervalID = setInterval(Function.createDelegate(this, this.__incrementSubmitCounter) , 500);
			this.set_currentFormSubmissionTimeoutSeconds(0);
			this.__startTime = new Date().getTime();
		}

		if (this.get_enableCaptchaImageRegeneration()==true)
		{
			var timeout = parseInt(this.get_captchaImageRegenerationTimeout())*1000;
			this.__captchaImageRegenerationID = setTimeout(Function.createDelegate(this, this.__regenerateCaptchaImage), timeout);
		}
		
		// find the refresh button
		if (this._elements["RefreshButtonLink"])
		{
			// attach event
			var refreshButtonDelegate = Function.createDelegate(this, this.__regenerateCaptchaImage);
			$addHandler(this._elements["RefreshButtonLink"], 'click', refreshButtonDelegate);
		}
		
		this._raiseClientEvent('Initialize');
	},
	
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebCaptcha.dispose">
		/// for internal use only 
		///</summary>
		
		if (this.get_protectionMode() == $IG.CaptchaProtectionMode.FormSubmissionTimeout)
		{
			clearInterval(this.__formSubmissionIntervalID);
		}

		if (this.get_enableCaptchaImageRegeneration())
		{
			clearInterval(this.__captchaImageRegenerationID);
		}
		
		this._imageArea = null;

		if (this._elements["RefreshButton"])
		{
			$clearHandlers(this._elements["RefreshButton"]);
		}

		$clearHandlers(this.get_element());
		$IG.WebCaptcha.callBaseMethod(this, 'dispose');
	},
	
	get_validationFailed: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebCaptcha.validationFailed">
		/// Indicates if the Captcha validation has failed on the server (that is, this is related to the Previous captcha image, not the current one)
		///</summary>
		///<returns type="Boolean">value indicating whether the Captcha validation has failed on the server</returns>
		return this._get_clientOnlyValue("cvf");
	},
	
	get_currentFormSubmissionTimeoutSeconds: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebCaptcha.currentFormSubmissionTimeoutSeconds">
		/// returns the actual time it took to submit the form 
		///</summary>
		///<value type="Integer"> seconds specifying the time it took to submit the form </value>
		return this._get_value($IG.CaptchaProps.CurrentFormSubmissionTimeoutSeconds);
	},
	
	set_currentFormSubmissionTimeoutSeconds: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebCaptcha.currentFormSubmissionTimeoutSeconds">
		/// for internal use 
		///</summary>
		///<param name="val" type="Integer"> the time it took to submit the form </param>
		this._set_value($IG.CaptchaProps.CurrentFormSubmissionTimeoutSeconds, val);
	},
	
	get_formSubmissionTimeoutSeconds: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebCaptcha.formSubmissionTimeoutSeconds">
		/// The minimum number of seconds that need to pass before form is successfully submitted (and validated )
		///</summary>
		///<value type="Integer"> minimum number of seconds that the user needs to spend filling in the form </value>
		return this._get_clientOnlyValue("fstsec");
	},
	
	get_protectionMode: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebCaptcha.protectionMode">
		/// Captcha protection mode  
		///</summary>
		///<value type="Infragistics.Web.UI.CaptchaProtectionMode"> protection mode value </value>
		return this._get_clientOnlyValue("pmd");
	},
	
	get_enableCaptchaImageRegeneration: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebCaptcha.enableCaptchaImageRegeneration">
		/// Specifies if image regeneration will be allowed without doing a full postback
		///</summary>
		///<value type="Boolean">returns a value which pecifies if image regeneration will be allowed without doing a full postback</value>
		return this._get_clientOnlyValue("cir");
	},
	
	get_captchaImageRegenerationTimeout: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebCaptcha.captchaImageRegenerationTimeout">
		/// timeout in seconds after which the image will be automatically regenerated via Async postback 
		///</summary>
		///<value type="Integer"> value which specifies the timeout in seconds after which the image will be automatically regenerated via Async postback </value>
		return this._get_clientOnlyValue("cirt");
	},
	
	__incrementSubmitCounter: function()
	{
		//this.set_currentFormSubmissionTimeoutSeconds(this.get_currentFormSubmissionTimeoutSeconds()+1);
		this.__endTime = new Date().getTime();
		this.set_currentFormSubmissionTimeoutSeconds(parseInt((this.__endTime-this.__startTime)/1000));
	},
	
	__regenerateCaptchaImage: function()
	{
		// do async postback
			var cbo = this._callbackManager.createCallbackObject();
			cbo.serverContext.type = "regenerate";
			this._callbackManager.execute(cbo);
			
			return false;
	},
	
	regenerateImage: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebCaptcha.regenerateImage">
		/// regenerate captcha image if regeneration has been explicitly allowed from the server 
		///</summary>
		if (this.get_enableCaptchaImageRegeneration())
		{
			this.__regenerateCaptchaImage();
		}
	},
	
	_responseComplete: function(callbackObject, responseObject, obj)
	{
		
		$IG.WebCaptcha.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		var props = eval(responseObject.context[0]);
		var html = responseObject.context[1];
		
		var currentControl = this;
		var div = document.createElement("DIV");
		div.innerHTML = html;
		var id = currentControl._id;

		if (!currentControl._element)
			currentControl = ig_controls[id];
			
			
		var childNodeCount = div.childNodes.length;
		for (var i = 0; i < childNodeCount; i++)
		{
			var child = div.childNodes[i];
			if (child.getAttribute && child.id == id)
			{
				currentControl._element.className = child.className;
				for (var i in child.style)
				{
				//	try { currentControl._element.style[i] = child.style[i]; } catch (exception) { };
				}
				currentControl._element.innerHTML = child.innerHTML;
				break;
			}
		}
		
		var name = currentControl.get_name();
		currentControl.dispose();
		ig_controls[id] = null;

		var control = $create($IG.WebCaptcha, { "id": id, "name": name, "props": props }, null, null, $get(id));
	}
}

$IG.WebCaptcha.registerClass('Infragistics.Web.UI.WebCaptcha', $IG.ControlMain);

$IG.CaptchaProps = new function() 
{
    this.CurrentFormSubmissionTimeoutSeconds = [$IG.ControlMainProps.Count +0, 0];
    this.Count = $IG.ControlMainProps.Count + 1;
}

$IG.CaptchaProtectionMode  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.CaptchaProtectionMode">
	/// 
	///</summary>
	///<field name="Captcha" type="Number" integer="true" static="true">  </field>
	///<field name="FormSubmissionTimeout" type="Number" integer="true" static="true"> </field>
	///<field name="InvisibleInputField" type="Number" integer="true" static="true"></field>
}

$IG.CaptchaProtectionMode.prototype = 
{  
   Captcha:0,
   FormSubmissionTimeout:1,   
   InvisibleInputField:2
   
};


$IG.CaptchaProtectionMode.registerEnum("Infragistics.Web.UI.CaptchaProtectionMode");




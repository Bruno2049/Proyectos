/*
* igWebDataGridDeleting.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


$IG.RowDeleting = function(obj, objProps, control, parentCollection)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowDeleting">
	///Deleting behavior object of the grid.
	///</summary>
	$IG.RowDeleting.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._gridElement = this._grid._element;
	this._container = control._elements["container"];
	this._rows = this._owner.get_rows();
	
	this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);
	this._grid._addElementEventHandler(this._grid._element, "keydown", this._gridElementKeyDownHandler);


}

$IG.RowDeleting.prototype =
{

	
	deleteRows: function (rows)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowDeleting.deleteRows">
		/// Takes an array of rows for deletion.
		/// </summary>
		/// <param name="rows" type="Array" elementType="Infragistics.Web.UI.GridRow">Array of rows to be deleted.</param>
		for (var i = 0; i < rows.length; i++)
			this._rows.remove(rows[i], true);

		this._editing.commit();
	},

	

	
	_deleteRows: function (rows, commit)
	{
		/// <summary>
		/// Takes a collection of rows for deletion.
		/// </summary>
		///<param name="rows">Collection of rows to be deleted.</param>

		for (var i = 0; i < rows.get_length(); i++)
			this._rows.remove(rows.getItem(i), true);

		if (typeof (commit) == "undefined" || commit)
			this._editing.commit();
	},

	

	
	_onKeydownHandler: function (evnt)
	{
		var key = evnt.keyCode;

		var isSelectionEnabled = this._selection == null ? false : true;

		if (key == Sys.UI.Key.del)
		{
			if (this._updating)
			{
				if (this._updating.get_cellInEditMode() != null)
					return;
			}

			if (isSelectionEnabled)
			{
				var rowsToBeDeleted = new $IG.GridAffectedItems();
				//Get a reference to the selected rows collection.
				var selectedRows = this._selection.get_selectedRows();
				if (selectedRows.get_length() > 0)
				{
					evnt.preventDefault();
					evnt.stopPropagation();

					var grid = selectedRows._grid;
					var rows = grid.get_rows();

					var numRows = selectedRows.get_length();
					for (var i = numRows - 1; i >= 0; i--)
					{
						var rowID = selectedRows.getItemID(i);
						var row = rows.get_rowFromIDPair(rowID);
						if (row)
							rowsToBeDeleted.add(row);
						else
							rowsToBeDeleted.add(rowID);
					}

					selectedRows.clear();
					if (this._activation)
						this._activation.set_activeCell(null, false);

					if (rowsToBeDeleted.get_length() > 0)
					

						this._deleteRows(rowsToBeDeleted);
				}
			}
		}

	},

	


















































































	

	

	_initializeComplete: function ()
	{
		//Get a reference to the activation interface.
		this._activation = this._grid.get_behaviors().getBehaviorFromInterface($IG.IActivationBehavior);

		//Get a reference to the selection interface.
		this._selection = this._grid.get_behaviors().getBehaviorFromInterface($IG.ISelectionBehavior);

		//Get a reference to the editing interface.
		this._editing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);

		//Get a reference to the updating interface.
		this._updating = this._grid.get_behaviors().getBehaviorFromInterface($IG.IUpdatingBehavior);


	},

	dipose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowDeleting.dipose">
		/// Disposes of the Row Deleting behavior.
		/// </summary>
		if (!this._grid)
			return;
		this._grid._removeElementEventHandler(this._gridElement, "keydown", this._gridElementKeyDownHandler);
	}
	
}
$IG.RowDeleting.registerClass('Infragistics.Web.UI.RowDeleting', $IG.GridBehavior, $IG.IRowDeletingBehavior);


$IG.AffectedRows = function ()
{
/// <summary locid="T:J#Infragistics.Web.UI.AffectedRows">
/// The enumeration defines which rows are affected when the delete operation is performed.
/// </summary>
/// <field name="Selected" type="Number" integer="true" static="true">
/// Selected rows shouls be deleted.
/// </field>
/// <field name="Activated" type="Number" integer="true" static="true">
/// Active row should be deleted.
/// </field>
/// <field name="Both" type="Number" integer="true" static="true">
/// Both selected and active rows should be deleted.
/// </field>
}
$IG.AffectedRows.prototype = 
{
   Selected:0, 
   Activated:1,
   Both: 2
};
$IG.AffectedRows.registerEnum("Infragistics.Web.UI.AffectedRows");


$IG.GridDeletingProps = new function()
{    
    
    this.AffectedRows = [$IG.GridBehaviorProps.Count + 0, $IG.AffectedRows.Both];
    this.Count =  $IG.GridBehaviorProps.Count + 1;
};


/*
* 7_igClientStateManager.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");


$IG.ClientStateManagerBase = function(props)
{
    /// <summary locid="T:J#Infragistics.Web.UI.ClientStateManagerBase">
    /// An object in charge of managing the ClientState of an Object.
    /// </summary>
    this._items = props;
    this._transactionList = null;
}

$IG.ClientStateManagerBase.prototype =
{	
    get_value:function(id)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.ClientStateManagerBase.value">
        /// Gets/Sets the value with the specified id.
        /// </summary>
        ///<param name="id" type="String"> id </param>
        ///<returns type="Object"> the value </returns>
    },
    set_value:function(id, value){},
    get_transactionList:function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.ClientStateManagerBase.transactionList">
        /// Gets a json representation of the TranascationList
        /// </summary>
        ///<returns type="Object" mayBeNull="false"> transaction list corresponding to the current client-state manager </returns>
	    return this._transactionList.get_list();
	},
	
	get_clientState:function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.ClientStateManagerBase.clientState">
        /// Returns the original json ClientState that was passed down from the server.
        /// </summary>
        ///<returns type="Object" mayBeNull="false">client-state in JSON format </returns>
	    return this._items;
	}
}

$IG.ClientStateManagerBase.registerClass('Infragistics.Web.UI.ClientStateManagerBase');



$IG.ObjectClientStateManager = function(props)
{
    /// <summary locid="T:J#Infragistics.Web.UI.ObjectClientStateManager">
    /// A ClientStateManager that handles any object that derives from ObjectBase.
    /// </summary>
    $IG.ObjectClientStateManager.initializeBase(this, [props]);
    this._transactionList = new $IG.ObjectTransactionList();    
}

$IG.ObjectClientStateManager.prototype =
{	
    get_value:function(id, isBool)
    {
    ///<summary locid="P:J#Infragistics.Web.UI.ObjectClientStateManager.value">
    /// returns a value from client-state 
    ///</summary>
    ///<param name="id" type="String"> id of the value to get from client-state </param>
    ///<param name="isBool" type="Boolean"> if the value returned is boolean or not  </param>
    ///<returns type="
        var index = id[0];
        var defaultVal = id[1];
        
        var val = this._transactionList.get_value(index);
        

	    if(val === undefined)
	    {
	        val = this._items[0][index];
	        if(val == null)
	            val = defaultVal;
	    }
	    if(isBool)
	    {
	        if(val == 0)
	            val = false;
	        else if(val == 1)
	            val = true;
	    }
	    
	    return val;
    },
    
    get_clientOnlyValue:function(propName)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.ObjectClientStateManager.clientOnlyValue">
        /// Returns the ClientOnlyProperty Value with the specified key.
        /// </summary>
        return this.__getExraProp(propName, "c");
    },
    
    get_occasionalProperty:function(propName)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.ObjectClientStateManager.occasionalProperty">
        /// Gets/Sets the OccasionalProperty value with the specified key.
        /// </summary>
        return this.__getExraProp(propName, "o");
    },
    
    set_occasionalProperty:function(propName, val)
    {
        var prop = this.__getExraProp(propName, "o");
         if(!$util.compare(prop, val))
            this._transactionList.add_transaction(val, propName);
        else
            this._transactionList.remove_transaction(propName);
    },
    
    __getExraProp:function(propName, key)
    {
        var item = this._items[1];
        if(item != null)
            item = item[key];
        return item ? item[propName] : null;
    },
    
    set_value:function(id, val)
    {
        var index = id[0];
        var defaultVal = id[1];
        
        if(typeof(val) == "boolean")
	        val = (val)?1:0;    
	    
	    var item = this._items[0][index];
        
        if(item == null)
            item =  defaultVal;
	    
        if(!$util.compare(item, val))
            this._transactionList.add_transaction( val, index);
        else
            this._transactionList.remove_transaction( index);
    },
    get_serverProps:function(vse)
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.ObjectClientStateManager.serverProps">
        /// Returns a Server friendly array of ClientState.
        /// </summary>
	    if(vse)
	    {
	        var props = [];
	        props.push(this._items[0]);
	        if(this._items[1] != null && this._items[1]["o"] != null)
	            props.push(this._items[1]["o"]);    
	        return props;
	    }
	    else
	        return null;
	}
}

$IG.ObjectClientStateManager.registerClass('Infragistics.Web.UI.ObjectClientStateManager', $IG.ClientStateManagerBase);



$IG.CollectionClientStateManager = function(props)
{
    /// <summary locid="T:J#Infragistics.Web.UI.CollectionClientStateManager">
    /// A ClientStateManager that handles any ObjectBase that belongs to an ObjectCollection.
    /// </summary>
    $IG.CollectionClientStateManager.initializeBase(this, [props]);   
    this._transactionList = new $IG.CollectionTransactionList(); 
}

$IG.CollectionClientStateManager.prototype =
{	 
    get_value:function(id, isBool, address)
    {
        var index = id[0];
        var defaultVal = id[1];
        
        var val = this._transactionList.get_value(address, index);
	    if(val == null)
	    {
	        val = this._items[address][0][index];
	        if(val == null)
	            val = defaultVal;
	    }
	    
	    if(isBool)
	    {
	        if(val == 0)
	            val = false;
	        else if(val == 1)
	            val = true;
	    }
	    return val;
    },
    
    get_clientOnlyValue:function(propName, adr)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.CollectionClientStateManager.clientOnlyValue">
        /// Returns the ClientOnlyProperty Value with the specified key.
        /// </summary>
        return this.__getExraProp(propName, adr, "c");
    },
    
    get_occasionalProperty:function(propName, adr)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.CollectionClientStateManager.occasionalProperty">
        /// Gets/Sets the OccasionalProperty value with the specified key.
        /// </summary>
        var prop = this._transactionList.get_value(adr, propName);
        if(prop == null)
            prop = this.__getExraProp(propName, adr, "o");
        return prop;
    }, 
    
    set_occasionalProperty:function(propName, val, adr)
    {
        var prop = this.__getExraProp(propName, adr, "o");
         if(!$util.compare(prop, val))
            this._transactionList.add_transaction(adr, val, propName);
        else
            this._transactionList.remove_transaction(adr, propName);
    },
    
    __getExraProp:function(propName, adr, key)
    {
        var item = this._items[adr];
        if(item != null)
        {    item = item[1];
            if(item != null)
            {
                item = item[key];
            }
            if(item != null)
                return item[propName];
        }
        return null;
    },
    
    set_value:function(id, val, address)
    {
        var index = id[0];
        var defaultVal = id[1];
        
        if(typeof(val) == "boolean")
	        val = (val)?1:0;    
	    var item = this._items[address][0][index]
        
        if(item == null)
            item =  defaultVal;
            
        if(!$util.compare(item, val))
            this._transactionList.add_transaction(address, val, index);
        else
            this._transactionList.remove_transaction(address, index);
    }, 
    
    set_itemProps:function(adr, props)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.CollectionClientStateManager.itemProps">
        /// Sets the original json ClientState from server to the ClientStateManager
        /// </summary>
        this._items[adr] = props;
    },
    
    get_serverProps:function(address)
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.CollectionClientStateManager.serverProps">
        /// Returns a Server friendly array of ClientState.
        /// </summary>
        var props = [];
        var item = this._items[address];
        props.push(item[0]);
        if(item[1] != null && item[1]["o"] != null)
            props.push(item[1]["o"]);    
        return props;
	}
}

$IG.CollectionClientStateManager.registerClass('Infragistics.Web.UI.CollectionClientStateManager', $IG.ClientStateManagerBase);









$IG.MSAjaxCollectionClientStateManager = function(props, bindings, parentBinding)
{
    /// <summary locid="T:J#Infragistics.Web.UI.MSAjaxCollectionClientStateManager">
    /// A ClientStateManager that handles any ObjectBase that belongs to an ObjectCollection.
    /// </summary>
    $IG.MSAjaxCollectionClientStateManager.initializeBase(this, [props]);   
    this._transactionList = new $IG.MSAjaxCollectionTransactionList(); 
    this._bindings = bindings;
    this._parentBinding = parentBinding;
}

$IG.MSAjaxCollectionClientStateManager.prototype =
{	 
	// gets stuff in the format "0.1" and returns [0][1]
	_getExpFromAddress: function(address)
	{
		var evalString = "";
		var addressArray = address.toString().split('.');
		
		evalString += "[" + addressArray[0] + "]";
			
		for(var i = 1; i < addressArray.length; i++)
		{
			evalString +=  ".Nodes[" + addressArray[i] + "]";
		}
		
		return evalString;
	},
	
	_getPropNameFromIndex: function(index)
	{
		return this._bindings[index];
	},
	
    get_value:function(id, isBool, address)
    {
        var index = id[0];
        var defaultVal = id[1];

        var val = this._transactionList.get_value(address, index);
	    if(val == null)
	    {
			var evalString = this._getExpFromAddress(address);
			var propName = this._getPropNameFromIndex(index);
			
			var items = this._items;
			val = eval('items' + evalString + '[\"' + propName + '\"]');
			
	        if(val == null)
	            val = defaultVal;
	    }
	    
	    if(isBool)
	    {
	        if(val == 0)
	            val = false;
	        else if(val == 1)
	            val = true;
	    }
	    return val;
    },
    
    get_clientOnlyValue:function(propName, adr)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionClientStateManager.clientOnlyValue">
        /// Returns the ClientOnlyProperty Value with the specified key.
        /// </summary>
        return this.__getExraProp(propName, adr, "c");
    },
    
    get_occasionalProperty:function(propName, adr)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionClientStateManager.occasionalProperty">
        /// Gets/Sets the OccasionalProperty value with the specified key.
        /// </summary>
        var prop = this._transactionList.get_value(adr, propName);
        if(prop == null)
            prop = this.__getExraProp(propName, adr, "o");
        return prop;
    }, 
    
    set_occasionalProperty:function(propName, val, adr)
    {
        var prop = this.__getExraProp(propName, adr, "o");
         if(!$util.compare(prop, val))
            this._transactionList.add_transaction(adr, val, propName);
        else
            this._transactionList.remove_transaction(adr, propName);
    },
    
    __getExraProp:function(propName, adr, key)
    {
        var item = this._items[adr];
        if(item)
        {    
            var prop = item[propName];
            if(prop && prop.length > 0)
                return prop;
        }
        return null;
    },
    
    set_value:function(id, val, address)
    {
        var index = id[0];
        var defaultVal = id[1];
        
        if(typeof(val) == "boolean")
	        val = (val)?1:0;    
	   // var item = this._items[address][0][index]
	   
	   	var propName = this._getPropNameFromIndex(index);
		var evalString = this._getExpFromAddress(address);
		var evalPath = function(items,evalString,index) 
		{
			return function (items,evalString,index) { return eval(items+evalString+'['+this._getPropNameFromIndex(index)+']') };
		};
			
		var item = evalPath(this._items,evalString,index);

        if(item == null)
            item =  defaultVal;
            
        if(!$util.compare(item, val))
            this._transactionList.add_transaction(address, val, index);
        else
            this._transactionList.remove_transaction(address, index);
    }, 
    
    set_itemProps:function(adr, props)
    {
        /// <summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionClientStateManager.itemProps">
        /// Sets the original json ClientState from server to the ClientStateManager
        /// </summary>
        this._items[adr] = props;
    },
    
    get_serverProps:function(address)
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.MSAjaxCollectionClientStateManager.serverProps">
        /// Returns a Server friendly array of ClientState.
        /// </summary>
        var props = [];
        var item = this._items[address];
        props.push(item[0]);
        if(item[1] != null && item[1]["o"] != null)
            props.push(item[1]["o"]);    
        return props;
	},

    getChangeLog: function()
    {
        return [];
    }
}

$IG.MSAjaxCollectionClientStateManager.registerClass('Infragistics.Web.UI.MSAjaxCollectionClientStateManager', $IG.CollectionClientStateManager);









$IG.TransactionListBase = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.TransactionListBase">
    /// An object in charge of managing any Transaction of ClientState.
    /// </summary>
    this._items = {};
    this._orderedList = {};
    this._count = 0; 
}
$IG.TransactionListBase.prototype =
{
	
	
	clear:function()
	{
		var item, i = this._count;
		this._count = 0;
		while (i-- > 0)
			if ((item = this._orderedList[i]))
				this.remove_transaction(item[0], item[1]);
	},
    add_transaction:function()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.TransactionListBase.add_transaction">
        /// Records a transaction in the Transaction list.
        /// </summary>
    },
    remove_transaction:function()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.TransactionListBase.remove_transaction">
        /// Removes a transaction from the Transaction list.
        /// </summary>
    },
    get_value:function()
    {
        /// <summary locid="P:J#Infragistics.Web.UI.TransactionListBase.value">
        /// Returns a value at the specified index, from the Transaction list.
        /// </summary>
    },
    get_list:function()
    {
        /// <summary locid="P:J#Infragistics.Web.UI.TransactionListBase.list">
        /// Returns a server friendly json object of the Transaction list.
        /// </summary>
        return this._orderedList;
    }  
}

$IG.TransactionListBase.registerClass('Infragistics.Web.UI.TransactionListBase');



$IG.ObjectTransactionList = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.ObjectTransactionList">
    /// A TransactionList targeted for ObjectBase objects.
    /// </summary>
    $IG.ObjectTransactionList.initializeBase(this);    
}
$IG.ObjectTransactionList.prototype =
{
    add_transaction:function(value, propsIndex)
    {
         if(this._items[propsIndex] != null && this._items[propsIndex].length > 0)
                delete this._orderedList[this._items[propsIndex][0]];
        this._items[propsIndex] = [this._count, value];
        this._orderedList[this._count] = [propsIndex, value];
        this._count++;
    },
    remove_transaction:function(propsIndex)
    {
        var item = this._items[propsIndex];
        if(item)
        {
            var index = item[0];
            delete this._orderedList[index];
            delete this._items[propsIndex];
        }
    }, 
    get_value:function(propsIndex)
    {
        var item = this._items[propsIndex];
        if(item != null)
            return item[1];
       

        return undefined;
    }
}

$IG.ObjectTransactionList.registerClass('Infragistics.Web.UI.ObjectTransactionList', $IG.TransactionListBase);





$IG.MSAjaxObjectTransactionList = function() 
{
	/// <summary locid="T:J#Infragistics.Web.UI.MSAjaxObjectTransactionList">
	/// A TransactionList targeted for ObjectBase objects.
	/// </summary>
	$IG.MSAjaxObjectTransactionList.initializeBase(this);
}
$IG.MSAjaxObjectTransactionList.prototype =
{
	add_transaction: function(value, propsIndex) 
	{
		if (this._items[propsIndex] != null && this._items[propsIndex].length > 0)
			delete this._orderedList[this._items[propsIndex][0]];
		this._items[propsIndex] = [this._count, value];
		this._orderedList[this._count] = [propsIndex, value];
		this._count++;
	},
	remove_transaction: function(propsIndex) 
	{
		var item = this._items[propsIndex];
		if (item) 
		{
			var index = item[0];
			delete this._orderedList[index];
			delete this._items[propsIndex];
		}
	},
	get_value: function(propsIndex) 
	{
		var item = this._items[propsIndex];
		if (item != null)
			return item[1];
		

		return undefined;
	}
}

$IG.MSAjaxObjectTransactionList.registerClass('Infragistics.Web.UI.MSAjaxObjectTransactionList', $IG.ObjectTransactionList);




$IG.CollectionTransactionList = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.CollectionTransactionList">
    /// A Transaction list targeted for ObjectBase objects that belong to an ObjectCollection.
    /// </summary>
    $IG.CollectionTransactionList.initializeBase(this);    
}
$IG.CollectionTransactionList.prototype =
{
    add_transaction:function(adr, value, propsIndex)
    {
        var item = this._items[adr];
        if(!item)
            item = this._items[adr] = [];
        else
        {
            if(item[propsIndex] != null && item[propsIndex].length > 0)
                delete this._orderedList[item[propsIndex][0]];
        }
        
        item[propsIndex] = [this._count, value];
        this._orderedList[this._count] = [adr, propsIndex, value];
        this._count++;
    },
    
    remove_transaction:function(adr, propsIndex)
    {
        var item = this._items[adr]; 
        if(item != null)
        {
            item = item[propsIndex];
            if(item != null)
            {
                var index = item[0];
                delete this._orderedList[index];
                delete this._items[adr][propsIndex];
            }
        }
    }, 
    
    get_value:function(adr, propsIndex)
    {
        var item = this._items[adr];
        if(item != null)
        {
           item = item[propsIndex]
           if(item != null)
               return item[1];
        }
        return null;
    }
}

$IG.CollectionTransactionList.registerClass('Infragistics.Web.UI.CollectionTransactionList', $IG.TransactionListBase);





$IG.MSAjaxCollectionTransactionList = function() 
{
	/// <summary locid="T:J#Infragistics.Web.UI.MSAjaxCollectionTransactionList">
	/// A Transaction list targeted for ObjectBase objects that belong to an ObjectCollection.
	/// </summary>
	$IG.MSAjaxCollectionTransactionList.initializeBase(this);
}
$IG.MSAjaxCollectionTransactionList.prototype =
{
	add_transaction: function(adr, value, propsIndex) 
	{
		var item = this._items[adr];
		if (!item)
			item = this._items[adr] = [];
		else 
		{
			if (item[propsIndex] != null && item[propsIndex].length > 0)
				delete this._orderedList[item[propsIndex][0]];
		}

		item[propsIndex] = [this._count, value];
		this._orderedList[this._count] = [adr, propsIndex, value];
		this._count++;
	},

	remove_transaction: function(adr, propsIndex) 
	{
		var item = this._items[adr];
		if (item != null) 
		{
			item = item[propsIndex];
			if (item != null) 
			{
				var index = item[0];
				delete this._orderedList[index];
				delete this._items[adr][propsIndex];
			}
		}
	},

	get_value: function(adr, propsIndex) 
	{
		var item = this._items[adr];
		if (item != null) 
		{
			item = item[propsIndex]
			if (item != null)
				return item[1];
		}
		return null;
	}
}

$IG.MSAjaxCollectionTransactionList.registerClass('Infragistics.Web.UI.MSAjaxCollectionTransactionList', $IG.CollectionTransactionList);




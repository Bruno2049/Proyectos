/*
* igWebDataMenu.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


/// <reference name="MicrosoftAjax.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/0_igControlMain.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/2_igCollections.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/3_igUIBehaviors.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/4_igEnums.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/5_igObjects.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/7_igClientStateManager.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/8_igCallback.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/9_igPropertyManagers.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igAnimation.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igDragDrop.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igDropDown.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igLayoutPane.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igResizeBehavior.js" />
/// <reference path="igDataMenuItem.js" />
/// <reference path="igWebDataMenu.js" />

Type.registerNamespace('Infragistics.Web.UI');
var $IG = Infragistics.Web.UI;




 

$IG.DataMenuProps = new function()
{
    this.Enabled = [$IG.NavControlProps.Count + 1, 0];
    this.EnableExpandOnClick = [$IG.NavControlProps.Count + 2, 0];
    this.IsContextMenu = [$IG.NavControlProps.Count + 3, false];
    this.ScrollingSpeed = [$IG.NavControlProps.Count + 4, 2]; // Normal Speed
    this.Count = $IG.NavControlProps.Count + 5;
};



$IG.DataMenuItemProps = new function()
{
    this.Expanded = [$IG.NavItemProps.Count + 0, 0];
    this.ClientLevel = [$IG.NavItemProps.Count + 1, 0];
    this.HoverCssClass = [$IG.NavItemProps.Count + 2, ''];
    this.IsSeparator = [$IG.NavItemProps.Count + 3, false];
    this.Clicked = [$IG.NavItemProps.Count + 4, 0];
    this.Count = $IG.NavItemProps.Count + 5;
};



$IG.DataMenuGroupSettingsProps = new function()
{
    this.OffsetX = [$IG.DataMenuItemProps.Count + 0, 0];
    this.OffsetY = [$IG.DataMenuItemProps.Count + 1, 0];
    this.Height = [$IG.DataMenuItemProps.Count + 2, 0];
    this.Width = [$IG.DataMenuItemProps.Count + 3, 0];
    this.Orientation = [$IG.DataMenuItemProps.Count + 4, 1];
    this.ExpandDirection = [$IG.DataMenuItemProps.Count + 5, 0];
    this.EnableAnimation = [$IG.DataMenuItemProps.Count + 6, 1];
    this.AnimationType = [$IG.DataMenuItemProps.Count + 7, 0];
    this.AnimationDuration = [$IG.DataMenuItemProps.Count + 8, 500];
    this.AnimationEquationType = [$IG.DataMenuItemProps.Count + 9, 3];
    this.ItemsFullAddress = [$IG.DataMenuItemProps.Count + 10, 0];
    this.Count = $IG.DataMenuItemProps.Count + 11;
};

$IG.DataMenuItemSettingsProps = new function()
{
    this.CssClass = [$IG.DataMenuGroupSettingsProps.Count + 0, ""];
    this.DisabledCssClass = [$IG.DataMenuGroupSettingsProps.Count + 1, ""];
    this.HoverCssClass = [$IG.DataMenuGroupSettingsProps.Count + 2, ""];
    this.ImageUrl = [$IG.DataMenuGroupSettingsProps.Count + 3, ""];
    this.Target = [$IG.DataMenuGroupSettingsProps.Count + 4, ""];
    this.NavigateUrl = [$IG.DataMenuGroupSettingsProps.Count + 5, ""];
    this.SelectedCssClass = [$IG.DataMenuGroupSettingsProps.Count + 6, ""];
    this.ImageToolTip = [$IG.DataMenuGroupSettingsProps.Count + 7, ""];
    this.Count = $IG.DataMenuGroupSettingsProps.Count + 8;
};


$IG.DataMenuAnimationtype = new function()
{
    /// <summary>Defines the types of animation that can be applied to the menu.</summary>
    /// <field name="OpacityAnimation" type="Number" integer="true" static="true">If used the menu turns its opacity from semi transparent to opaque.</field>
    /// <field name="ExpandAnimation" type="Number" integer="true" static="true">If used the menu slides itself according to the expand direction.</field>
    this.OpacityAnimation = 0;
    this.ExpandAnimation = 1;
}


$IG.DataMenuScrollingSpeed = new function()
{
    /// <summary>Defines the scrolling speed values that can be used for the menu.</summary>
    /// <field name="VerySlow" type="Number" integer="true" static="true"></field>
    /// <field name="Slow" type="Number" integer="true" static="true"></field>
    /// <field name="Normal" type="Number" integer="true" static="true"></field>
    /// <field name="Fast" type="Number" integer="true" static="true"></field>
    /// <field name="VeryFast" type="Number" integer="true" static="true"></field>
    this.VerySlow = 0;
    this.Slow = 1;
    this.Normal = 2;
    this.Fast = 3;
    this.VeryFast = 4;
}

$IG.DataMenuScrollingSpeedFormula = new function()
{
    /// <summary>Defines the scrolling speed values that can be used for the menu.</summary>   
    this.VerySlow = [1, 100];
    this.Slow = [3, 80];
    this.Normal = [6, 30];
    this.Fast = [9, 20];
    this.VeryFast = [12, 5];
}

$IG.DataMenuScrollingItemsFactor = new function()
{
    this.Slow = [0, 100, 1];
    this.Normal = [100, 1000, 1.2];
    this.Fast = [1000, 10000, 2];
}


$IG.MenuExpandDirection = new function()
{
    /// <summary>Defines the expand directions that menu follows when oppening.</summary>
    /// <field name="Auto" type="Number" integer="true" static="true">Defaults to the Left value when the menu is vertically aligned. If horizontally aligned defaults to the Down value.</field>
    /// <field name="Up" type="Number" integer="true" static="true">The menu will open upwards. Applies only when the orientation is horizontal.</field>
    /// <field name="Down" type="Number" integer="true" static="true">The menu will open downwards. Applies only when the orientation is horizontal.</field>
    /// <field name="Left" type="Number" integer="true" static="true">The menu will open leftwards. Applies only when the orientation is vertical.</field>
    /// <field name="Right" type="Number" integer="true" static="true">The menu will open rightwards. Applies only when the orientation is vertical.</field>
    this.Auto = 0;
    this.Up = 1;
    this.Down = 2;
    this.Left = 3;
    this.Right = 4;
}


$IG.DataMenuItemSettings = function(element, props, control)
{
    /// <summary locid="T:J#Infragistics.Web.UI.DataMenuItemSettings">
    /// A DataMenuItemSettings object that represents the common item settings
    /// </summary>
    var csm = new $IG.ObjectClientStateManager(props[0]);
    $IG.DataMenuItemSettings.initializeBase(this, ["itemSettings", element, props, control, csm]);
    this.initialize();   
}

$IG.DataMenuItemSettings.prototype = 
{
    initialize:function()
	{	    
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemSettings.initialize">
        /// Initializes the DataMenuItemSettings object
        ///</summary>
		$IG.DataMenuItemSettings.callBaseMethod(this, 'initialize');
	},
	
    get_CssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.CssClass">Get the CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.CssClass);
    },
    
    get_DisabledCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.DisabledCssClass">Get the disabled CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.DisabledCssClass);
    },
    
    get_HoverCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.HoverCssClass">Get the hover CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.HoverCssClass);
    },
    
    get_SelectedCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.SelectedCssClass">Get the selected CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.SelectedCssClass);
    },
    
    
    get_ImageUrl: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.ImageUrl">Get the image URL.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.ImageUrl);
    },
    
    get_NavigateUrl: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.NavigateUrl">Get the navigate URL.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.NavigateUrl);
    },
    
    get_Target: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.Target">Get the navigate URL target.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.Target);
    }
}

$IG.DataMenuItemSettings.registerClass('Infragistics.Web.UI.DataMenuItemSettings', $IG.ObjectBase);

$IG.DataMenuGroupSettings = function(element, props, control)
{
    /// <summary locid="T:J#Infragistics.Web.UI.DataMenuGroupSettings">
    /// A DataMenuGroupSettings object that represents the group settings
    /// </summary>
    var csm = new $IG.ObjectClientStateManager(props[0]);
    $IG.DataMenuGroupSettings.initializeBase(this, ["groupSettings", element, props, control, csm]);
    this.initialize();
}

$IG.DataMenuGroupSettings.prototype =
{
    initialize:function()
	{	    
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.initialize">
        ///Initializes the DataMenuGroupSettings object 
        ///</summary>
		$IG.DataMenuGroupSettings.callBaseMethod(this, 'initialize');
        this._menuItem = null;
        this._settingsCache = new Array(); // contains cached values by prop id.
	},

    get_offsetX: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.offsetX">Get the offset X appearance in pixels for the menu or sub-menu group.</summary>
        ///<value type="int"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.OffsetX);
    },
    get_offsetY: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.offsetY">Get the offset Y appearance in pixels for the menu or sub-menu group.</summary>
        ///<value type="int"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.OffsetY);
    },
    get_height: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.height">Get the height of the menu or sub-menu group in pixels.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Height);
    },
    get_width: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.width">Get the width of the menu or sub-menu group in pixels.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Width);
    },
    get_orientation: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.orientation">Get the orientation of the menu or sub-menu group.</summary>
        ///<value type="Infragistics.Web.UI.Orientation"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Orientation);
    },    
    get_expandDirection: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.expandDirection">Get the expand direction of the menu items.</summary>
        ///<value type="Infragistics.Web.UI.MenuExpandDirection"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.ExpandDirection);
    },
    
    get_enableAnimation: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.enableAnimation">Get whether animation is enabled.</summary>
        ///<value type="Boolean"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.EnableAnimation, true);
    },
    
    get_animationDuration: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationDuration">Get the duration in milliseconds of the animation effect.</summary>
        ///<value type="int"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationDuration);        
    },
    
    get_animationType: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationType">Get the animation type.</summary>
        ///<value type="Infragistics.Web.UI.DataMenuAnimationtype"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationType);
    },
    
    get_animationEquationType: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationEquationType">Get the animation equation type.</summary>
        ///<value type="Infragistics.Web.UI.AnimationEquationType"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationEquationType);
    },

    get_itemsFullAddress: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.itemsFullAddress">Get the address of a menu item. Format: ItemLevel.ItemLevel.ItemLevel</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.ItemsFullAddress);
    },

    isEmpty: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.isEmpty">Get whether the object contains default values for all of its properties.</summary>
        ///<value type="Boolean"></value>
        var defaultVal = this.get_offsetX() == $IG.DataMenuGroupSettingsProps.OffsetX[1];
        defaultVal = defaultVal && this.get_offsetY() == $IG.DataMenuGroupSettingsProps.OffsetY[1];
        defaultVal = defaultVal && this.get_height() == $IG.DataMenuGroupSettingsProps.Height[1];
        defaultVal = defaultVal && this.get_width() == $IG.DataMenuGroupSettingsProps.Width[1];
        defaultVal = defaultVal && this.get_orientation() == $IG.DataMenuGroupSettingsProps.Orientation[1];
        defaultVal = defaultVal && this.get_expandDirection() == $IG.DataMenuGroupSettingsProps.ExpandDirection[1];
        defaultVal = defaultVal && this.get_enableAnimation() == $IG.DataMenuGroupSettingsProps.EnableAnimation[1];
        defaultVal = defaultVal && this.get_animationDuration() == $IG.DataMenuGroupSettingsProps.AnimationDuration[1];
        defaultVal = defaultVal && this.get_animationType() == $IG.DataMenuGroupSettingsProps.AnimationType[1];
        defaultVal = defaultVal && this.get_animationEquationType() == $IG.DataMenuGroupSettingsProps.AnimationEquationType[1];
        return defaultVal;
    },

    _set_item: function(item)
    {
        this._menuItem = item;
    },

	get_item: function()
	{
		return this._menuItem;
	},

    _get_inheritedValue: function(propId, isBool)
    {
		///<summary>If the current instance has a default value for the concreet property
		/// the function will go up the stack and return the value that is set by the user.
		/// If the user set somewhere the default value we will know that it is explicitly
		/// set and will return it.
		///</summary>
        if(!$util.isNullOrUndefined(this._settingsCache[propId[0]]))
            return this._settingsCache[propId[0]];

        var val = this._get_value(propId, isBool);

        if(val == propId[1] &&
           $util.isNullOrUndefined(this._csm._items[0][propId[0]]) && // value has not come from the server about this
           this.get_itemsFullAddress() != "-1")
        {
            // the value is default, search up the stack until the root level.
            var settings;
            var parentItem = this._menuItem.get_parentItem();
            if(parentItem)
            {
                settings = parentItem.get_itemsGroupSettings();
            }
            else
            {
                settings = this._menuItem._get_owner().get_menuGroupSettings();
            }

            if(settings)
            {
                var val1 = settings._get_inheritedValue(propId, isBool);
                this._settingsCache[propId[0]] = val1;
                return val1;
            }
        }
        else
        {
            this._settingsCache[propId[0]] = val;
        }
        return val;
    }
}
$IG.DataMenuGroupSettings.registerClass('Infragistics.Web.UI.DataMenuGroupSettings', $IG.ObjectBase);



$IG.WebDataMenu = function(element)
{
	$IG.WebDataMenu.initializeBase(this, [element]);

	$IG.WebDataMenu.find = $find;
	$IG.WebDataMenu.from = $IG._from;
}

$IG.WebDataMenu.prototype =
{
	_thisType: 'menu',
	_menuGroupSettings: $IG.DataMenuGroupSettings,
	_itemSettings: $IG.DataMenuItemSettings,
	_selectedItem: $IG.DataMenuItem,
	_hoveredItem: $IG.DataMenuItem,
	_activeItem: $IG.DataMenuItem,
	_itemsGroupSettings: null,
	_focusElement: null,
	__controlActive: false,
	__form: null,
	__submit: null,
	__defaultContextHandler: null,
	__defaultMouseUpHandler: null,
	_contextClosingTimeOut: null,
	__subMenuClosingDelay: 0,
	__subMenuOpeningDelay: 0,
	__resizedId: 0,
	__isInitialized: false,
    __expandedItems: [],
	__iframeItemsListBackground: null,
    __topLevelItemsResized : false,

	initialize: function()
	{
		this.__enabled = this._get_clientOnlyValue("enabled");
        this.__topLevelItemsResized = false;
		$IG.WebDataMenu.callBaseMethod(this, 'initialize');
		this._visibleItems = [];
		this.__currentFocusedItem = null;
		this._selectedItem = null;
		this._activeItem = null;
		this._hoveredItem = null;
		this._itemSettings = new $IG.DataMenuItemSettings(this._element, this._objectsManager.get_objectProps(0), this);
		this._objectsManager.register_object(0, this._itemSettings);
		this._menuGroupSettings = this._groupSettingsCollection.getGroupSettingsObjectByAdr("-1");
		this.__subMenuClosingDelay = parseInt(this._get_clientOnlyValue("subMenuClosingDelay"));
		this.__subMenuOpeningDelay = parseInt(this._get_clientOnlyValue("subMenuOpeningDelay"));
		this.__enableScrolling = this._get_clientOnlyValue("enableScrolling");
		this.__activateOnHover = this._get_clientOnlyValue("aoh");
		this.__closeOnClick = this._get_clientOnlyValue("cmonc");
		this.__iframeItemsListBackground = this._createIframeAsListBackground();
		var selItemAdr = this._get_clientOnlyValue("selectedItemAdr");
		if(!$util.isNullOrUndefined(selItemAdr))
		{
			this._selectedItem = this.getItems()._getObjectByAdr(selItemAdr);
		}

		if (this.get_isContextMenu())
		{
			var el = this._element;
			// L.T. 12/11/2010, 59844, When WDM is in UpdatePanel, when some other control causes the panel
			// to do an async postback, the update panel disposes its child controls by enumerating its child
			// DOM elements and calling el.control.dispose(). We have to leave an empty DIV in the update panel
			// so that we are notified about the dispose.
			var pseudoControlDiv = document.createElement("DIV");
			pseudoControlDiv.style.display = "none";
			pseudoControlDiv.style.visibility = "hidden";
			pseudoControlDiv.control = this;
			el.parentNode.appendChild(pseudoControlDiv);
			this._pseudoControlDiv = pseudoControlDiv;

			el.parentNode.removeChild(el);
			document.body.appendChild(el);
		}
		else
		{
            // A.Y. 18/01/2011, 59951, WDM is incorrectly rendered on WebKit browsers(Safari, Chrome)
            // The problem arises from the fact that DOMContentLoaded event fires before
            // all images and css files are loaded and when measured the size of the menu is incorrect.
            // Moving the resize in window.onload solves the problem.
            // K.D. January 26, 2011 The below fix needs to be applied only in Webkit browsers, otherwise it breaks
            // functionality for all other browsers
            if($util.IsChrome || $util.IsSafari)
            {
                var onResizeFn = Function.createDelegate(this, this.__resizeTopLevelItems);
                $addHandler(window, 'load', onResizeFn);
                
                 //I.I. 90688: window.load is not called when part of the page is posted back by UpdatePanel
                 var prm = Sys.WebForms.PageRequestManager.getInstance();
                 if (prm) prm.add_endRequest(onResizeFn);
            }
            else
                this.__resizeTopLevelItems();
		}

		if($util.IsIE7)
		{
			Sys.UI.DomElement.addCssClass(this._element, "ie7_DisplayInlineFix");
		}
		else if($util.IsIE6)
		{
			// L.T. 4/11/2010 35617, Menu does not reder correctly under IE6.
			Sys.UI.DomElement.addCssClass(this._element, "ie6");
		}
		// NB: Display the menu because initially it is rendered hidden from the server.
		this._element.style.display = $util.IsIE7 ? "" : "inline-block";

		if(this.get_enabled())
		{
			this.__createFocusEl();

			if (this._focusElement != null)
			{
				this._onFocusFn = Function.createDelegate(this, this._onFocusHandler);
				$addHandler(this._focusElement, 'focus', this._onFocusFn);
				this._onBlurFn = Function.createDelegate(this, this._onBlurHandler);
				$addHandler(this._focusElement, 'blur', this._onBlurFn);
			}

			this._onKeydownFn = Function.createDelegate(this, this._onKeydownHandler);
			$addHandler(this.get_element(), 'keydown', this._onKeydownFn);

			this._onDocumentMouseOverFn = Function.createDelegate(this, this._onDocumentMouseOverHandler);
			$addHandler(document, 'mouseover', this._onDocumentMouseOverFn);

			this._onMouseOutFn = Function.createDelegate(this, this._onMouseOutHandler);
			$addHandler(this.get_element(), 'mouseout', this._onMouseOutFn);

			if ($util.IsIE)
			{
				this._onDocumentClickFn = Function.createDelegate(this, this._onDocumentClickHandler);
				$addHandler(document, 'click', this._onDocumentClickFn);
			}

			if (this.get_enableScrolling())
			{
				this._onMouseOverFn = Function.createDelegate(this, this._onMouseOverHandler);
				$addHandler(this.get_element(), 'mouseover', this._onMouseOverFn);

				//A.T. 5 October 2010 - fix for bug #50032 - The menu is not resized when the splitter is resized under IE7
				this._onResizeFn = Function.createDelegate(this, this._onWindowResizeHandler);
				//$addHandler(window, 'resize', this._onResizeFn);
				this._resizeTimerID = setInterval(this._onResizeFn, 200);

				this.__attachMouseWheelEvent();
			}
		}
		this.__getPageDimensions(true);
		//this._resizeTopLevelSeparators();
		if(!this.preventInitEvent)
			this._raiseClientEvent('Initialize', 'DataMenuItemCancel', null, null, null);
		this.__isInitialized = true;
	},

    __resizeTopLevelItems: function()
	{
        if (this.__topLevelItemsResized) return;

		var group = this._get_subgroup();
		this.__resizeItems(this.getItems().getItem(0), this._menuGroupSettings, group);
        
        this.__topLevelItemsResized = true;
	},

	_onIgSubmit: function()
	{
		if (this._hoveredItem)
		{
			
			this._hoveredItem._getFlags().setHovered(false);
		}

        //A.T. Fix for #48430
        for(var i=0; i < this.__expandedItems.length; i++)
        {
            if (this.__expandedItems[i])
            {
                this.__expandedItems[i].set_expanded(false);
            }
        }

		$IG.WebDataMenu.callBaseMethod(this, '_onIgSubmit');
	},

	__resizeListItems: function(item)
	{
		if ($util.isNullOrUndefined(item))
			return;
		this.__resizeItems(item.get_childItem(0), item.get_itemsGroupSettings(), item._get_subgroup());
	},

	__resizeItems: function(childItem, grpSettings, group)
	{
		if ($util.isNullOrUndefined(childItem) ||
           $util.isNullOrUndefined(grpSettings) ||
           $util.isNullOrUndefined(group))
			return;

		var childItemElem = childItem.get_element();

		if (this.get_enableScrolling())
		{
			var ulBounds = this.__getElementBoundsEx(group);

			this.__resizeScrollArea(ulBounds, group.parentNode, grpSettings);

			if (group.style.height != "") // if we have set the size once, return.
				return;
            
            // K.D. April 6th, 2011 Bug #71419 In IE9 and FF4 the browsers cut the last item in the list because
            // of this 1 pixel difference
            if($util.IsIE9Plus || $util.IsFireFox4)
            {
                group.style.width = ulBounds.width + 1 + "px";
            }
            else
			    group.style.width = ulBounds.width + "px";
			group.style.height = ulBounds.height + "px";
		}

		if (grpSettings.get_orientation() == $IG.Orientation.Vertical && this.get_enableScrolling() && group.previousSibling && group.previousSibling.style.width == '')
		{
			var maxWidth = $util.toIntPX(null, 'width', 0, group);
			if (maxWidth > 0)
			{
				if (group.previousSibling)
				{
					var topButton = group.previousSibling;
					var maxTopButtonWidth = maxWidth;
					maxTopButtonWidth -= $util.toIntPX(null, 'borderLeftWidth', 0, topButton);
					maxTopButtonWidth -= $util.toIntPX(null, 'borderRightWidth', 0, topButton);
					if(maxTopButtonWidth > 0)
						topButton.style.width = maxTopButtonWidth + "px";
				}
				if (group.nextSibling)
				{
					var bottomButton = group.nextSibling;
					var maxBottomButtonWidth = maxWidth;
					maxBottomButtonWidth -= $util.toIntPX(null, 'borderLeftWidth', 0, bottomButton);
					maxBottomButtonWidth -= $util.toIntPX(null, 'borderRightWidth', 0, bottomButton);
					if(maxBottomButtonWidth > 0)
						bottomButton.style.width = maxBottomButtonWidth + "px";
				}
			}
		}
		else if (grpSettings.get_orientation() == $IG.Orientation.Horizontal && childItemElem.style.height == "")
		{
			var maxHeight = 0;
			while (childItemElem)
			{
				if (!this._isSeparatorElement(childItemElem))
				{
					var offsetHeight = this.__getElementBoundsEx(childItemElem).height;
					(offsetHeight > maxHeight) ? maxHeight = offsetHeight : null;
				} else {
					//B.C. January 24th, 2012, Bug #99926 In IE last item is droped from the menu list because of insufficient menu width when we have separators.
					group.style.width = ($util.toIntPX(null, 'width', 0, group) + 1) + "px";
				}
				childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
			}

			childItemElem = childItem.get_element();			

			if (maxHeight && maxHeight > 0)
			{
				var maxHeightSeparator = maxHeight;
				if (this.get_enableScrolling())
				{
					group.parentNode.style.height = maxHeight + "px";
					if (group.previousSibling)
					{
						var leftButton = group.previousSibling;
						var maxLeftButtonHeight = maxHeight;
						maxLeftButtonHeight -= $util.toIntPX(null, 'borderTopWidth', 0, leftButton);
						maxLeftButtonHeight -= $util.toIntPX(null, 'borderBottomWidth', 0, leftButton);
						if(maxLeftButtonHeight > 0)
							leftButton.style.height = maxLeftButtonHeight + "px";
					}
					if (group.nextSibling)
					{
						var rigthButton = group.nextSibling;
						var maxRightButtonHeight = maxHeight;
						maxRightButtonHeight -= $util.toIntPX(null, 'borderTopWidth', 0, rigthButton);
						maxRightButtonHeight -= $util.toIntPX(null, 'borderBottomWidth', 0, rigthButton);
						if(maxRightButtonHeight > 0)
							rigthButton.style.height = maxRightButtonHeight + "px";
					}
				}

				maxHeight -= $util.toIntPX(null, 'paddingBottom', 0, group);
				maxHeight -= $util.toIntPX(null, 'paddingTop', 0, group);
				maxHeight -= $util.toIntPX(null, 'borderTopWidth', 0, group);
				maxHeight -= $util.toIntPX(null, 'borderBottomWidth', 0, group);
				maxHeight -= $util.toIntPX(null, 'marginBottom', 0, group);
				maxHeight -= $util.toIntPX(null, 'marginTop', 0, group);

				if(this.get_enableScrolling())
				{
					group.style.height = maxHeight + "px";
				}

				maxHeight -= $util.toIntPX(null, 'paddingBottom', 0, childItemElem);
				maxHeight -= $util.toIntPX(null, 'paddingTop', 0, childItemElem);
				maxHeight -= $util.toIntPX(null, 'borderTopWidth', 0, childItemElem);
				maxHeight -= $util.toIntPX(null, 'borderBottomWidth', 0, childItemElem);
				maxHeight -= $util.toIntPX(null, 'marginBottom', 0, childItemElem);
				maxHeight -= $util.toIntPX(null, 'marginTop', 0, childItemElem);

				while (childItemElem)
				{
					if (!this._isSeparatorElement(childItemElem))
					{
						childItemElem.style.height = maxHeight + 'px';
					}
					else
					{
						childItemElem.style.height = maxHeightSeparator + 'px';
					}
					childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
				}
			}
		}
	},

	__resizeScrollArea: function(ulBounds, scrollContainer, grpSettings)
	{
		var orientation = grpSettings.get_orientation();

		if (this.get_enableScrolling() && (this.__needsResize(scrollContainer.parentNode.resizeId) ||
		                                  (scrollContainer.style.height == "" && orientation == $IG.Orientation.Vertical) ||
										  (scrollContainer.style.width == "" && orientation == $IG.Orientation.Horizontal)))
		{
            // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
            // in the commented lines below
			//var firstScrollButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[0];
			//var secondScrollButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[1];
			var pageDims = this.__getPageDimensions();

			if (orientation == $IG.Orientation.Vertical && grpSettings.get_height() == 0)
			{
                // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
                // in the commented lines below
				//var firstScrollButtonHeight = this.__getElementBoundsEx(firstScrollButton).height;
				//var secondScrollButtonHeight = this.__getElementBoundsEx(secondScrollButton).height;
                //A.T. Fix for bug #37249 (this code is not needed ) 
				//var height = firstScrollButtonHeight + ulBounds.height + secondScrollButtonHeight;
                var height = ulBounds.height;
				
				if (height > pageDims.MaxY)
				{
					height = Math.floor((pageDims.MaxY * 99) / 100);
				}

				if(grpSettings.get_itemsFullAddress() == "-1")
				{
					// when the root context menu is positioned its size should be calculated respective to the opening position.
					var top = $util.toIntPX(null, 'top', 0, this._element);
					if(height + top > pageDims.MaxY)
					{
						height = height - top;
					}
					// L.T. 8/11/2010 59328. If you change this code make sure to test 57382 and 48174 as well!
					var marginTop = $util.toIntPX(null, 'marginTop', 0, this._element);
					if(height + marginTop > pageDims.MaxY)
					{
						height = height - marginTop;
					}

					var marginTopVal = $util.getStyleValue(null, 'marginTop', this._element);
					if(marginTopVal == "auto")
					{
						var controlBounds = this.__getElementBounds(this._element);
						if(height + controlBounds.y > pageDims.MaxY)
						{
							height = height - controlBounds.y;
						}
					}
				}

                if(height > 0)
				{
                    scrollContainer.style.height = height + "px";

					if(scrollContainer.realParent)
					{
						scrollContainer.parentNode.style.height = height + "px";
					}
				}

				if($util.IsIE7 && scrollContainer.parentNode.id == this._id && height > 0)
				{
					scrollContainer.parentNode.style.height = height + "px";
				}
			}
            // Bug #67035 K.D. March 19, 2011 We need to set the scrollercontainer width according to the
            // parent container when the parent container's width is in percentages
			else if (orientation == $IG.Orientation.Horizontal && (grpSettings.get_width() == 0 || grpSettings.get_width()[grpSettings.get_width().length - 1] == '%'))
			{
                // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
                // in the commented lines below
				//var firstScrollButtonWidth = this.__getElementBoundsEx(firstScrollButton).width;
				//var secondScrollButtonWidth = this.__getElementBoundsEx(secondScrollButton).width;
                //A.T. Fix for bug #37249 (this code is not needed ) 
				//var width = firstScrollButtonWidth + ulBounds.width + secondScrollButtonWidth;
                var width = ulBounds.width;

				if (width > pageDims.MaxX)
				{
					width = Math.floor((pageDims.MaxX * 99) / 100);
				}

				if(grpSettings.get_itemsFullAddress() == "-1")
				{
					// when the root context menu is positioned its size should be calculated respective to the opening position.
					var left = $util.toIntPX(null, 'left', 0, this._element);
					if(width + left > pageDims.MaxX)
					{
						width = width - left;
					}
					// L.T. 8/11/2010 59328. If you change this code make sure to test 57382 and 48174 as well!
					var marginLeft = $util.toIntPX(null, 'marginLeft', 0, this._element);
					if(width + marginLeft > pageDims.MaxX)
					{
						width = width - marginLeft;
					}

					var marginLeftVal = $util.getStyleValue(null, 'marginLeft', this._element);
					if(marginLeftVal == "auto")
					{
						var controlBounds = this.__getElementBounds(this._element);
						if(width + controlBounds.x > pageDims.MaxX)
						{
							width = width - controlBounds.x;
						}
					}
				}

                if(width > 0)
				{
                    scrollContainer.style.width = width + "px";

					if(scrollContainer.realParent)
					{
						scrollContainer.parentNode.style.width = width + "px";
					}
				}

				if($util.IsIE7 && scrollContainer.parentNode.id == this._id && width > 0)
				{
					scrollContainer.parentNode.style.width = width + "px";
				}

                // Bug #67035 K.D. March 19, 2011 We need to set the scrollercontainer width according to the
                // parent container when the parent container's width is in percentages
                var scrollParent = scrollContainer.parentNode;
                if(scrollParent.id == this._id && width > 0 && scrollParent.style.width[scrollParent.style.width.length - 1] == '%')
                {
                    var containerWidth = this.__getElementBounds(scrollParent).width + 'px';
                    scrollContainer.style.width = containerWidth;
                }
			}

			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			var scrollContainerBounds = this.__getElementBoundsEx(scrollContainer);
			var it = grpSettings.get_item();

			if (orientation == $IG.Orientation.Vertical)
			{
				if (it)
				{
					if (ulBounds.height < scrollContainerBounds.height)
					{
						it._displayScrollButton(0, false);
					}
					it._displayScrollButton(1, ulBounds.height > scrollContainerBounds.height);
				}
				else
				{
					var mainMenuScrollContainer = this._get_scrollContainer();
					if (ulBounds.height < scrollContainerBounds.height)
					{
						this._displayScrollButton(mainMenuScrollContainer, 0, false);
					}
					this._displayScrollButton(mainMenuScrollContainer, 1, ulBounds.height > scrollContainerBounds.height);
				}

				// if the user resized, scrolled up and resized so that no buttons are need we should reset the top of the scroll container.
				var ul = $adrutil.getImmediateElementsByTagName(scrollContainer, "UL")[0];
				if (ulBounds.height < scrollContainerBounds.height && $util.toIntPX(null, 'top', 0, ul) != 0)
				{
					ul.style.top = "0px";
				}
			}
			else
			{
				// show the second scroll button, when contents are bigger than scroll area.
				if (it)
				{
					if (ulBounds.width < scrollContainerBounds.width)
					{
						it._displayScrollButton(0, false);
					}
					it._displayScrollButton(1, ulBounds.width > scrollContainerBounds.width);
				}
				else
				{
					var mainMenuScrollContainer = this._get_scrollContainer();
					if (ulBounds.width < scrollContainerBounds.width)
					{
						this._displayScrollButton(mainMenuScrollContainer, 0, false);
					}
					this._displayScrollButton(mainMenuScrollContainer, 1, ulBounds.width > scrollContainerBounds.width);
				}

				// if the user resized, scrolled left and resized so that no buttons are need we should reset the left of the scroll container.
				var ul = $adrutil.getImmediateElementsByTagName(scrollContainer, "UL")[0];
				if (ulBounds.width < scrollContainerBounds.width && $util.toIntPX(null, 'left', 0, ul) != 0)
				{
					ul.style.left = "0px";
				}
			}
		}

		if (scrollContainer.style.width == "" && ulBounds.width > 0)
			scrollContainer.style.width = ulBounds.width + "px";

		if (scrollContainer.style.height == "" && ulBounds.height > 0)
			scrollContainer.style.height = ulBounds.height + "px";
	},

	_isSeparatorElement: function(domElement)
	{
		if (!$util.isNullOrUndefined(domElement))
		{
			return domElement.id && domElement.id.indexOf("mkr:sep") != -1;
		}
		return false;
	},

	//    _resizeTopLevelSeparators: function()
	//    {
	//        var item0 = this.getItems().getItem(0);
	//        var item0Elem = item0.get_element();
	//        if(this._menuGroupSettings.get_orientation() == $IG.Orientation.Vertical)
	//            this._resizeSeparators(item0, this._menuGroupSettings, item0Elem.offsetWidth, 1);
	//        else
	//            this._resizeSeparators(item0, this._menuGroupSettings, 1, item0Elem.offsetHeight);
	//    },

	//    _resizeSubLevelSeparators: function(item, width, height)
	//    {
	//        this._resizeSeparators(item.get_childItem(0), item.get_itemsGroupSettings(), width, height);
	//    },

	//    _resizeSeparators: function(childItem, grpSettings, width, height)
	//    {
	//        var childItemElem = childItem.get_element();
	//	    var orientation = grpSettings.get_orientation();

	//        while(childItemElem)
	//        {
	//            if(this._isSeparatorElement(childItemElem))
	//            {
	//                if(orientation == $IG.Orientation.Vertical)
	//                {
	//                    childItemElem.style.width = width + 'px';
	//                    var nextItemElem = $util.skipTextNodes(childItemElem.nextSibling);
	//                    /* dirty hack to make separators work */
	//                    if(nextItemElem &&
	//                       !this._isSeparatorElement(nextItemElem) &&
	//                       nextItemElem.style.marginTop == "")
	//                    {
	//                        nextItemElem.style.marginTop = "1px";
	//                    }
	//                }
	//                else
	//                {
	//                    childItemElem.style.height = height + 'px';
	//                }
	//            }
	//            childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
	//        }
	//    },

	__createFocusEl: function()
	{
		var inputEl = document.createElement("INPUT");
		inputEl.style.position = "absolute";
		inputEl.style.top = "1px";
		inputEl.style.left = "1px";
		inputEl.style.border = "0px none";
		inputEl.style.background = "transparent";
		inputEl.style.width = "1px";
		inputEl.style.height = "1px";
		inputEl.style.zIndex = "0";
		
		inputEl.style.outline = "none";
		inputEl.setAttribute("type", "button");
		// inputEl.setAttribute("tabindex", "-1");
		// A.T. 2009-10-08 Fix for bug #22847
		inputEl.setAttribute("tabIndex", this._get_clientOnlyValue("tabIndex"));
		// this._element.setAttribute("tabIndex", "-1"); L.T. !! never! Breaks kb navigation on FF, Chrome, Safari.
		inputEl.value = "";
		this._element.appendChild(inputEl);
		this._focusElement = inputEl;
	},

	_onFocusHandler: function(browserEvent)
	{
		if (this.__controlActive)
			return;

		if (this.get_isContextMenu() && this._contextClosingTimeOut != null)
		{
			clearTimeout(this._contextClosingTimeOut);
		}

		this.__controlActive = true;

		if ($util.isNullOrUndefined(this._activeItem))
		{
			this.__setActiveItem(this.getItems().getItem(0), false);
		}
		else
		{
			this._activeItem.set_active(true);
		}
	},

	_onBlurHandler: function(event)
	{
		this.__controlClicked = false;

		if (this.__cancelBlur)
		{
			this.__cancelBlur = false;
			setTimeout($util.createDelegate(this, this._focusEventElement, [false]), 50);
		}
		else if (this.__controlActive)
		{
			if ($util.IsIE)
			{
				this.__clickedOutside = false;
			}

			this.__controlActive = false;

			if (this._activeItem != null)
			{
				this._activeItem.set_active(false);
			}

			if(this._selectedItem && this._selectedItem.get_selected())
			{
				this._selectedItem._set_selected(true);
			}

			if (this.get_isContextMenu())
                // M.H. 25 Jul 2011 - fix bug 76404 - for setTimeout should be used 100ms for delay - otherwise the bug is reproduced in IE9
                this._contextClosingTimeOut = setTimeout(Function.createDelegate(this, this.__hideAll), 100);
			else
			{
				clearTimeout(this._timeoutID);
				this._timeoutID = setTimeout(Function.createDelegate(this, this.__hideAll), this.__subMenuClosingDelay);
			}
		}
	},

	dispose: function()
	{
		this._disposeMenu();
		if(this._pseudoControlDiv)
		{
			this._pseudoControlDiv.parentNode.removeChild(this._pseudoControlDiv);
			this._pseudoControlDiv = null;
		}
		if(this.get_isContextMenu())
			document.body.removeChild(this._element);
		$IG.WebDataMenu.callBaseMethod(this, 'dispose');
	},

	_disposeMenu: function()
	{
		// clear timeouts, they could be fired after the dispose and be a potential source of exceptions.
		clearTimeout(this._timeoutID);
		clearTimeout(this._contextClosingTimeOut);
		clearTimeout(this._openingDelayTimeoutID);
		clearTimeout(this.__scrollingTimeoutID);

		$clearHandlers(this.get_element());
		
		if(this.get_enabled())
		{
			if(this._focusElement)
			{
				$removeHandler(this._focusElement, 'focus', this._onFocusFn);
				$removeHandler(this._focusElement, 'blur', this._onBlurFn);
			}

			$removeHandler(document, 'mouseover', this._onDocumentMouseOverFn);

			if($util.IsIE)
			{
				$removeHandler(document, 'click', this._onDocumentClickFn);
			}
		}

		if(this.get_enableScrolling())
		{
            //A.T. 5 October 2010 - fix for bug #50032 - The menu is not resized when the splitter is resized under IE7
			//$removeHandler(window, 'resize', this._onResizeFn);
           clearInterval(this._resizeTimerID);
		}
	},

	_soft_dispose: function()
    {
        
        
		this._disposeMenu();

		this._elements = []; // clear markers
        // K.D. May 19, 2011 Bug #74373 If AjaxControlToolkit is referenced it has disposed of _events already
        // so check for the existence of _events should be made first before reseting the list
        if (this._events)
            this._events._list = []; // it's very important to clear the events !
		this.__clearOtherEvents();

        if (this._objectsManager)
			this._objectsManager.dispose();
		if (this._collectionsManager)
			this._collectionsManager.dispose();
    },

	_focusEventElement: function(blurBeforeFocus)
	{
		var fe = this._focusElement;
		if (fe && fe.focus)
		{
			try
			{
				var dims = this.__getPageDimensions(true);
                
				if (blurBeforeFocus) fe.blur();
				fe.focus();
                if ($util.IsIE)
				{
					if (document.documentElement.scrollTop != dims.ScrollTop)
						document.documentElement.scrollTop = dims.ScrollTop;
					if (document.documentElement.scrollLeft != dims.ScrollLeft)
						document.documentElement.scrollLeft = dims.ScrollLeft;
				}
				else
				{
					if (window.pageYOffset != dims.ScrollTop)
						window.scrollTo(0, dims.ScrollTop);
					if (window.pageXOffset != dims.ScrollLeft)
						window.scrollTo(0, dims.ScrollLeft);
				}
			} catch (e) { }
		}
	},

	showAt: function(x, y, browserEvent)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.showAt">
		/// Shows the menu at specified position
		///</summary>
		///<param name="x" type="int">The value for X-Axis where to show the menu</param>
		///<param name="y" type="int">The value for Y-Axis where to show the menu</param>
		///<param name="browserEvent" type="BrowserEvent">The borwser event object, to calculate position, if X,Y or both are empty</param>
		if (this._contextClosingTimeOut != null)
		{
			clearTimeout(this._contextClosingTimeOut);
		}
		this.__hideAll();
		this.__defaultContextHandler = document.oncontextmenu;
		this.__defaultMouseUpHandler = document.body.onmouseup;

		var f = function() { return false; };
		//window.oncontextmenu = f;
		document.oncontextmenu = f;
		document.body.onmouseup = f;

		if (typeof (x) == "undefined" || x == null)
		{
			if (browserEvent != null && typeof (browserEvent) != "undefined")
			{
				try { x = browserEvent.clientX + 2; } catch (e) { x = 0; }
			}
			else
			{
				if (window.event) x = window.event.clientX;
				else if (window.Event) { try { x = window.Event.clientX + 2; } catch (e) { x = 0; } }
				else x = 0;
			}
		}
		if (typeof (y) == "undefined" || y == null)
		{
			if (browserEvent != null && typeof (browserEvent) != "undefined")
			{
				try { y = browserEvent.clientY + 2; } catch (e) { y = 2; }
			}
			else
			{
				if (window.event) y = window.event.clientY;
				else if (window.Event) { try { y = window.Event.clientY + 2; } catch (e) { y = 2; } }
				else y = 0;
			}
		}
        
		var pageDims = this.__getPageDimensions(true);
		y += pageDims.ScrollTop;
		x += pageDims.ScrollLeft;
		this._element.style.position = "absolute";
		this._element.style.zIndex = "12000";

		if(this.get_enableScrolling())
		{
			var currentTop = $util.toIntPX(null, 'top', 0, this._element);
			var currentLeft = $util.toIntPX(null, 'left', 0, this._element);
			if(currentTop != y || currentLeft != x)
			{
				this.__resizedId++;
			}
		}

		this._element.style.top = y + "px";
		this._element.style.left = x + "px";
		if (this._menuGroupSettings.get_orientation() == $IG.Orientation.Horizontal && !this.get_enableScrolling())
		{
			var elBounds = this.__getElementBounds(this._element);
			this._element.style.width = elBounds.width + 'px';
		}

		this.__clearActiveItem();

        this.__topLevelItemsResized = false;
        this.__resizeTopLevelItems();

		this._element.style.display = "block";
		this._element.style.visibility = "visible";
		
		this._element.style.overflow = "visible";
		var that = this;
		var f = function() { that._focusEventElement(false); };
		window.setTimeout(f, 1);
	},

	hide: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.hide">
		/// Hides the menu if IsContextMenu is enabled
		///</summary>
		if (this.get_isContextMenu())
		{
			document.oncontextmenu = this.__defaultContextHandler;
			document.body.onmouseup = this.__defaultMouseUpHandler;

			this._element.style.display = "none";
			this._element.style.visibility = "hidden";
		}
	},

	_addHandlers: function()
	{
		$IG.WebDataMenu.callBaseMethod(this, '_addHandlers');
		if(this.get_enabled())
		{
			this._registerHandlers(["mousedown", "mouseup"]);
		}
	},

	getItems: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.getItems">Get the collection of menu items in the WebDataMenu.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItemCollection"></value>
		return this._itemCollection;
	},

	get_isContextMenu: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_isContextMenu">Get whether the menu is displayed as context menu.</summary>
		///<value type="Boolean"></value>
		if (this._get_value($IG.DataMenuProps.IsContextMenu) < 1)
			return false;
		return true;
	},

	get_enableExpandOnClick: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_enableExpandOnClick">Get whether the menu items expand when they are clicked with the mouse.</summary>
		///<value type="Boolean"></value>
		if (this._get_value($IG.DataMenuProps.EnableExpandOnClick) < 1)
			return false;
		return true;
	},

	get_selectedItem: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_selectedItem">Get the currently selected item.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
		return this._selectedItem;
	},

	get_activeItem: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_activeItem">Get the currently active item.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
		return this._activeItem;
	},

	get_scrollingSpeed: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.scrollingSpeed">Get the menu scrolling speed.</summary>
		///<value type="Infragistics.Web.UI.ScrollingSpeed"></value>
		return this._get_value($IG.DataMenuProps.ScrollingSpeed);
	},

	set_scrollingSpeed: function(value)
	{
		///<summary>Specify scrolling speed of the items during scrolling.</summary>
		///<param type="Infragistics.Web.UI.DataMenuScrollingSpeed"></param>
		this._set_value($IG.DataMenuProps.ScrollingSpeed, value);
	},

	get_enableScrolling: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.enableScrolling">Get whether the scrolling feature is enabled.</summary>
		///<value type="Boolean"></value>
		return this.__enableScrolling;
	},

	get_enabled: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.enabled">Get whether the menu is enabled.</summary>
		///<value type="Boolean"></value>
		return this.__enabled;
	},

	__clearActiveItem: function()
	{
		if (this._activeItem != null)
		{
			this._activeItem.set_active(false);
			this._selectItem(this._activeItem, false);
			this._activeItem = null;
		}
	},

	__setActiveItem: function(item, force)
	{
		if (this._activeItem != null)
		{
			this._activeItem.set_active(false);
		}
		
		if (item == null) return;
		item.set_active(true, force);
		this._activeItem = item;
	},

	// called by the Aikido behaviors 
	_selectItem: function(item, val)
	{
		if (!item.get_isSeparator())
			this.__selectItem(item, val);
	},

	__selectItem: function(item, val, force)
	{
		var selAddr = (this._selectedItem != null) ? this._selectedItem._address : "";
		var realForce = (force != null && typeof (force) != "undefined") ? force : false;
		if (val && (item._address != selAddr || realForce))
		{
			

			if (this.__isInitialized)
				var args = this._raiseClientEvent('ItemSelecting', 'DataMenuItemCancel', null, null, item);

			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				if (this.__isInitialized)
					this._raiseClientEventEx('ItemSelected', $IG.DataMenuItemCancelEventArgs, [item]);

				this.__unselectAll(this.getItems());
				item.set_selected(true);
				this._selectedItem = item;
			}
			


			else
			{
				item.set_selected(false);
			}
		}
		else if (!val)
		{
			item.set_selected(false);
		}
	},

	_raiseClientEventEx: function(clientEventName, evntArgs, eventArgsParams)
	{
		var args = null;
		var clientEvent = this._clientEvents[clientEventName];
		if (clientEvent != null)
		{
			if (evntArgs == null)
				args = new $IG.EventArgs();
			else
				args = new evntArgs(clientEventName, eventArgsParams); // L.T. 4/11/2010 59265 all eventArgs receive the eventName first!
			args = this._raiseSenderClientEvent(this, clientEvent, args);
		}
		return args;
	},

	__unselectAll: function(items)
	{
		
		//	    for (var i = 0, len = items.getChildrenCount(); i < len; i++)
		//	    {
		//            var item = items.getItem(i);
		//	        item.set_selected(false);
		//	        if(item.hasChildren())
		//	        {
		//	            this.__unselectAll(item.getItems());
		//	        }
		//	    }
		if (this._selectedItem && this._selectedItem.get_selected())
		{
			this._selectedItem.set_selected(false);
			this._selectedItem = null;
		}
	},

	__hideItem: function(item)
	{
		args = this._raiseClientEvent('ItemCollapsing', 'DataMenuItemCancel', null, null, item);

		if (args && args.get_cancel())
			return false;

		this.__hideItemElement(item);

		this._raiseClientEvent('ItemCollapsed', 'DataMenuItemCancel', null, null, item);

		return true;
	},

	__getPageDimensions: function(force)
	{
		


		if ($util.isNullOrUndefined(this.__pageSize) || force)
		{
			var pageHeight = 0;
			var pageScrollTop = 0;
			var pageWidth = 0;
			var pageScrollLeft = 0;
			var pageScrollWidth = document.body.scrollWidth;
			var pageScrollHeight = document.body.scrollHeight;
			if (document.compatMode == "BackCompat")
			{
				pageHeight = document.body.clientHeight;
				pageScrollTop = document.body.scrollTop + document.body.parentNode.scrollTop;
				pageWidth = document.body.clientWidth;
				pageScrollLeft = document.body.scrollLeft + document.body.parentNode.scrollLeft;
			} else
			{
				
				pageHeight = window.innerHeight;
				pageScrollTop = window.pageYOffset;
				pageWidth = window.innerWidth;
				pageScrollLeft = window.pageXOffset;
				if ($util.IsIE)
				{
					if($util.IsIE7)
					{
						
						document.body.style.overflow = 'hidden'; // will hide the scrollbars on IE7
						this.__scrollbarWidth = document.documentElement.clientWidth - document.body.offsetWidth;
						document.body.style.overflow = '';
					}					
					pageHeight = document.documentElement.clientHeight;
					pageScrollTop = document.documentElement.scrollTop;
					pageWidth = document.documentElement.clientWidth;
					pageScrollLeft = document.documentElement.scrollLeft;
					pageScrollHeight = document.documentElement.scrollHeight;
					pageScrollWidth = document.documentElement.scrollWidth;
				}
			}
			var scrollBarWidth = this.__get_scrollbarWidth();
			var dims = new Object();
			dims.Width = pageWidth;
			dims.Height = pageHeight;
			dims.ScrollLeft = pageScrollLeft;
			dims.ScrollTop = pageScrollTop;
			dims.ScrollWidth = pageScrollWidth;
			dims.ScrollHeight = pageScrollHeight;
			dims.X = pageScrollWidth - pageScrollLeft;
			dims.Y = pageScrollHeight - pageScrollTop;
			dims.MaxX = dims.ScrollLeft + dims.Width - scrollBarWidth;
			dims.MaxY = dims.ScrollTop + dims.Height - scrollBarWidth;

			this.__pageSize = dims;
		}
		return this.__pageSize;
	},

	__focusLink: function(item, fromParent)
	{
		clearTimeout(this._timeoutID);
		var isChild = false;
		if (!$util.isNullOrUndefined(fromParent))
		{
			if (fromParent) isChild = true;
		}
		if (!$util.isNullOrUndefined(item) && !item.get_isSeparator())
		{
			if (this._activeItem != null && !isChild)
			{
				$util.removeCompoundClass(this._activeItem.get_element(),
                                          this._activeItem.get_stateCssClass("Active"));
			}

			this.__hideUpLevelItems(item);
			this._activeItem = item; // 44165: Needed so that parent items remain active.
			this.__setActiveItem(item);
		}
	},

	_onMouseupHandler: function(elem, adr, event)
	{
		this.__controlClicked = true;

		if (this.__accelerateScrolling)
		{
			this.__accelerateScrolling = false;
		}
	},

	_onMousedownHandler: function(elem, adr, event)
	{
		
		if (!this.get_isInitialized())
			return false;

		if (this._isScrollButtonTarget(event))
		{
			this.__accelerateScrolling = true;
			if ($util.IsIE)
			{
				this.__cancelBlur = true;
			}
			$util.cancelEvent(event);
			return false;
		}

		var item = this.getItems()._getObjectByAdr(adr);

		if (item && !item.get_enabled())
		{
			if ($util.IsIE)
			{
				this.__cancelBlur = true;
			}
			$util.cancelEvent(event);
			return false;
		}

		if (!this.__activateOnHover && !this.__controlActive)
		{
			if (item) { this.__setActiveItem(item); }
			this._focusEventElement(false);
			if (item) { item.open(); }
		}
		else if(item && !item.get_expanded() && item.hasChildren())
		{
			if (this.__showItem(item))
				this.__hideUpLevelItems(item);
		}
		else
		{
			this.__closeMenuOnClick(item);
		}

		if (!$util.isNullOrUndefined(item) && item._getFlags().getEnabled(this))
		{
			// L.T. 2/11/2010 58814 focus is not properly handled.
            // K.D. 20/12/2010 61566 We have to add the condition of closeOnClick being false, because otherwise the menu
            // closes when clicked on submenu item
			if (($util.IsIE && this.__activateOnHover) || ($util.IsIE && !this.__closeOnClick))
				this.__cancelBlur = true;
			item._toggleClicked();
			
			this._posted = false;
			var args = this._raiseClientEventEx("ItemClick", $IG.DataMenuItemCancelEventArgs, [item]);
			this.__focusLink(item);
			if (args && args.get_cancel())
			{
				item._toggleClicked(); // return the old value, since the click is cancelled.
				return false;
			}
			if(this._posted)
				item._clearTransactions();

			if (event.button == '0')
			{
				// Navigate if the events is not cancelled, and only on left button click.
				item._navigateOnClick();
			} 
			
			else if (event.button == '1')
			{
				item._navigateOnClick(true);
			}
		}
	},

	__closeMenuOnClick: function(itemClicked)
	{
		if($util.isNullOrUndefined(itemClicked))
			return;

		if(itemClicked.get_level() > 0) // applys only to non root items.
		{
			if(this.__closeOnClick && !itemClicked.hasChildren())
			{
				if (this.get_isContextMenu())
				{
					this.hide();
				}
				else
				{
					this.__hideAll();
				}
			}
		}
		else
		{
			if (this.get_isContextMenu() && !itemClicked.hasChildren())
			{
				// we clicked on a root item of a context menu that do not have children -> close the menu.
				this.hide();
			}
			else if(itemClicked.get_expanded())
			{
				// if we click for a second time on a root menu item of a non context menu, close the item.
				this.__hideAll();
			}
		}
	},

	_onKeydownHandler: function(event)
	{
		if (!this.get_isInitialized())
			return false;

		var item = (this._activeItem) ? this._activeItem : this.getItems().getItem(0);

		if ($util.isNullOrUndefined(item))
			return false;

		this.__setActiveItem(item);

		args = this._raiseClientEvent("KeyDown", "DataMenuItemCancel", null, null, item);
		if (args && args.get_cancel())
		{
			return false;
		}

		var shouldPreventDefault = false;

		switch (event.keyCode)
		{
			case Sys.UI.Key.space:
				{
					this.__selectItem(item, !item.get_selected(), true);
					break;
				}

			case Sys.UI.Key.left:
				{
					if (item.get_orientation() == $IG.Orientation.Horizontal)
					{
						this.__focusPrevious(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}
			case Sys.UI.Key.right:
				{
					
					var orientation = item.get_orientation();
					if (orientation == $IG.Orientation.Horizontal)
					{
						this.__focusNext(item);
					}
					
					else if (orientation == $IG.Orientation.Vertical && item.hasChildren())
					{
						this.__focusChild(item);
					}
					
					else if (orientation == $IG.Orientation.Vertical && !item.hasChildren())
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.enter:
				{
					// K.D. March 24, 2011 Bug #70070 Enter key does not have an effect on the WebDataMenu
                    // Doing this so that ItemClick server event fires
                    item._toggleClicked();
					
					this._posted = false;
					var args = this._raiseClientEventEx("ItemClick", $IG.DataMenuItemCancelEventArgs, [item]);
					if (args && args.get_cancel())
					{
                        // Returning the item to its previous state if event canceled
                        item._toggleClicked();
						return false;
					}

		            

		            item._navigateOnClick();

					if(this._posted)
						item._clearTransactions();
					this.__selectItem(item, true, true);
					this.__focusLink(item);
					
					
					if (!this.get_enableExpandOnClick())
					{
						if (this.get_isContextMenu())
							this._contextClosingTimeOut = window.setTimeout(Function.createDelegate(this, this.hide), this.__subMenuClosingDelay);
						else
							this._timeoutID = window.setTimeout(Function.createDelegate(this, this.__hideAll), this.__subMenuClosingDelay);
					}
					shouldPreventDefault = true;
					break;
				}
			case Sys.UI.Key.esc:
				{
					
					this.__hideAll();
					
					var firstItem = this.getItems().getItem(0);
					this.__focusLink(firstItem);
					break;
				}

			case Sys.UI.Key.tab:
			case Sys.UI.Key.space:
				{
					
					break;
				}

			case Sys.UI.Key.up:
				{
					
					if (item.get_orientation() == $IG.Orientation.Vertical)
					{
						this.__focusPrevious(item);
					}
					else if (item.hasChildren())
					{
						this.__focusChild(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.down:
				{
					if (item.get_orientation() == $IG.Orientation.Vertical)
					{
						this.__focusNext(item);
					}
					else if (item.hasChildren())
					{
						this.__focusChild(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.home:
				{
					var items = this.getItems();
					if (this._activeItem)
					{
						var parentItem = this._activeItem.get_parentItem();
						if (parentItem)
						{
							items = parentItem.getItems();
						}
					}

					var firstItem = items.getItem(0);
                    // K.D. April 13, 2011 Bug #72230 We need to clear selection and restore style if the active
                    // item is not the first item
                    if(firstItem && firstItem != this._activeItem)
                    {
                        this._activeItem.set_selected(false);
                        this._activeItem.restore_style();
                    }

					if (firstItem && firstItem.get_enabled() &&
                   this._activeItem &&
                   firstItem._get_address() != this._activeItem._get_address())
					{
						this.__focusLink(firstItem);
					}
					else if (!this._activeItem && firstItem)
					{
						this.__focusLink(firstItem);
					}
					break;
				}

			case Sys.UI.Key.end:
				{
					var items = this.getItems();
					if (this._activeItem)
					{
						var parentItem = this._activeItem.get_parentItem();
						if (parentItem)
						{
							items = parentItem.getItems();
						}
					}

					var lastItem = items.getItem(items.getChildrenCount() - 1);
                    // K.D. April 13, 2011 Bug #72230 We need to clear selection and restore style if the active
                    // item is not the last item
                    if(lastItem && lastItem != this._activeItem)
                    {
                        this._activeItem.set_selected(false);
                        this._activeItem.restore_style();
                    }

					if (lastItem && lastItem.get_enabled() &&
                   this._activeItem &&
                   lastItem._get_address() != this._activeItem._get_address())
					{
						this.__focusLink(lastItem);
					}
					else if (!this._activeItem)
					{
						this.__focusLink(lastItem);
					}
					break;
				}

			default:
				break;
		}

		if(event.keyCode != Sys.UI.Key.esc)
			this.__scrollToActiveItem();

		if (shouldPreventDefault)
		{
			$util.cancelEvent(event);
		}
	},

	__scrollToActiveItem: function()
	{
		var item = this._activeItem;

		if ($util.isNullOrUndefined(item) || !this.get_enableScrolling())
			return;

		var parentItem = item.get_parentItem();

		var firstScrollButtonVisible = false;
		var secondScrollButtonVisible = false;
		var scrollContainer;
		var orientation;

		if (parentItem)
		{
			scrollContainer = parentItem._get_scrollContainer();
			firstScrollButtonVisible = parentItem._getScrollButtonVisible(0);
			secondScrollButtonVisible = parentItem._getScrollButtonVisible(1);
			orientation = parentItem.get_itemsGroupSettings().get_orientation();
		}
		else
		{
			scrollContainer = this._get_scrollContainer();
			firstScrollButtonVisible = this._getScrollButtonVisible($adrutil.getImmediateElementsByTagName(scrollContainer, "A")[0]);
			secondScrollButtonVisible = this._getScrollButtonVisible($adrutil.getImmediateElementsByTagName(scrollContainer, "A")[1]);
			orientation = this.get_menuGroupSettings().get_orientation();
		}

		var itemBounds = Sys.UI.DomElement.getBounds(item.get_element());
		var scrollContainerBounds = this.__getElementBounds(scrollContainer);
		var subgroup = $adrutil.getImmediateElementsByTagName(scrollContainer, "UL")[0];
		var firstButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[0];
		var secondButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[1];
		var firstButtonBounds = Sys.UI.DomElement.getBounds(firstButton);
		var secondButtonBounds = Sys.UI.DomElement.getBounds(secondButton);

		if (orientation == $IG.Orientation.Horizontal)
		{
			var oldLeft = $util.toIntPX(null, 'left', 0, subgroup);

			if (itemBounds.x > scrollContainerBounds.x + scrollContainerBounds.width - secondButtonBounds.width)
			{
				// item is not visible on the right side of the container.                
				subgroup.style.left = (oldLeft + ((itemBounds.x - (scrollContainerBounds.x + scrollContainerBounds.width) + itemBounds.width + (secondScrollButtonVisible ? 10 : 0)) * -1)) + "px";
				this._displayScrollButton(scrollContainer, 0, true);
				this.__resizedId++;
			}
			else if (itemBounds.x < scrollContainerBounds.x + firstButtonBounds.width)
			{
				// item is not visible on the left of the container.
				subgroup.style.left = (oldLeft + (scrollContainerBounds.x - itemBounds.x) + (firstScrollButtonVisible ? 10 : 0)) + "px";
				this._displayScrollButton(scrollContainer, 1, true);
				this.__resizedId++;
			}
		}
		else if (orientation == $IG.Orientation.Vertical)
		{
			var oldTop = $util.toIntPX(null, 'top', 0, subgroup);

			if (itemBounds.y > scrollContainerBounds.y + scrollContainerBounds.height - secondButtonBounds.height)
			{
				// item is not visible and is below the container.
				subgroup.style.top = (oldTop + ((itemBounds.y - (scrollContainerBounds.y + scrollContainerBounds.height) + itemBounds.height + (secondScrollButtonVisible ? 10 : 0)) * -1)) + "px";
				this._displayScrollButton(scrollContainer, 0, true);
				this.__resizedId++;
			}
			else if (itemBounds.y < scrollContainerBounds.y + firstButtonBounds.height)
			{
				// item is not visible and is before the container.
				subgroup.style.top = (oldTop + (scrollContainerBounds.y - itemBounds.y) + (firstScrollButtonVisible ? 10 : 0)) + "px";
				this._displayScrollButton(scrollContainer, 1, true);
				this.__resizedId++;
			}
		}

		var hasNextItem = !$util.isNullOrUndefined(item.get_nextItem());
		if (!hasNextItem && this._getScrollButtonVisible(secondButton))
		{
			if (orientation == $IG.Orientation.Horizontal)
			{
				var ulWidth = Sys.UI.DomElement.getBounds(subgroup).width;
				if (scrollContainerBounds.width - $util.toIntPX(null, 'left', 0, subgroup) >= ulWidth)
				{
					subgroup.style.left = ((ulWidth - scrollContainerBounds.width) * -1) + "px";
				}
			}
			else
			{
				var ulHeight = Sys.UI.DomElement.getBounds(subgroup).height;
				if (scrollContainerBounds.height - $util.toIntPX(null, 'top', 0, subgroup) >= ulHeight)
				{
					subgroup.style.top = ((ulHeight - scrollContainerBounds.height) * -1) + "px";
				}
			}
			// if we scrolled to last item hide the last scroll button
			this._displayScrollButton(scrollContainer, 1, false);
		}

		var hasPreviousItem = !$util.isNullOrUndefined(item.get_previousItem());
		if (!hasPreviousItem && this._getScrollButtonVisible(firstButton))
		{
			// if we scrolled to first item hide the first scroll button
			this._displayScrollButton(scrollContainer, 0, false);
			orientation == $IG.Orientation.Horizontal ? subgroup.style.left = "0px" : subgroup.style.top = "0px";
		}
	},

	__focusParent: function(item)
	{
		



		var parent = item.get_parentItem();
		
		if (parent != null)
		{
			// L.T. 11/11/2010 59618 Do this only when ItemCollapsing is not cancelled!
			if(this.__hideItem(item))
			{
				item.set_selected(false);
				this.__focusLink(parent);
				item.restore_style();
			}
		}
	},

	__focusChild: function(item)
	{
		




		if (item)
		{
			item.set_selected(false);
			if (this.__showItem(item) || item.get_expanded())
				this.__focusLink(item.get_childItem(0, true), true);
		}
	},

	__focusPrevious: function(item)
	{
		





		item.set_selected(false);
		item.restore_style();

		var collection = item.getItems()._ownerNode;
		var collectionLength = collection.get_length();
		var prevItem = item.get_previousItem();
		var index = collection.get_indexOf(item);
		var initialIndex = index;

		index--;

		if (index < 0)
		{
			index = collectionLength - 1;
			prevItem = collection.getItem(index);
		}

		while (prevItem && (prevItem.get_isSeparator() || !prevItem._getFlags().getEnabled(this)))
		{
			prevItem = prevItem.get_previousItem();
			index--;
			if (index == initialIndex) break;
			if (index < 0) { index = collectionLength - 1; prevItem = collection.getItem(index); }
		}

		this.__focusLink(prevItem);
	},

	__focusNext: function(item)
	{
		





		item.set_selected(false);
		item.restore_style();

		var collection = item.getItems()._ownerNode;
		var collectionLength = collection.get_length();
		var nextItem = item.get_nextItem();
		var index = collection.get_indexOf(item);
		var initialIndex = index;

		index++;

		if (index >= collectionLength)
		{
			index = 0;
			nextItem = collection.getItem(index);
		}

		while (nextItem && (nextItem.get_isSeparator() || !nextItem._getFlags().getEnabled(this)))
		{
			nextItem = nextItem.get_nextItem();
			index++;
			if (index == initialIndex) break;
			if (index >= collectionLength) { index = 0; nextItem = collection.getItem(index); }
		}

		this.__focusLink(nextItem);
	},

	_setupCollections: function()
	{
		this._itemCollection = this._collectionsManager.register_collection(0, $IG.DataMenuItemCollection);
		this._itemCollection._owner = this;
		this._collectionsManager.registerUIBehaviors(this._itemCollection);

		this._groupSettingsCollection = this._collectionsManager.register_collection(1, $IG.DataMenuGroupSettingsCollection);
		this._groupSettingsCollection._owner = this;

		this._itemCollection._getUIBehaviorsObj().initElemAttr = this._uiBehaviorsObject_initElemAttr;
	},

	_uiBehaviorsObject_initElemAttr: function(elem)
	{
		if (elem.getAttribute("adr") == null)
		{
			$util._initAttr(elem);
		}
	},

	__hideAll: function()
	{
		if($util.isNullOrUndefined(this.get_element())) // we are somehow called after the control is disposed.
			return;

		this._clearOpeningDelayTimeoutContext();

		clearTimeout(this._timeoutID);

		for (var key in this._visibleItems)
		{
		    
		    if (this._visibleItems.hasOwnProperty(key))
		    {
		        var item = this._visibleItems[key];
		        if (!$util.isNullOrUndefined(item))
		        {
		            // L.T. 11/11/2010 59618 Do this only when ItemCollapsing is not cancelled!
		            if (this.__hideItem(item))
		            {
		                item.set_expanded(false);
		                item.set_hover(false);
		                delete this._visibleItems[key];
		            }
		        }
		    }
		}

		if (this.get_isContextMenu())
		{
			this.hide();
		}
	},

	__hideUpLevelItems: function(currentItem)
	{
		var currentLevel = currentItem.get_level();

		for (var key in this._visibleItems)
		{
		    
		    if (this._visibleItems.hasOwnProperty(key))
		    {
		        var item = this._visibleItems[key];

		        if (!$util.isNullOrUndefined(item) &&
                   item != currentItem)
		        {
		            var level = item.get_level();
		            if (level >= currentLevel)
		            {
		                if (currentItem.isDescendant(item))
		                    continue;
		                args = this._raiseClientEvent("ItemCollapsing", "DataMenuItemCancel", null, null, item);
		                if (args && args.get_cancel())
		                    continue;

		                item.set_expanded(false);
		                item.set_hover(false);

		                if (key != currentItem._get_address())
		                    this.__hideItemElement(item);

		                this._raiseClientEvent("ItemCollapsed", "DataMenuItemCancel", null, null, item);
		                delete this._visibleItems[key];
		            }
		        }
		    }
		}
	},

	
	_shouldHover: function(item, e)
	{
		
		if (!this.get_isInitialized() || !this.__enabled) return false;
		e.cancelBubble = true;
		
		if (item.get_isSeparator()) return false;

		if (e.type == "mouseover")
		{
			
			if (item._getFlags().getHovered()) return false;
			else return true;
		}
		else if (e.type == "mouseout") // && e.target.nodeName == "LI")
		{
			
			if (!item._getFlags().getHovered()) return false;

			
			return $util.isOut(e, item._element);
		}
		return false;
	},

	_clearOpeningDelayTimeoutContext: function()
	{
		clearTimeout(this._openingDelayTimeoutID);
		delete this._openingDelayTimeoutID;
		delete this.__hoverItemContext_Item;
		delete this.__hoverItemContext_Subgroup;
		delete this.__subMenuOpeningDelayInProgress;
	},

	_expandOnHoverHelper: function(subgroup, item)
	{
		if (!$util.isNullOrUndefined(this.__hoverItemContext_Subgroup) &&
           ($util.isNullOrUndefined(subgroup) || ($util.IsFireFox && (typeof (subgroup)).toLowerCase() == "number")))
		{
			// fetch the subgroup from the context if we are called by setTimeout.
			subgroup = this.__hoverItemContext_Subgroup;
		}

		if (!$util.isNullOrUndefined(this.__hoverItemContext_Item) &&
            $util.isNullOrUndefined(item))
		{
			// fetch the item from the context if we are called by setTimeout.
			item = this.__hoverItemContext_Item;
			// We assume subgroup is properly fetched and we are good to go to clear.
			this._clearOpeningDelayTimeoutContext();
		}

		if (!$util.isNullOrUndefined(item) &&
           !$util.isNullOrUndefined(subgroup))
		{
			// Show the sub menu.
			if (this.__showItem(item))
            {
                //A.T. Fix for #48430
                this.__expandedItems.push(item);
            }
		}
	},

	_isSubMenuOpeningDelayApplied: function(subgroup, item)
	{
		if (this.__subMenuOpeningDelay > 0 &&
           !this.get_enableExpandOnClick() &&
           !item.get_expanded())
		{
			if (item.hasChildren())
			{
				if ($util.isNullOrUndefined(this.__subMenuOpeningDelayInProgress))
				{
					this.__subMenuOpeningDelayInProgress = true;
					this.__hoverItemContext_Item = item;
					this.__hoverItemContext_Subgroup = subgroup;
					this._openingDelayTimeoutID = setTimeout(Function.createDelegate(this, this._expandOnHoverHelper), this.__subMenuOpeningDelay);
					return true;
				}
				else if (this.__subMenuOpeningDelayInProgress)
				{
					if (!(this.__hoverItemContext_Item === item))
					{
						clearTimeout(this._openingDelayTimeoutID);
						this.__hoverItemContext_Item = item;
						this.__hoverItemContext_Subgroup = subgroup;
						this._openingDelayTimeoutID = setTimeout(Function.createDelegate(this, this._expandOnHoverHelper), this.__subMenuOpeningDelay);
						return true;
					}
				}
			}
			else
			{
				if (!$util.isNullOrUndefined(this.__subMenuOpeningDelayInProgress) &&
                    this.__subMenuOpeningDelayInProgress)
				{
					if (!(this.__hoverItemContext_Item === item))
					{
						this._clearOpeningDelayTimeoutContext();
					}
				}
			}
		}
		return false;
	},

	
	_hoverItem: function(item, shouldHover)
	{
		if (this.__activateOnHover && !this.__controlActive)
		{
			if(this._selectedItem)
				this._selectedItem._set_selected(false);
			this.__setActiveItem(item);
			this._onFocusHandler();
			this.__cancelBlur = true;
			this._focusEventElement(false);
		}
		else if (this.__controlActive)
		{
			this.__setActiveItem(item);
		}

		if (shouldHover)
		{
			clearTimeout(this._timeoutID);

			var hoveredItem = this._hoveredItem;
			if (hoveredItem &&
               hoveredItem._get_address() != item._get_address())
			{
				
				hoveredItem._getFlags().setHovered(false);
				hoveredItem.restore_style();
			}

			this._raiseClientEvent("ItemHovered", "DataMenuItemCancel", null, null, item);			

			if (this.__controlActive)
			{
				// allow hover, but open only when control is active.
				var subgroup = this.get_enableScrolling() ? item._get_scrollContainer() : item._get_subgroup();
				if (!this._isSubMenuOpeningDelayApplied(subgroup, item))
				{
					if (subgroup && !this.get_enableExpandOnClick())
					{
						this._expandOnHoverHelper(subgroup, item);
					}
				}

				if (!this.get_enableExpandOnClick())
				{
					this.__hideUpLevelItems(item);
				}
			}

			this._hoveredItem = item;
		}
		else
		{
			this._hoveredItem = null;
			this._raiseClientEvent("ItemUnhovered", "DataMenuItemCancel", null, null, item);
		}
		item.set_hover(shouldHover);
	},

	get_menuGroupSettings: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_menuGroupSettings">Get the menu group settings.</summary>
		///<value type="Infragistics.Web.UI.DataMenuGroupSettings"></value>
		return this._menuGroupSettings;
	},

	get_orientation: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_orientation">Get the menu orientation setting.</summary>
		///<value type="Infragistics.Web.UI.Orientation"></value>
		return this.get_menuGroupSettings().get_orientation()
	},

	removeItem: function(item)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.removeItem">Remove an item from the menu.</summary>
		///<param name="item" type="Infragistics.Web.UI.DataMenuItem">Menu item.</param>
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		if(!item || !item._owner || item._owner._id !== this._id) // item does not belong to this control.
			return false;

		var adr = item._get_address();
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = cbo.clientContext.type = "remove";
		cbo.serverContext.address = adr;
		cbo.clientContext.item = item;
		cbo.clientContext.parentItem = item.get_parentItem();		

		if (this._activeItem && this._activeItem._get_address() === adr)
		{
			this.__clearActiveItem();
		}

		if (this._selectedItem && this._selectedItem._get_address() === adr)
		{
			this.__unselectAll();
		}

		if (this._activeItem)
		{
			cbo.serverContext.activeItemAddress = this._activeItem._get_address();
		}

		if (this._selectedItem)
		{
			cbo.serverContext.selectedItemAddress = this._selectedItem._get_address();
		}

		if(this.get_enableScrolling())
		{
			var slider = $get(this._id + "_" + ($adrutil.getLevelByAdr(adr) > 0 ? $adrutil.getParentAddress(adr) : adr));
			if(slider)
				slider.parentNode.removeChild(slider);
		}

		this._callbackManager.execute(cbo, true, true, false);
	},

	addItem: function(txt, parentItem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.addItem">Add an item to the menu.</summary>
		///<param name="itemText" type="String">Specify item text.</param>
		///<param name="parentItem" type="Infragistics.Web.UI.DataMenuItem">Specify the parent menu item of the new item that will be added.</param>
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		var adr = "";
		if (parentItem)
		{
			adr = parentItem._get_address();

			if(this.get_enableScrolling())
			{
				var slider = $get(this._id + "_" + adr);
				if(slider)
					slider.parentNode.removeChild(slider);
			}
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = cbo.clientContext.type = "add";
		cbo.serverContext.address = adr;
		cbo.serverContext.text = txt;
		cbo.clientContext.parentItem = parentItem;
		this._callbackManager.execute(cbo, true, true, false);
	},

	_responseComplete: function(callbackObject, responseObject, obj)
	{
		
		$IG.WebDataMenu.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		switch (callbackObject.serverContext.type)
		{
			case "add":
			{
				var html = responseObject.context[1];
				var parentItem = callbackObject.clientContext.parentItem;
				var element;
				if (!$util.isNullOrUndefined(parentItem))
				{
					element = parentItem.get_element();
				}
				else
				{
					element = document.createElement("LI");
					var ul = $adrutil.getImmediateElementsByTagName(this.get_enableScrolling() ? this._get_scrollContainer() : this.get_element(), "UL")[0];
					if (ul)
					{
						ul.appendChild(element);
					}
				}

				var helperEl = document.createElement("DIV");
				helperEl.innerHTML = html;
				element.id = helperEl.firstChild.id;
				element.className = helperEl.firstChild.className;
				element.innerHTML = helperEl.firstChild.innerHTML;
				delete helperEl;

				if(this.get_enableScrolling())
				{
					// reset the height of the ULs so that initalization code in initalize() could handle this.
					var uls = this.get_element().getElementsByTagName("UL");
					for(var i=0, len = uls.length; i < len; i++)
					{
						var style = uls[i].style;
						style.height = "";
						style.width = "";
					}
				}
			}
			break;

			case "remove":
			{
				var html = responseObject.context[1];
				var parentItem = callbackObject.clientContext.parentItem;
				var element = this.get_element();
				if (parentItem)
				{
					element = parentItem.get_element();
					var helperEl = document.createElement("DIV");
					helperEl.innerHTML = html;
					element.id = helperEl.firstChild.id;
					element.className = helperEl.firstChild.className;
					element.innerHTML = helperEl.firstChild.innerHTML;
					delete helperEl;
				}
				else
				{
					element.innerHTML = html;
				}
			}
			break;
		}

		this.__isInitialized = false;
		this._soft_dispose();
		var props = eval(responseObject.context[0]);
		this.set_props(props);
		this.preventInitEvent = true;
		this.initialize();

		if(callbackObject.serverContext.activeItemAddress)
			this._activeItem = this._itemCollection._getObjectByAdr(callbackObject.serverContext.activeItemAddress);

		if(callbackObject.serverContext.selectedItemAddress)
			this._selectedItem = this._itemCollection._getObjectByAdr(callbackObject.serverContext.selectedItemAddress);
	},

	_ensureItem: function(e, adr)
	{
		var item = this._itemCollection._getObjectByAdr(adr);
		if (item == null || e != null)
			item = this._itemCollection._addObject($IG.DataMenuItem, e, adr);
		return item;
	},

	/////////////////////////////////////////////////// SCROLLING FEATURE ////////////////////////////////////////

	__createTopLevelDivStructure: function()
	{
		var div = document.createElement("DIV");
		div.style.width = "0px";
		div.style.height = "0px";
		div.style.visibility = "hidden";
		div.style.position = "absolute";
		div.style.left = "0px";
		div.style.margin = "0px";
		div.style.padding = "0px";
		div.style.display = "inline-block";
        // K.D. April 27, 2011 If the parent element of the menu had text-align: center this messes up the submenu
        // items in IE7 so applying default ltr value. If rtl compatibility is added to the menu then the default
        // value for rtl should be 'right'.
        if($util.IsIE7)
            div.style.textAlign = 'left';
		return div;
	},

	__createRelativeDiv: function()
	{
		var innerDiv = document.createElement("DIV");
		innerDiv.style.position = "relative";
		return innerDiv;
	},

	__createSliderDiv: function(width, height, adr)
	{
		var div = document.createElement("DIV");
		div.style.width = width + "px";
		div.style.height = height + "px";
		div.style.visibility = "visible";
		//!div.style.overflow = "hidden"; !never!
		div.style.display = "none";
		div.style.left = "0px";
		div.style.top = "0px";
		div.style.position = "absolute";
		div.id = adr;
		return div;
	},

	__showSliderDivByItem: function(item)
	{
		var useAnimation = item.get_itemsGroupSettings().get_enableAnimation();

		if (useAnimation)
		{
			this.__animateItem(item);
		}
		else
		{
			if($util.IsIE7)
			{
				item.get_element().className = item.get_element().className;
			}

			this.__showSliderDiv(item._get_sliderContainer());

			if($util.IsIE7)
			{
				// L.T. Fix for 37631. IE7 does not redraw when enable animation is false.
				item.get_element().className = item.get_element().className;
				var cont = item._get_scrollContainer();
				if(cont)
					cont.className = cont.className;
			}
		}
	},

	__hideItemElement: function(item)
	{
		if (!$util.isNullOrUndefined(item))
		{
			item.__clearAnimation(false);

			if (this.get_enableScrolling())
			{
				this.__hideSliderDivByAdr(item._get_address());
			}
			else
			{
				var subgroup = item._get_subgroup();
				if (subgroup)
				{
					subgroup.style.display = 'none';
					subgroup.style.visibility = 'hidden';
				}
			}
		}
	},

	__hideSliderDivByAdr: function(adr)
	{
		this.__hideSliderDiv($get(this._id + "_" + adr));
	},

	__showSliderDiv: function(div)
	{
		if (!$util.isNullOrUndefined(div) && div.nodeName == "DIV")
		{
			div.style.display = 'block';
			div.style.visibility = 'visible';
			if($util.IsIE7)
			{
				div.firstChild.style.display = '';
				div.firstChild.style.visibility = 'visible';
			}
		}
	},

	__hideSliderDiv: function(div)
	{
		if (!$util.isNullOrUndefined(div) && div.nodeName == "DIV")
		{
			div.style.display = 'none';
            div.style.visibility = 'hidden';
			if($util.IsIE7)
			{
				div.firstChild.style.display = 'none';
				div.firstChild.style.visibility = 'hidden';
			}
		}
	},

	__animateItem: function(item)
	{
		var itemGroupSettings = item.get_itemsGroupSettings();

		if (!this.get_menuGroupSettings().get_enableAnimation() &&
           !itemGroupSettings.get_enableAnimation())
			return;

		var animationType = itemGroupSettings.get_animationType();
		var elemToAnimate = this.get_enableScrolling() ? item._get_sliderContainer() : item._get_subgroup();

		if (!elemToAnimate)
			return;

		var elemToAnimateBounds = this.__getElementBounds(elemToAnimate);

		if (this.get_enableScrolling())
		{
			elemToAnimate.style.display = '';
			elemToAnimate.style.visibility = 'visible';
			elemToAnimate = item._get_scrollContainer();

			elemToAnimateBounds = this.__getElementBounds(elemToAnimate);
		}

		this._createIframeAsListBackground(this.__iframeItemsListBackground, 
			true, 
			elemToAnimateBounds.width, 
			elemToAnimateBounds.height,
			elemToAnimate.style.marginTop,
			elemToAnimate.style.marginLeft,
			(elemToAnimate.style.zIndex - 1)
		);

		elemToAnimate.parentNode.appendChild(this.__iframeItemsListBackground);

		var animation = item._get_animation();

		if (animationType == $IG.DataMenuAnimationtype.ExpandAnimation)
		{
			if($util.isNullOrUndefined(animation))
			{
				if(this.get_enableScrolling() && $util.IsIE7 && elemToAnimate)
				{
					// hack, the right border is not shown on IE7! so increase the slider width with 2px! 1 does not work.
					var slider = elemToAnimate.parentNode;
					if(slider)
					{
						if(itemGroupSettings.get_orientation() == $IG.Orientation.Vertical)
							slider.style.width = ($util.toIntPX(null, 'width', 0, slider) + 2) + "px";
						else
							slider.style.height = ($util.toIntPX(null, 'height', 0, slider) + 2) + "px";
					}
				}
				animation = new $IG.SlideAnimation(elemToAnimate);
				animation.onEnd = function()
				{
					var menu = item._get_owner();
					menu._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
					menu._visibleItems[item._get_address()] = item;
				};
				item._set_animation(animation);
			}
			animation.play(true,
                           itemGroupSettings.get_animationEquationType(),
                           itemGroupSettings.get_animationDuration(),
                           itemGroupSettings.get_orientation() == $IG.Orientation.Vertical ? $IG.AnimationSlideDirection.Horizontal : $IG.AnimationSlideDirection.Vertical,
                           false,
                           false);
		}
		else if (animationType == $IG.DataMenuAnimationtype.OpacityAnimation)
		{
			if($util.isNullOrUndefined(animation))
			{
				animation = new $IG.OpacityAnimation(elemToAnimate, itemGroupSettings.get_animationEquationType());
				animation.set_duration(itemGroupSettings.get_animationDuration());
				animation.onEnd = function()
				{
					var menu = item._get_owner();
					menu._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
					menu._visibleItems[item._get_address()] = item;
				};
				item._set_animation(animation);
			}
			elemToAnimate.style.display = "";
			elemToAnimate.style.visibility = "visible";
			animation.play(0, 100, true);
		}
	},

	__get_scrollbarWidth: function()
	{
		if ($util.isNullOrUndefined(this.__scrollbarWidth))
		{
			var scr = null;
			var inn = null;
			var wNoScroll = 0;
			var wScroll = 0;

			// Outer scrolling div
			scr = document.createElement('div');
			scr.style.position = 'absolute';
			scr.style.top = '-1000px';
			scr.style.left = '-1000px';
			scr.style.width = '100px';
			scr.style.height = '50px';
			// Start with no scrollbar
			scr.style.overflow = 'hidden';

			// Inner content div
			inn = document.createElement('div');
			inn.style.width = '100%';
			inn.style.height = '200px';

			// Put the inner div in the scrolling div
			scr.appendChild(inn);
			// Append the scrolling div to the doc
			document.body.appendChild(scr);

			// Width of the inner div sans scrollbar
			wNoScroll = inn.offsetWidth;
			// Add the scrollbar
			scr.style.overflow = 'auto';
			// Width of the inner div width scrollbar
			wScroll = inn.offsetWidth;

			// Remove the scrolling div from the doc
			document.body.removeChild(document.body.lastChild);

			// Pixel width of the scroller
			this.__scrollbarWidth = wNoScroll - wScroll;
		}
		return this.__scrollbarWidth;
	},

	__getElementBounds: function(domElem)
	{
		///<summary>
		/// Retrieves the dom elemnts bounds by showing the element and shifting its top left to a position that is
		/// not visible on the screen. If one of element parents is not displayed get bounds will return 0 for wheight and width.
		///</summary>
		if (!$util.isNullOrUndefined(domElem))
		{
			var originalTop = domElem.style.top;
			var originalLeft = domElem.style.left;
			var originalOverflow = domElem.style.overflow;
			var display = domElem.style.display;
			var visibility = domElem.style.visibility;
			domElem.style.top = "-10000px";
			domElem.style.left = "-10000px";
			domElem.style.overflow = "visible";
			domElem.style.visibility = "visible";
			domElem.style.display = "";
			var bounds = Sys.UI.DomElement.getBounds(domElem);
			domElem.style.display = display;
			domElem.style.visibility = visibility;
			domElem.style.top = originalTop;
			domElem.style.left = originalLeft;
			domElem.style.overflow = originalOverflow;
			// correct the corrdinates because get bounds sets top & left to -10000px;
			if(domElem.style.position != "")
			{
				bounds.x = bounds.x + 10000;
				bounds.y = bounds.y + 10000;
			}
			return bounds;
		}
	},

	__getSizer: function()
	{
		if ($util.isNullOrUndefined(this.__sizer))
		{
			var div = document.createElement("DIV");
			div.style.position = "absolute";
			div.style.top = "-10000px";
			div.style.left = "-10000px";
			div.style.display = "block";
            // K.D. March 21, 2011 Bug #63211 The sizer should not wrap white spaces in order to avoid 
            // rendering issues for items containing white spaces in their text
            div.style.whiteSpace = "nowrap";
			div.style.border = "solid";
			document.body.appendChild(div);
			this.__sizer = div;
		}
		return this.__sizer;
	},

	__getElementBoundsEx: function(domElem)
	{
		///<summary>
		/// Retrieves the dom elemnts bounds by detaching the element from its current location
		/// and attaches it to a sizer div that is displayed in the document and is out of the visible screen area.
		/// We show the domElement if it is not visible and we get its bounds. Then we restore the original
		/// display/visibility state and restore the element to its inital location in the DOM tree.
		/// This way we overcome the problem that __getElementBounds have, when the element has parents
		/// that are not displayed on the page.
		///</summary>
		if (!$util.isNullOrUndefined(domElem))
		{
			// attaching an element to the body causes a body rezsize.
			// In the case of context menu, it is attached to the body
			// and we receive a fake on window resize event.
			this.__stopResize = true;
			try
			{
				var sizer = this.__getSizer();
				//B.C. January 27th, 2012 Bug #99947. We replace the target node with a temporary node which saves the real node place.
				var placeHolder = document.createElement("div");
				domElem.replaceNode(placeHolder);
				sizer.appendChild(domElem);

				var display = domElem.style.display; 
				var visibility = domElem.style.visibility;
				domElem.style.visibility = "visible";
				if (display == "none")
					domElem.style.display = "";
				var bounds = Sys.UI.DomElement.getBounds(domElem);

				//Here the real node is returned in its place.
				placeHolder.replaceNode(domElem);
				domElem.style.display = display;
				domElem.style.visibility = visibility;

			}
			finally
			{
				this.__stopResize = false;
			}

			return bounds;
		}
	},

	__onBeforeShowItem: function(item)
	{
		
		
		// this._resizeSubLevelSeparators(item, item._get_scrollContainer().offsetWidth, item.get_childItem(0, false).get_element().offsetHeight);
		
		this.__resizeListItems(item);
	},

	__renderStructure: function(item)
	{
		if ($util.isNullOrUndefined(item))
			return;

		var itemAddress = item._get_address();
		var slider = $get(this._id + "_" + itemAddress);

		if ($util.isNullOrUndefined(slider) && item.hasChildren())
		{
			// if the structure is not created yet, create it.
			var itemLevel = item.get_level();
			var ul = item._get_scrollContainer();
			slider = this.__createSliderDiv($util.toIntPX(null, 'width', 0, ul),
                                            $util.toIntPX(null, 'height', 0, ul),
                                            this._id + "_" + itemAddress);

			if (itemLevel == 0)
			{
				var div = this.__createTopLevelDivStructure();
				var innerDiv = this.__createRelativeDiv();
				innerDiv.appendChild(slider);
				div.appendChild(innerDiv);
				this.get_element().appendChild(div);
			}
			else
			{
				var parentSlider = $get(this._id + "_" + $adrutil.getParentAddress(itemAddress));
				parentSlider.appendChild(slider);
			}
			this.__attachItemChildrenToSlider(item, slider);
		}

		if (this.__needsResize(slider.resizeId))
		{
			this.__positionSliderDiv(item, slider);
			slider.resizeId = this.__resizedId;
		}
	},

	__positionSliderDiv: function(item, slider)
	{
		if ($util.isNullOrUndefined(item) ||
           $util.isNullOrUndefined(slider) ||
           slider.nodeName != "DIV")
			return;

		var itemGroupSettings = item.get_itemsGroupSettings();
		var menuGroupSettings = this.get_menuGroupSettings();
		var menuExpandDirection = menuGroupSettings.get_expandDirection();

		var parent;
		var expandDirection = 0;
		var tmpItem = item;

		while (tmpItem !== null) {
			if(tmpItem.get_itemsGroupSettings().get_expandDirection() === 0)
			{
				parent = tmpItem.get_parentItem();
				if(!parent) {
					expandDirection = menuExpandDirection;
					break;
				} 
				else if (parent.get_itemsGroupSettings().get_expandDirection() !== 0 ) {
					expandDirection = parent.get_itemsGroupSettings().get_expandDirection();
					break;
				}
				tmpItem=parent;
			}
			else 
			{
				expandDirection = tmpItem.get_itemsGroupSettings().get_expandDirection();
				break;
			}
		}

		var orientation = item.get_orientation();
		var itemsBounds = Sys.UI.DomElement.getBounds(item.get_element());
		var itemUl = item._get_subgroup();
		var ulBounds = new Object();
		ulBounds.width = $util.toIntPX(null, 'width', 0, itemUl);
		ulBounds.height = $util.toIntPX(null, 'height', 0, itemUl);

		slider.style.top = "0px";
		slider.style.left = "0px";
		var sliderBounds = this.__getElementBounds(slider);

		var pageDims = this.__getPageDimensions();
		var needsSwitch = false;
		var switchCount = 0;
		var top = 0, left = 0;

		do
		{
			needsSwitch = false;

			if (orientation == $IG.Orientation.Horizontal)
			{
				// align the sub menu to the item left edge, else align it to the item right edge,
				// depending on which distance is bigger (from item left edge to right page end or from left page start to item right edge)
				var alignToItemLeft = ((pageDims.MaxX - itemsBounds.x > itemsBounds.x + itemsBounds.width) || (pageDims.MaxX - itemsBounds.x > sliderBounds.width)) || itemGroupSettings.get_orientation() == $IG.Orientation.Vertical;

				left += itemGroupSettings.get_offsetX();

				switch (expandDirection)
				{
					case $IG.MenuExpandDirection.Auto:
					case $IG.MenuExpandDirection.Down:
						{
							var x = (alignToItemLeft ? itemsBounds.x - sliderBounds.x : itemsBounds.x - sliderBounds.x + itemsBounds.width - (ulBounds.width < sliderBounds.width ? ulBounds.width : sliderBounds.width));
							var y = itemsBounds.y + itemsBounds.height - sliderBounds.y;

							top += y + itemGroupSettings.get_offsetY();
							left += x;
							break;
						}

					case $IG.MenuExpandDirection.Up:
						{
							var x = (alignToItemLeft ? itemsBounds.x - sliderBounds.x : itemsBounds.x - sliderBounds.x + itemsBounds.width - (ulBounds.width < sliderBounds.width ? ulBounds.width : sliderBounds.width));
							//B.C. 3, January 2012. Bug #98650.
							//Because the slider's parent is set with "position=relative", its "y=0" position is just bellow the root menu. 
							//And because we need to position the slider above the menu, we substract from 0 the items height + slider height.
							var y = 0 - (itemsBounds.height + sliderBounds.height);

							top += y - itemGroupSettings.get_offsetY();
							left += x;
							break;
						}
				}

				if ((sliderBounds.y + top + sliderBounds.height > pageDims.MaxY ||
				   sliderBounds.y + top < 0) && itemGroupSettings.get_orientation() == $IG.Orientation.Horizontal)
				{
					needsSwitch = true;
					switchCount++;
					top = 0;
					left = 0;
					expandDirection = ((expandDirection == $IG.MenuExpandDirection.Down ||
					                    expandDirection == $IG.MenuExpandDirection.Auto) ? $IG.MenuExpandDirection.Up : $IG.MenuExpandDirection.Down);
				}
			}
			else if (orientation == $IG.Orientation.Vertical)
			{
				// align the sub menu to the item top edge, else align it to the item bottom edge,
				// depending on which distance is bigger (from item top edge to page end or from page start to item bottom)
				var alignToItemTop = ((pageDims.MaxY - itemsBounds.y > itemsBounds.y + itemsBounds.height) || (pageDims.MaxY - itemsBounds.y > sliderBounds.height)) || itemGroupSettings.get_orientation() == $IG.Orientation.Horizontal;

				top += itemGroupSettings.get_offsetY();

				switch (expandDirection)
				{
					case $IG.MenuExpandDirection.Left:
						{
							var x = itemsBounds.x - sliderBounds.x - sliderBounds.width;
							var y = (alignToItemTop ? itemsBounds.y - sliderBounds.y : itemsBounds.y + itemsBounds.height - sliderBounds.y - (ulBounds.height < sliderBounds.height ? ulBounds.height : sliderBounds.height));

							left += x - itemGroupSettings.get_offsetX();
							top += y;
							break;
						}

					case $IG.MenuExpandDirection.Auto:
					case $IG.MenuExpandDirection.Right:
						{
							var x = itemsBounds.x - sliderBounds.x + itemsBounds.width;
							var y = (alignToItemTop ? itemsBounds.y - sliderBounds.y : itemsBounds.y + itemsBounds.height - sliderBounds.y - (ulBounds.height < sliderBounds.height ? ulBounds.height : sliderBounds.height));

							left += x + itemGroupSettings.get_offsetX();
							top += y;
							break;
						}
				}

				if ((sliderBounds.x + left + sliderBounds.width > pageDims.MaxX ||
				   sliderBounds.x + left < 0) && itemGroupSettings.get_orientation() == $IG.Orientation.Vertical)
				{
					needsSwitch = true;
					switchCount++;
					top = 0;
					left = 0;
					expandDirection = ((expandDirection == $IG.MenuExpandDirection.Right ||
					                    expandDirection == $IG.MenuExpandDirection.Auto) ? $IG.MenuExpandDirection.Left : $IG.MenuExpandDirection.Right);
				}
			}
		} while (needsSwitch && switchCount < 2);

		slider.style.top = top + "px";
		slider.style.left = left + "px";

		this.__fitSliderInPage(slider, sliderBounds, top, left, item);
	},

	__fitSliderInPage: function(slider, sliderBounds, top, left, item)
	{
		if ($util.isNullOrUndefined(slider) ||
           $util.isNullOrUndefined(sliderBounds) ||
           $util.isNullOrUndefined(item) ||
		   !this.get_enableScrolling())
			return;
		



		var pageDims = this.__getPageDimensions();
		var itemGroupSettings = item.get_itemsGroupSettings();
		var scrollContainer = item._get_scrollContainer();
		var scrollContainerBounds = this.__getElementBoundsEx(scrollContainer);
		var orientation = itemGroupSettings.get_orientation();
		var minSize = 0; // min size, we can not decrease below.

		if ((sliderBounds.x + left + scrollContainerBounds.width > pageDims.MaxX &&
            orientation == $IG.Orientation.Horizontal) ||
           (sliderBounds.y + top + scrollContainerBounds.height > pageDims.MaxY &&
            orientation == $IG.Orientation.Vertical))
		{
			// When Width/Height is not applied, we should set this.
			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			if (orientation == $IG.Orientation.Vertical)
			{
				// decrease the height with the piece that goes beyond the page max Y value.
				var decreasedHeight = scrollContainerBounds.height - ((sliderBounds.y + top + scrollContainerBounds.height) - pageDims.MaxY);
				if (decreasedHeight > minSize)
				{
					scrollContainer.style.height = decreasedHeight + "px";
					slider.style.height = decreasedHeight + "px";
				}
			}
			else if (orientation == $IG.Orientation.Horizontal)
			{
				// decrease the width with the piece that goes beyond the page max X value.
				var decreasedWidth = scrollContainerBounds.width - ((sliderBounds.x + left + scrollContainerBounds.width) - pageDims.MaxX);
				if (decreasedWidth > minSize)
				{
					scrollContainer.style.width = decreasedWidth + "px"; // scroll container must be 3px smaller than the slider as created in __renderStructure.
					slider.style.width = decreasedWidth + "px";
				}
			}

			if (this.get_enableScrolling())
				item._displayScrollButton(1, true);
		}

		if ((sliderBounds.x + left < 0 && orientation == $IG.Orientation.Horizontal) ||
		   (sliderBounds.y + top < 0 && orientation == $IG.Orientation.Vertical))
		{
			// When Width/Height is not applied, we should set this.
			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			if (orientation == $IG.Orientation.Vertical)
			{
				// decrease the height with the piece that goes beyond the page max Y value.
				var decreasedHeight = scrollContainerBounds.height + sliderBounds.y + top;
				if (decreasedHeight > minSize)
				{
					scrollContainer.style.height = decreasedHeight + "px";
					slider.style.height = decreasedHeight + "px";
					slider.style.top = top + ((sliderBounds.y + top) * -1) + "px";
				}
			}
			else if (orientation == $IG.Orientation.Horizontal)
			{
				// decrease the width with the piece that goes beyond the page max X value.
				var decreasedWidth = scrollContainerBounds.width + sliderBounds.x + left;
				if (decreasedWidth > minSize)
				{
					scrollContainer.style.width = decreasedWidth + "px";
					slider.style.width = decreasedWidth + "px";
					slider.style.left = left + ((sliderBounds.x + left) * -1) + "px";
				}
			}

			if (this.get_enableScrolling())
				item._displayScrollButton(1, true);
		}
	},

	__needsResize: function(resizeId)
	{
		return this.__resizedId != resizeId;
	},

	_onWindowResizeHandler: function(event)
	{
		if(this.__stopResize || !this.get_element() || this.get_element().offsetHeight == 0) // return, when menu element is not visible!
			return;

		var pageSize = this.__pageSize;
		this.__getPageDimensions(true); // repopulate this.__pageSize;
		var newPageSize = this.__pageSize;

		var isResized = (!pageSize || (pageSize.MaxX != newPageSize.MaxX || pageSize.MaxY != newPageSize.MaxY));
		if (isResized)
		{
			this.__resizedId++;
			this.__resizeScrollArea(this.__getElementBoundsEx(this._get_subgroup()), this._get_scrollContainer(), this._menuGroupSettings);
		}
	},

	_onDocumentMouseOverHandler: function(e)
	{
		this.__x = e.clientX;
		this.__y = e.clientY;
		
		var activeElem = document.activeElement || e.target;
		if (activeElem && !this.__controlActive && activeElem.nodeName != "BODY" && activeElem.nodeName != "HTML")
		{
			this.__lastFocusedElement = activeElem;

			if (this.__lastFocusedElement && this.__lastFocusedElement.nodeName == "INPUT")
			{
				this.__lastFocusedInputCaretPosition = this.__lastFocusedElement.value.length;
			}
		}
	},

	_onDocumentClickHandler: function()
	{
		this.__clickedOutside = true; // true when you clicked in the document, will not fire if you click on scrollbars for IE specific.
		var elemAtPoint = document.elementFromPoint(this.__x, this.__y);
		var control = this.get_element();
		if (control && !control.contains(elemAtPoint))
			this._onBlurHandler();
	},

	__attachItemChildrenToSlider: function(item, sliderContainer)
	{
		if ($util.isNullOrUndefined(item) ||
           $util.isNullOrUndefined(sliderContainer) ||
           sliderContainer.nodeName != "DIV")
			return;

		var scrollDiv = item._get_scrollContainer();
		var realParent = scrollDiv.parentNode;

		sliderContainer.appendChild(scrollDiv);

		item._set_scrollContainer(scrollDiv);
		item._set_sliderContainer(sliderContainer);

		scrollDiv.realParent = realParent;

		scrollDiv.style.display = "";
		scrollDiv.style.visibility = "visible";
	},

	__showItem: function(item)
	{
		if ($util.isNullOrUndefined(item) || item.get_expanded())
			return false;

		if (item.get_level() > 0)
		{
			var parentItem = item.get_parentItem();
			if (!parentItem.get_expanded())
				this.__showItem(parentItem);
		}

		if (!item.hasChildren())
			return false;

		if (!this.get_enableScrolling())
		{
			
			return this.__showItemOld(item);
		}

		this.__onBeforeShowItem(item);

		this.__renderStructure(item);

		args = this._raiseClientEvent('ItemExpanding', 'DataMenuItemCancel', null, null, item);
		if (args && args.get_cancel())
			return false;

		item.set_expanded(true);
		var itemGroupSettings = item.get_itemsGroupSettings();
		var useAnimation = itemGroupSettings.get_enableAnimation();

		this.__showSliderDivByItem(item);

		this._visibleItems[item._get_address()] = item;

		if (!useAnimation)
		{			
			this._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
		}

		return true;
	},

	__attachMouseWheelEvent: function()
	{
		if ($util.IsFireFox)
			$addHandler(this.get_element(), "DOMMouseScroll", Function.createDelegate(this, this._onMouseWheel));
		else
			$addHandler(this.get_element(), "mousewheel", Function.createDelegate(this, this._onMouseWheel));
	},

	_onMouseWheel: function(event)
	{
		var delta = 0;
		if (event.rawEvent.wheelDelta)
		{
			
			delta = event.rawEvent.wheelDelta / 120;
			

			
			

		}
		else if (event.rawEvent.detail)
		{ 
			


			delta = -event.rawEvent.detail / 3;
		}
		



		if (delta)
			this._onRealMouseWheel(delta, event);
		



		if (event.preventDefault)
			event.preventDefault();
		event.returnValue = false;
	},

	__getNearestScrollingDiv: function(domElement)
	{
		while (domElement)
		{
			var id = domElement.getAttribute && domElement.getAttribute("id");
			if (domElement.nodeName == "DIV" && id && id.indexOf("mkr:sd") != -1)
			{
				return domElement;
			}
			else
			{
				domElement = domElement.parentNode;
			}
		}

		return null;
	},

	__isVerticalScroll: function(scrollButton)
	{
		if (scrollButton && scrollButton.nodeName == "A")
		{
			var css = $util.getCssClass(scrollButton);
			return (!$util.isNullOrUndefined(css) &&
                    css != "" &&
                    (css.indexOf("MenuScrollerTop") != -1 ||
                     css.indexOf("MenuScrollerBottom") != -1));
		}
	},

	__getScrollSpeedDimensions: function(numberOfItems)
	{
		var triplet;
		var speed = this.get_scrollingSpeed();
		if (speed == $IG.DataMenuScrollingSpeed.VerySlow)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.VerySlow);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Slow)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Slow);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Normal)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Normal);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Fast)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Fast);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.VeryFast)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.VeryFast);
		}

		triplet.itemsFactor = this.__getScrollSpeedFactor(numberOfItems);

		return triplet;
	},

	__getScrollSpeedValues: function(speedType)
	{
		var triplet = new Object();
		triplet.pixelsToScroll = speedType[0];
		triplet.perTime = speedType[1];
		triplet.itemsFactor = 1;
		return triplet;
	},

	__getScrollSpeedFactor: function(numberOfItems)
	{
		if (!$util.isNullOrUndefined(numberOfItems) && typeof (numberOfItems) == "number")
		{
			var factor = $IG.DataMenuScrollingItemsFactor.Slow;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];

			factor = $IG.DataMenuScrollingItemsFactor.Normal;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];

			factor = $IG.DataMenuScrollingItemsFactor.Fast;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];
		}
		return 1;
	},

	_onRealMouseWheel: function(delta, browserEvent)
	{
		var target = this._getTarget(browserEvent);
		var div = this.__getNearestScrollingDiv(target);

		if (!div)
			return;

		var ul = $adrutil.getImmediateElementsByTagName(div, "UL")[0];
		var scrollUp = delta > 0;
		var firstScrollButton = $adrutil.getImmediateElementsByTagName(div, "A")[0];
		var secondScrollButton = $adrutil.getImmediateElementsByTagName(div, "A")[1];

		if ((!this._getScrollButtonVisible(firstScrollButton) && scrollUp) ||
           (!this._getScrollButtonVisible(secondScrollButton) && !scrollUp))
			return; 


		this.__resizedId++; // when scrolling is done, we should advance the resizeId, because submenus that are already positioned with top/left needs to be recalculated.

		this.__doScroll(0, ul, scrollUp,
                        firstScrollButton,
                        secondScrollButton,
                        this.__isVerticalScroll(firstScrollButton), Math.abs(delta));

		// hide the menus that are expanded and are with level deeper than the scroll container.
		this.__hideUpLevelItems(this._itemCollection._getUIBehaviorsObj().getItemFromElem($adrutil.getImmediateElementsByTagName(ul, "LI")[0]));
	},

	_getTarget: function(browserEvent)
	{
		var target = browserEvent.target;
		if (!target)
			target = browserEvent.srcElement;
		return target;
	},

	_onMouseOverHandler: function(browserEvent)
	{
		var target = this._getTarget(browserEvent);

		if (target && target.nodeName == "SPAN")
		{
			target = target.parentNode;
		}

		if (this._isScrollButtonTarget(browserEvent))
		{
			if (!this._isScrolling)
			{
				clearTimeout(this._timeoutID); // clear the hideAll timeout!				

				this._isScrolling = true;

				this.__resizedId++; // when scrolling is done, we should advance the resizeId, because submenus that are already positioned with top/left needs to be recalculated.

				var ul = $adrutil.getImmediateElementsByTagName(target.parentNode, "UL")[0];
				var css = $util.getCssClass(target);
				if (css && css.indexOf("MenuScrollerTop") != -1)
				{
					this.__doScroll(0, ul, true, target, $adrutil.getImmediateElementsByTagName(ul.parentNode, "A")[1], true);
				}
				else if (css && css.indexOf("MenuScrollerBottom") != -1)
				{
					this.__doScroll(0, ul, false, $adrutil.getImmediateElementsByTagName(ul.parentNode, "A")[0], target, true);
				}
				else if (css && css.indexOf("MenuScrollerLeft") != -1)
				{
					this.__doScroll(0, ul, true, target, $adrutil.getImmediateElementsByTagName(ul.parentNode, "A")[1], false);
				}
				else if (css && css.indexOf("MenuScrollerRight") != -1)
				{
					this.__doScroll(0, ul, false, $adrutil.getImmediateElementsByTagName(ul.parentNode, "A")[0], target, false);
				}

				// hide the menus that are expanded and are with level deeper than the scroll container.
				this.__hideUpLevelItems(this._itemCollection._getUIBehaviorsObj().getItemFromElem($adrutil.getImmediateElementsByTagName(ul, "LI")[0]));
			}
			return; // prevent from stop scrolling
		}

		this.__stopScroll();
	},

	_isScrollButtonTarget: function(e)
	{
		var target = this._getTarget(e);

		if (target.nodeName == "SPAN")
			target = target.parentNode;

		return target && target.nodeName == "A" && target.id && target.id.indexOf("mkr:sb") != -1;
	},

	_onMouseOutHandler: function(e)
	{
		if (this.get_enableScrolling())
		{
			var target = this._getTarget(e);
			var relTarget = e.rawEvent.relatedTarget || e.rawEvent.toElement;
			var isScrollButtonTarget = this._isScrollButtonTarget(e);
			if (isScrollButtonTarget &&
			   ((target.nodeName == "A" && (relTarget ? relTarget.parentNode != target : true)) ||
				(target.nodeName == "SPAN" && target.parentNode != relTarget)))
			{
				this.__stopScroll();
			}
		}

		if ($util.isOut(e, this.get_element()) && this.__activateOnHover)
		{
			// close the menu on mouse out from the whole menu, when enable expand on hover is true.
			if (!this.get_isContextMenu())
			{
				this._timeoutID = setTimeout(Function.createDelegate(this, this.__hideAll), this.__subMenuClosingDelay);
				this.__returnFocusIfNeeded();
			}
		}

		this.__iframeItemsListBackground.style.display = "none";
	},

	__returnFocusIfNeeded: function()
	{
		if (this.__activateOnHover)
		{
			this.__cancelBlur = false;

			if (this.__controlClicked)
			{
				try
				{
					document.body.focus();
				} catch (e) { }
				this.__controlClicked = false;
			}
			else if (this.__lastFocusedElement)
			{
				try
				{
					var lfe = this.__lastFocusedElement;
					var lfecp = this.__lastFocusedInputCaretPosition;
					setTimeout(Function.createDelegate(this, this.__lastFocusedElementFocus), 5);
					if (lfe.nodeName == "INPUT");
						this.__setCaretTo(lfe, lfecp);
				} catch (ex) { }
			}
		}
	},

    __lastFocusedElementFocus: function()
    {
        var lfe = this.__lastFocusedElement;
        if (lfe)
        {
            try {
                
                lfe.focus();

            } catch (e)
            {

            }
        }
    },

	__doScroll: function(fakeOnFF, scrollElement, scrollUp, upButton, downButton, isVertical, delta)
	{
		var continueScrolling = false;

		var scrollElemParent = scrollElement.parentNode;
		var scrollSpeedVaribales = this.__getScrollSpeedDimensions(scrollElemParent.realParent ? this._itemCollection._getUIBehaviorsObj().getItemFromElem(scrollElemParent.realParent).getItems().get_length() : this.getItems().get_length());

		if (isVertical)
			continueScrolling = this.__scrollVerticalItems(scrollElement, scrollUp, scrollSpeedVaribales, upButton, downButton);
		else
			continueScrolling = this.__scrollHorizontalItems(scrollElement, scrollUp, scrollSpeedVaribales, upButton, downButton);

		if (!$util.isNullOrUndefined(delta) && typeof (delta) == "number")
		{
			// delta is defined only when we scroll with the mouse wheel.
			// We will call this handler exactly delta times, this way we will have the so called scroll wheel effect.
			if (delta <= 0)
			{
				this.__stopScroll();
				continueScrolling = false;
			}
			delta--;
		}

		if (continueScrolling)
		{
			this.__scrollingTimeoutID = setTimeout($util.createDelegate(this, this.__doScroll, [0, scrollElement, scrollUp, upButton, downButton, isVertical, delta]), (this.__accelerateScrolling ? Math.ceil(scrollSpeedVaribales.perTime / 3) : scrollSpeedVaribales.perTime));
		}

        //A.T. Fix for bug #37646 - Scrolling inside context menu not working well
        // hack to fix a well-known bug in IE - we need to force the browser to reflow, so that scrolling is smooth and updated on time 
        if ($util.IsIE)
        {
            if (scrollElemParent.realParent)
            {
                scrollElemParent.realParent.className = scrollElemParent.realParent.className;
            }

            if (scrollElemParent)
            {
                scrollElemParent.className = scrollElemParent.className;
            }

			if(this.get_isContextMenu())
				this.get_element().className = this.get_element().className;
        }
	},

	__stopScroll: function()
	{
		if (this._isScrolling)
		{
			clearTimeout(this.__scrollingTimeoutID);
			this.__accelerateScrolling = false;
			this._isScrolling = false;
			this.__scrollingTimeoutID = null;
		}
        
        else if (this.__scrollingTimeoutID != null)
        {
			clearTimeout(this.__scrollingTimeoutID);
			this.__scrollingTimeoutID = null;
        }
	},

	__scrollVerticalItems: function(scrollElement, scrollUp, speed, upButton, downButton)
	{
		var continueScrolling = false;
		if (!$util.isNullOrUndefined(scrollElement) &&
           !$util.isNullOrUndefined(upButton) &&
           !$util.isNullOrUndefined(downButton))
		{
			continueScrolling = true;

			var currentTop = $util.toIntPX(null, 'top', 0, scrollElement);
			var pixelsToScroll = (this.__accelerateScrolling ? speed.pixelsToScroll * speed.itemsFactor * 2 : speed.pixelsToScroll * speed.itemsFactor);
			var newTop = scrollUp ? currentTop + (pixelsToScroll) : currentTop - (pixelsToScroll);
			scrollElement.style.top = newTop + "px";

			if (currentTop == 0 && newTop < 0 && upButton.style.display == "none")
			{
				// show the top button
				upButton.style.display = "";
			}
			else if (newTop >= 0 && currentTop != 0 && upButton.style.display != "none")
			{
				// hide the top button
				this.__stopScroll();
				continueScrolling = false;
				upButton.style.display = "none";
				scrollElement.style.top = "0px";
			}

			var downButtonDisplay = downButton.style.display;
			var ulHeight = Sys.UI.DomElement.getBounds(scrollElement).height;
			var scrollContainerHeight = Sys.UI.DomElement.getBounds(scrollElement.parentNode).height;
			if (scrollContainerHeight - newTop >= ulHeight &&
               downButtonDisplay != "none")
			{
				// hide the bottom button
				this.__stopScroll();
				continueScrolling = false;
				scrollElement.style.top = ((ulHeight - scrollContainerHeight) * -1) + "px";
				downButton.style.display = "none";
			}
			else if (downButtonDisplay == "none")
			{
				// show the bottom button
				downButton.style.display = "";
			}
		}
		return continueScrolling;
	},

	__scrollHorizontalItems: function(scrollElement, scrollLeft, speed, leftButton, rightButton)
	{
		var continueScrolling = false;
		if (!$util.isNullOrUndefined(scrollElement) &&
           !$util.isNullOrUndefined(leftButton) &&
           !$util.isNullOrUndefined(rightButton))
		{
			continueScrolling = true;

			var currentLeft = $util.toIntPX(null, 'left', 0, scrollElement);
			var pixelsToScroll = (this.__accelerateScrolling ? speed.pixelsToScroll * speed.itemsFactor * 2 : speed.pixelsToScroll * speed.itemsFactor);
			var newLeft = scrollLeft ? currentLeft + (pixelsToScroll) : currentLeft - (pixelsToScroll);
			scrollElement.style.left = newLeft + "px";

			if (currentLeft == 0 && newLeft < 0 && leftButton.style.display == "none")
			{
				// show the left button
				leftButton.style.display = "";
			}
			else if (newLeft >= 0 && currentLeft != 0 && leftButton.style.display != "none")
			{
				// hide the left button
				this.__stopScroll();
				continueScrolling = false;
				leftButton.style.display = "none";
				scrollElement.style.left = "0px";
			}

			var rightButtonDisplay = rightButton.style.display;
			var ulWidth = Sys.UI.DomElement.getBounds(scrollElement).width;
			var scrollContainerWidth = Sys.UI.DomElement.getBounds(scrollElement.parentNode).width;
			if (scrollContainerWidth - newLeft >= ulWidth &&
               rightButtonDisplay != "none")
			{
				// hide the right button
				this.__stopScroll();
				continueScrolling = false;
				scrollElement.style.left = ((ulWidth - scrollContainerWidth) * -1) + "px";
				rightButton.style.display = "none";
			}
			else if (rightButtonDisplay == "none")
			{
				// show the right button
				rightButton.style.display = "";
			}
		}
		return continueScrolling;
	},

	_get_scrollContainer: function()
	{
		
		return $adrutil.getImmediateElementsByTagName(this.get_element(), "DIV")[0];
	},

	_get_subgroup: function()
	{
		var element = this.get_enableScrolling() ? this._get_scrollContainer() : this.get_element();
		return $adrutil.getImmediateElementsByTagName(element, "UL")[0];
	},

	_displayScrollButton: function(scroller, buttonIndex, show)
	{
		if (!scroller)
			return;
		if (buttonIndex != 0 &&
           buttonIndex != 1)
			return;

		var button = $adrutil.getImmediateElementsByTagName(scroller, "A")[buttonIndex];
		if (show)
		{
			button.style.display = "";
		}
		else
		{
			button.style.display = "none";
		}
	},

	_getScrollButtonVisible: function(button)
	{
		if (button && button.nodeName == "A")
		{
			return button.style.display != "none";
		}
	},

	__setCaretTo: function(obj, pos)
	{
		if (!obj || obj.nodeName != "INPUT")
			return;

		if (obj.createTextRange)
		{
			var range = obj.createTextRange();
			range.move('character', pos);
			range.select();
		}
		else if (obj.selectionStart)
		{
			obj.setSelectionRange(pos, pos);
		}
	},
	/////////////////////////////////////////////////// END SCROLLING FEATURE ////////////////////////////////////

	/////////////////////////////////////////////OBSOLETE CODE////////////////////////////////////////////////////
	

	__showItemOld: function(item)
	{
		
		var sg = item._get_subgroup();

		if ($util.isNullOrUndefined(sg) || sg.style.display != 'none')
			return false;

		if (!$util.isNullOrUndefined(item))
		{
			
			args = this._raiseClientEvent('ItemExpanding', 'DataMenuItemCancel', null, null, item);
			if (args && args.get_cancel())
				return false;
		}
		
		var pageDims = this.__getPageDimensions();
		var itemElement = item.get_element();
		var itemGroupSettings = item.get_itemsGroupSettings();
		var orientation = itemGroupSettings.get_orientation();
		var bounds = Sys.UI.DomElement.getBounds(itemElement);

		sg.style.position = 'absolute';
		sg.style.display = 'block';
		sg.style.visibility = 'hidden';
		sg.style.zIndex = "10000";

		if (sg.style.width == "" && orientation == $IG.Orientation.Horizontal)
		{
			var sgBounds = $util.IsIE7 ? this.__getElementBoundsEx(sg) : this.__getElementBounds(sg);
			sg.style.width = sgBounds.width + 'px';
			delete sgBounds;
		}
		//this._resizeSeparators(item, sg.offsetWidth, item.get_childItem(0, false)._element.offsetHeight);
		
		this.__resizeListItems(item);
		
		sg.style.marginTop = "0px";
		sg.style.marginLeft = "0px";
		var x = 0, y = 0;
		if (item.get_orientation() == $IG.Orientation.Vertical || (item.get_level() == 0 && this.get_orientation() == $IG.Orientation.Vertical))
		{
			x += bounds.width;
		}
		else
		{
			y += bounds.height;
		}

		var p0 = $util.getLocation(itemElement);
		var p1 = $util.getLocation(sg);
		x += p0.x - p1.x;
		y += p0.y - p1.y;

		if (!$util.IsIE && item.get_level() > 0)
		{
			scrolls = item.calcScrolls();
			x += scrolls.Left;
			y += scrolls.Top;
		}

		
		x += item.get_itemsGroupSettings().get_offsetX();
		y += item.get_itemsGroupSettings().get_offsetY();

		sg.style.marginTop = y + 'px';
		sg.style.marginLeft = x + 'px';

		var expandDirection = itemGroupSettings.get_expandDirection();
		var sgBounds = Sys.UI.DomElement.getBounds(sg);
		var itemsBounds = Sys.UI.DomElement.getBounds(itemElement);

		var itemGroupSettings = item.get_itemsGroupSettings();
		var menuGroupSettings = this.get_menuGroupSettings();
		var menuExpandDirection = menuGroupSettings.get_expandDirection();

		var parent;
		var expandDirection = 0;
		var tmpItem = item;

		while (tmpItem !== null) {
			if(tmpItem.get_itemsGroupSettings().get_expandDirection() === 0)
			{
				parent = tmpItem.get_parentItem();
				if(!parent) {
					expandDirection = menuExpandDirection;
					break;
				} 
				else if (parent.get_itemsGroupSettings().get_expandDirection() !== 0 ) {
					expandDirection = parent.get_itemsGroupSettings().get_expandDirection();
					break;
				}
				tmpItem=parent;
			}
			else 
			{
				expandDirection = tmpItem.get_itemsGroupSettings().get_expandDirection();
				break;
			}
		}


		if (item.get_orientation() == $IG.Orientation.Horizontal)
		{
			
			switch (expandDirection)
			{
				case $IG.MenuExpandDirection.Auto:
				case $IG.MenuExpandDirection.Down:
					
					break;
				case $IG.MenuExpandDirection.Up:
					substractY = itemsBounds.height + sgBounds.height;
					y -= substractY;
					break;
			}
		}
		else if (item.get_orientation() == $IG.Orientation.Vertical)
		{
			
			switch (expandDirection)
			{
				case $IG.MenuExpandDirection.Left:
					substractX = itemsBounds.width + sgBounds.width;
					x -= substractX;
					break;
				case $IG.MenuExpandDirection.Auto:
				case $IG.MenuExpandDirection.Right:
					
					break;
			}
		}

		sg.style.marginTop = y + 'px';
		sg.style.marginLeft = x + 'px';

		delete sgBounds;
		delete itemsBounds;
		delete expandDirection;
		delete pageDims;
		delete p0;
		delete p1;

		item.set_expanded(true);

		this._visibleItems[item._get_address()] = item;
		if (itemGroupSettings.get_enableAnimation())
		{
			this.__animateItem(item);
		}
		else
		{
			sg.style.visibility = 'visible';

			var elemToAnimateBounds = this.__getElementBounds(sg);
			this._createIframeAsListBackground(this.__iframeItemsListBackground, 
				true, 
				elemToAnimateBounds.width, 
				elemToAnimateBounds.height,
				y,
				x,
				(sg.style.zIndex - 1)
			);

			sg.parentNode.appendChild(this.__iframeItemsListBackground);

			this._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
		}
		return true;
	},

	_createIframeAsListBackground: function (iframe, isVisible, width, height, marginTop, marginLeft, zIndex)
	{
		var iframe = iframe || document.createElement("iframe"),
			width = width || 0,
			height = height || 0,
			marginLeft = marginLeft || 0,
			marginTop = marginTop || 0,
			isVisible = isVisible || false,
			zIndex = zIndex || 0;


		iframe.setAttribute("scrolling", "no");
		iframe.setAttribute("frameBorder", "0");

		iframe.style.display = "none";
		iframe.style.visibility = "hidden";
		
		if(isVisible)
		{
			iframe.style.display = "block";
			iframe.style.visibility = "visible";
		}

		iframe.style.position = "absolute";
		iframe.style.marginLeft = marginLeft;
		iframe.style.marginTop = marginTop;
		iframe.style.width = width + "px";
		iframe.style.height = height + "px";
		iframe.style.backgroundColor = "#FFFFFF";
		iframe.style.border = "0";
		iframe.style.zIndex = zIndex;
		return iframe;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

$IG.WebDataMenu.registerClass('Infragistics.Web.UI.WebDataMenu', $IG.NavControl);

$IG.WebDataMenu.find = function (clientID)
{
	///<summary>Finds WebDataMenu by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDataMenu">Reference to the WebDataMenu control object that corresponds to specified client ID.</returns>
};

$IG.WebDataMenu.from = function (obj)
{
	///<summary>Casts passed in object to the WebDataMenu type.</summary>
	///<param name="obj">Object to convert to the WebDataMenu type.</param>
	///<returns type="Infragistics.Web.UI.WebDataMenu">Reference to the same object that is passed in, only type converted to the WebDataMenu type.</returns>
};


$IG.DataMenuItemCollection = function(control, clientStateManager, index, manager)
{
    ///<summary locid="T:J#Infragistics.Web.UI.DataMenuItemCollection">
    /// Used internally to construct the DataMenuItemCollection of the WebDataMenu
    ///</summary>
    $IG.DataMenuItemCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.DataMenuItemCollection.prototype = 
{
    _createNewCollection:function(parent)
    {
        var nodes = new $IG.DataMenuItemCollection(this._control, this._csm, this._index, this._manager);
        nodes._ownerNode = parent ? parent : this;
        return nodes;
    },

    _createObject: function(adr, element)
	{
		var item = this._addObject($IG.DataMenuItem, element, adr);
        item._set_itemsGroupSettings(this._control._groupSettingsCollection.getGroupSettingsObjectByAdr(adr));
        return item;
	},

    getItem:function(index)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.getItem">
        /// Get the item at the specified index in the collection.
        ///</summary>
        ///<param name="index" type="int">Specify index of an item.</param>
        ///<returns type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true">The menu item at the specified index. Null if index is out of range.</returns>
        var item = null;
        if(index >= 0)
        {
            item = this._getObjectByIndex(index);
		    if($util.isNullOrUndefined(item))
		    {
                if ($util.isNullOrUndefined(this._owner))
                    return null;

	            var adr;
	            if(this._owner._get_address)
		            adr = this._owner._get_address() + "." + index;
	            else
		            adr = index.toString();

	            item = this._getObjectByAdr(adr);
		    }
        }
        return item;
    },

    _getObjectByAdr: function(adr)
	{
		var item = $IG.DataMenuItemCollection.callBaseMethod(this, '_getObjectByAdr', [adr]);
		if(item)
        {
			return item;
        }
		// Lazy loading of items
		var elem = this._findDomElementByAdr(adr);
        return this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(elem);
	},

	_addObject:function(navItemType, element, adr)
	{
		var object = null;		
		var indexes = adr.split('.');
		if(indexes.length == 1)
		{
			var val = parseInt(adr);
			if(val.toString() != "NaN")
				object = this._items[val] = new navItemType(adr, element,  null, this._control, this._csm, this._createNewCollection(), null);
		}
		else
		{
			var scrollDiv = element.parentNode.parentNode; // get through the UL to the scroll div.
			// if the element has been moved it will have realParent, if not we will use the parentNode.
			var parentElem = (this._control.get_enableScrolling() ? (scrollDiv.realParent ? scrollDiv.realParent : scrollDiv.parentNode) : scrollDiv);			
			var parent = this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(parentElem);
			if(parent != null)
			{
				var parentCollection = parent.getItems();
				object = new navItemType(adr, element, null, this._control, this._csm, this._createNewCollection(parentCollection), parent);
				parentCollection._items[$adrutil.indexOfDomElement(element)] = object;
			}
		}
		this._manager.addObject(this._index, adr, object);
		return object;
	},

    _findDomElementByAdr: function(adr)
	{
        var nodes = this._control.get_element().getElementsByTagName("li");
        for(var i=0, len=nodes.length; i < len; i++)
        {
            var li = nodes[i];
            var nodeId = li.getAttribute("id");
            if($adrutil.getAdrFromId(nodeId) === adr)
            {
                return li;
            }
        }
        return null;
	},

    _get_childrenCount: function(rootElement) 
    {
        ///<summary>
        /// Returns the subnodes count of the given root element.
        ///</summary>
        var count = 0;  
        if (rootElement && rootElement.tagName == "UL")
        {
            var child = rootElement.firstChild;
            while(child)
            {
                if (child.tagName == "LI")
					count++;
                child = child.nextSibling;
            }
        }
        return count;
    },

    getChildrenCount: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.getChildrenCount">Get number of items in the collection.</summary>
        ///<value type="int"></value>
        if($util.isNullOrUndefined(this.__itemCount))
        {
            this.__itemCount = this._get_childrenCount(this._owner._get_subgroup());
        }
        return this.__itemCount;
    },

    get_length: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemCollection.length">
		/// The number of objects in the collection.
		///</summary> 
		///<returns type="Integer" mayBeNull="false">Number of objects in the collection.</returns>
		return this.getChildrenCount();
	},

    dispose: function()
	{
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.dispose">
        /// Disposes the object. 
        ///</summary>
	    this._ownerNode = null;
	    $IG.DataMenuItemCollection.callBaseMethod(this, "dispose");
	}
}
$IG.DataMenuItemCollection.registerClass('Infragistics.Web.UI.DataMenuItemCollection', $IG.NavItemCollection);



$IG.DataMenuGroupSettingsCollection = function(control, clientStateManager, index, manager)
{
    $IG.DataMenuGroupSettingsCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.DataMenuGroupSettingsCollection.prototype = 
{
    getGroupSettingsObjectByAdr: function(adr)
    {
        return new $IG.DataMenuGroupSettings(null, [this._csm._items[adr]], this._control);
    }
}
$IG.DataMenuGroupSettingsCollection.registerClass('Infragistics.Web.UI.DataMenuGroupSettingsCollection', $IG.ObjectCollection);




$IG.DataMenuItemCancelEventArgs = function(eventName, params)
{
    ///<summary locid="T:J#Infragistics.Web.UI.DataMenuItemCancelEventArgs">
    /// Used internally to constuct cancelable event arguments to be passed to WebDataMenu event handlers
    ///</summary>
    $IG.DataMenuItemCancelEventArgs.initializeBase(this);
	this._context = {};
	// L.T. 4/11/2010 59265 exception when ItemHovered is raised.
	if(params && params[0])
		this._props[2] = params[0];

	if(this._props[2])
		this._context["adr"] = this.getItem()._get_address();
}

$IG.DataMenuItemCancelEventArgs.prototype =
{
    
    getItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.getItem">Get the menu item for which the event fired.</summary>
        ///<value type="Infragistics.Web.UI.DataMenuItem"></value>
        return this._props[2];
    },

    dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.dispose">Disposes object.</summary>
		this._props[0] = null;
		this._props[1] = null;
		this._props[2] = null;
	},

    _getPostArgs: function()
    {
        return ':' + this.getItem()._get_address();
    }
}
$IG.DataMenuItemCancelEventArgs.registerClass('Infragistics.Web.UI.DataMenuItemCancelEventArgs', $IG.CancelEventArgs);



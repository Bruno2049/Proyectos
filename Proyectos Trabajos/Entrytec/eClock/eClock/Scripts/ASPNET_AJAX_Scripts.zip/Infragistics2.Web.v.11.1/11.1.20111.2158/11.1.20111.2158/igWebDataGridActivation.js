/*
* igWebDataGridActivation.js
* Version 11.1.20111.2158
* Copyright(c) 2001-2012 Infragistics, Inc. All Rights Reserved.
*/


$IG.Activation = function(obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Activation">
	/// Activation behavior object of the grid.
	/// </summary>
	$IG.Activation.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._hierarchical = hierarchical;
	this._rows = this._owner.get_rows();

	this._container = control._elements["container"];

	this._activeCellCssClass = this._get_clientOnlyValue("acc");
	this._activeColCssClass = this._get_clientOnlyValue("ahc");
	this._activeRowCssClass = this._get_clientOnlyValue("arc");
	this._activeRowSelectorImgCssClass = this._get_clientOnlyValue("arsi");
	this._activeRowSelectorCssClass = this._get_clientOnlyValue("arsc");

	this._gridElement = this._grid._element;

	this._gridElementMouseDownHandler = Function.createDelegate(this, this._onMousedownHandler);
	this._gridElementKeyDownHandler = Function.createDelegate(this, this._onKeydownHandler);

	this._grid._addElementEventHandler(this._gridElement, "mousedown", this._gridElementMouseDownHandler);
	this._grid._addElementEventHandler(this._gridElement, "keydown", this._gridElementKeyDownHandler);

	this._onHideColumnHandler = Function.createDelegate(this, this._onHideColumn);
	this._grid._gridUtil._registerEventListener(this._grid, "HideColumn", this._onHideColumnHandler);

	if (this._hierarchical)
	{
		this._onRowCollapsingHandler = Function.createDelegate(this, this._onRowCollapsing);
		this._grid._gridUtil._registerEventListener(this._grid, "RowCollapsing", this._onRowCollapsingHandler);
	}

	if ($util.IsOpera)
	{
		this._gridElementKeyPressHandler = Function.createDelegate(this, this._onKeypressHandler);
		this._grid._addElementEventHandler(this._gridElement, "keypress", this._gridElementKeyPressHandler);
	}

	if (this._grid.get_enableClientRendering())
	{
		this._onDataBoundHandler = Function.createDelegate(this, this._onDataBound);
		this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
	}
}

$IG.Activation.prototype =
{
	
	__activeCell: null,

	get_activeCell: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Activation.activeCell">
		/// Returns/sets the Active cell in the WebDataGrid.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell" mayBeNull="true" />

		if (this.__activeCell)
			return this.__activeCell;

		var activeCell = null;
		var activeCellIDPair = this._get_value($IG.GridActivationProps.ActiveCell);
		if (activeCellIDPair != null)
		{
			activeCell = this._rows.get_cellFromIDPair(activeCellIDPair);
		}
		return activeCell;
	},
	get_activeCellResolved: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Activation.activeCellResolved">
		/// Returns/sets the Active cell in the grid.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell" mayBeNull="true" />

		if (!this._hierarchical)
			return this.get_activeCell();

		var mainGrid = this._grid._get_mainGrid();
		var lastActiveGridId = mainGrid._get_lastActiveGridId();
		if (lastActiveGridId)
		{
			var lastActiveGrid = ig_controls[lastActiveGridId];
			if (lastActiveGrid)
			{
				var activation = lastActiveGrid.get_behaviors().get_activation();
				if (activation)
					return activation.get_activeCell();
			}
		}
		return null;
	},
	get_activeGroupedRow: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Activation.activeGroupedRow">
		/// Returns active grouped row for the ContainerGrid if there is one (this method should only be used for IG.WebHierarchicalDataGrid).
		/// </summary>
		/// <value type="Infragistics.Web.UI.GroupedRow" mayBeNull="true" />
		if (this.__activeElement)
			return this.__activeElement.get_row();

		var activeRow = null;
		var activeRowIndecies = this._get_value($IG.GridActivationProps.ActiveGroupedRow);
		if (activeRowIndecies != null && activeRowIndecies.length)
		{
			for (var i = activeRowIndecies.length - 1; i >= 0; i--)
			{
				
				if (i == activeRowIndecies.length - 1)
					activeRow = this._grid.get_groupRows().get_row(activeRowIndecies[i]);
				else if (activeRow)
					activeRow = activeRow.get_childGroupRows().get_row(activeRowIndecies[i]);
				else
					return null;
			}
			if (activeRow)
				this.__activeElement = activeRow._get_valueCell();
		}
		return activeRow;
	},
	set_activeGroupedRow: function (row, fireEvent)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Activation.activeGroupedRow">
		/// Sets the active grouped row for the ContainerGrid (this method should only be used for IG.WebHierarchicalDataGrid).
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GroupedRow">The row to make active</param>
		/// <param name="fireEvent" type="Boolean">This is an optional parameter, which indicates whether the events need to be fired</param>

		if (this._hierarchical)
		{
			if (row)
			{
				if (row._owner != this._grid)
					return
				var cell = row._get_valueCell();
				var parentRow = this._grid.get_parentRow();
				var cellElement = cell.get_element();
				if (parentRow && !parentRow.get_expanded() || cellElement && cellElement.offsetWidth <= 0)
					return;

				this._set_activeElement(cell, fireEvent, false, false, null, "code");
			}
			else
				this._set_activeElement(row, fireEvent, false, false, null, "code");
		}

	},
	get_activeGroupedRowResolved: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.Activation.activeGroupedRowResolved">
		/// Returns active grouped row for the whole IG.WebHierarchicalDataGrid if one is set, otherwise null will be returned.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GroupedRow">Row</value>

		if (!this._hierarchical)
			return null;

		var mainGrid = this._grid._get_mainGrid();
		var lastActiveGridId = mainGrid._get_lastActiveGridId();
		if (lastActiveGridId)
		{
			var lastActiveGrid = ig_controls[lastActiveGridId];
			if (lastActiveGrid)
			{
				var activation = lastActiveGrid.get_behaviors().get_activation();
				if (activation)
					return activation.get_activeGroupedRow();
			}
		}
		return null;
	},
	_set_activeCell: function (cell, fireEvent, shiftKey, ctrlkey, keyCode, howInvoked, src, metaKey)
	{
		var activeCell = this.get_activeCell();
		if (cell == activeCell && cell != null)
		{
			
			if (src && src != cell.get_element())
				return;
			if (this._hierarchical)
				this.__focusCell(activeCell);
			return;
		}
		
		if (src && src == cell.get_element())
			src = null;

		if (cell && cell.get_column().get_hidden())
			return;

		if (fireEvent)
		{
			var args = this.__raiseClientEvent("ActiveCellChanging", $IG.ActiveCellChangingEventArgs, [activeCell, cell, this.get_activeGroupedRow(), null]);
			if (args != null && args.get_cancel())
			{
				if (this.__rowCollapsing)
					this.__rowCollapsing = false;
				return;
			}
		}
		this._grid._gridUtil._fireEvent(this, "ActiveCellChanging", { activeCell: activeCell, cell: cell, shiftKey: shiftKey, ctrlKey: ctrlkey, keyCode: keyCode, howInvoked: howInvoked, metaKey: metaKey });

		this.__inSetActiveCell = true;
		if (this._hierarchical)
			this._set_activeGrid();
		this.__activeCell = cell;

		if (!this.__inSetActiveElement && this.get_activeGroupedRow())
			this.set_activeGroupedRow(null, false);
		if (activeCell)
		{
			var old = activeCell.get_element();
			if (old)
				old.tabIndex = -1;
			this.__removeCssClass(activeCell, false);
		}

		var key = null;
		if (cell != null)
		{
			var row = cell.get_row();
			if (row != null)
			{
				key = cell.get_idPair();
				var elem = cell.get_element();
				this.__addCssClass(cell);
				
				if (elem)
					elem.tabIndex = this._grid._element.tabIndex;
				this.__focusCell(cell, src);
			}
		}
		this._set_value($IG.GridActivationProps.ActiveCell, key);

		if (fireEvent)
			this.__raiseClientEvent("ActiveCellChanged", $IG.ActiveCellChangedEventArgs, [this, cell, true, this.get_activeGroupedRow()]);

		this._grid._gridUtil._fireEvent(this, "ActiveCellChanged", { cell: cell, shiftKey: shiftKey, ctrlKey: ctrlkey, howInvoked: howInvoked, rowCollapsing: this.__rowCollapsing, metaKey: metaKey });
		this.__rowCollapsing = false;
		this.__inSetActiveCell = false;
	},

	_set_activeElement: function (cell, fireEvent, shiftKey, ctrlkey, keyCode, howInvoked, src)
	{
		var activeGrpRow = this.get_activeGroupedRow();
		var activeElem = (activeGrpRow ? activeGrpRow._get_valueCell() : null);

		if (cell == activeElem && cell != null)
		{
			
			if (src && src != cell.get_element())
				return;
			if (this._hierarchical)
				this.__focusCell(activeElem);
			return;
		}
		
		if (src && src == cell.get_element())
			src = null;

		if (fireEvent)
		{
			var args = this.__raiseClientEvent("ActiveCellChanging", $IG.ActiveCellChangingEventArgs, [this.get_activeCell(), null, activeGrpRow, (cell ? cell.get_row() : null)]);
			if (args != null && args.get_cancel())
			{
				if (this.__rowCollapsing)
					this.__rowCollapsing = false;
				return;
			}
		}

		this.__inSetActiveElement = true;
		if (this._hierarchical)
			this._set_activeGrid();
		this.__activeElement = cell;

		if (!this.__inSetActiveCell && this.get_activeCell())
			this.set_activeCell(null, false);
		if (activeElem)
		{
			var old = activeElem.get_element();
			if (old)
				old.tabIndex = -1;
			this.__removeCssClass(activeElem, true);
		}


		var key = null;
		if (cell != null)
		{
			var row = cell.get_row();
			if (row != null)
			{
				key = cell.get_idPair();
				var elem = cell.get_element();
				this.__addCssClass(cell);
				
				if (elem)
					elem.tabIndex = this._grid._element.tabIndex;
				this.__focusCell(cell, src);
			}
		}
		this._set_value($IG.GridActivationProps.ActiveGroupedRow, key);

		if (fireEvent)
			this.__raiseClientEvent("ActiveCellChanged", $IG.ActiveCellChangedEventArgs, [this, this.get_activeCell(), true, (cell ? cell.get_row() : null)]);

		this.__rowCollapsing = false;
		this.__inSetActiveElement = false;
	},
	_set_activeGrid: function ()
	{
		var mainGrid = this._grid._get_mainGrid();
		if (mainGrid._lastActiveGridIdLock)
			return;

		var lastGridId = mainGrid._get_lastActiveGridId();
		var currentGridId = this._grid.get_id();
		if (lastGridId != null && lastGridId != currentGridId)
		{
			mainGrid._lastActiveGridIdLock = true;
			
			var lastActiveGrid = ig_controls[lastGridId];
			if (lastActiveGrid)
			{
				var activation = lastActiveGrid.get_behaviors().get_activation();
				if (activation.get_activeCell() != null)
					activation.set_activeCell(null, true);
				if (activation.get_activeGroupedRow() != null)
					activation.set_activeGroupedRow(null, true);
			}
			mainGrid._lastActiveGridIdLock = false;
		}
		mainGrid._set_lastActiveGridId(currentGridId);

	},
	set_activeCell: function (cell, fireEvent)
	{
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell to activate.</param>
		///<param name="fireEvent" type="Boolean" optional="true">Optional. Whether the client events should be fired.</param>
		if (this._hierarchical && cell)
		{
			if (cell._owner != this._grid)
				return
			var parentRow = this._grid.get_parentRow();
			var cellElement = cell.get_element();
			if (parentRow && !parentRow.get_expanded() || cellElement && cellElement.offsetWidth <= 0)
				return;
		}
		this._set_activeCell(cell, fireEvent, false, false, null, "code", null, false);
	},
	

	

	_onMousedownHandler: function (evnt)
	{
		if (evnt.button == 0)
		{
			var src = evnt.target;
			if (!src)
				return;
			if (src.nodeName == '#text')
				src = src.parentNode;
			var cell = this._grid._gridUtil.getCellFromElem(src);
			
			if (cell != null)
				this._set_activeCell(cell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "mousedown", src, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
			else if (this._hierarchical)
			{
				var rowElem = this._grid._gridUtil._isGroupRow(evnt.target) ? evnt.target : evnt.target.parentNode;
				var row = this._grid._gridUtil.getGrpRowFromElem(rowElem);
				if (row)
				{
					cell = row._get_valueCell();
					var checkCell = (rowElem != evnt.target ? true : false);
					if (cell && (!checkCell || evnt.target == cell.get_element()))
						this._set_activeElement(cell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "mousedown", src);
				}
			}
		}
	},

	_onKeydownHandler: function (evnt)
	{
		var util = this._grid._gridUtil;
		var cell = util.getCellFromElem(evnt.target);
		var key = evnt.keyCode;
		var grpCell = null;
		var grpRow = null;
		if (this._hierarchical && cell == null)
		{
			var grpRowElem = this._grid._gridUtil._isGroupRow(evnt.target) ? evnt.target : evnt.target.parentNode;
			grpRow = this._grid._gridUtil.getGrpRowFromElem(grpRowElem);
			if (grpRow)
			{
				grpCell = grpRow._get_valueCell();
				if (grpRowElem != evnt.target && evnt.target != grpCell.get_element())
					grpCell = null;
			}
		}
		
		if (!(key == Sys.UI.Key.enter || key == Sys.UI.Key.tab))
		{
			var src = cell ? cell.get_element() : (grpCell ? grpCell.get_element() : null);
			if (src && src != evnt.target)
				return;
		}
		
		var upDown = 0;
		
		var row = null;
		if (this._hierarchical && (this.__activeCell != null || grpRow != null) && !this._grid._cellInEditMode &&
			(!$util.IsOpera && ((!evnt.shiftKey && key == 189) || key == 107 || key == 109 || (evnt.shiftKey && key == 187)) ||
			$util.IsOpera && (key == 43 || key == 45 || (evnt.shiftKey && key == 61) || (!evnt.shiftKey && key == 109))))
		{
			row = (this.__activeCell ? this.__activeCell.get_row() : grpRow);
			
			if (!row.set_expanded)
				row = null;
		}

		if (this._hierarchical && this.get_activeCell() != null && !this._grid._cellInEditMode && (evnt.altKey && evnt.ctrlKey && key == 71))
		{
			this._grid._get_mainGrid()._toggleColumnGrouping(this.get_activeCell().get_column(), this._grid._get_band());
			this._operaCancelKeyPress = true;
			$util.cancelEvent(evnt);
		}
		
		if (row)
		{
			var expand = ((key == 189 || key == 109 || key == 45) ? false : true);
			if (!grpRow)
				row.__fireExpndColEvnt = true;
			row.set_expanded(expand);
			this._operaCancelKeyPress = true;
			$util.cancelEvent(evnt);
		}
		else if (cell != null && key == Sys.UI.Key.space && cell.get_column()._isCheck)
		{
			var column = cell._column;
			var checkbox = cell._get_ImgCheckbox();
			if (checkbox && column._editableCheckbox)
			{
				var checked = parseInt(checkbox.getAttribute("chkState"));
				var newValue = checked != $IG.CheckBoxState.Unchecked ? column._defaultFalse : column._defaultTrue;
				var newCheckedValue = checked != $IG.CheckBoxState.Unchecked ? 0 : 1;
				cell.set_value(newValue, newCheckedValue);
				$util.cancelEvent(evnt);
			}
		}
		else if (cell != null || grpCell != null)
		{
			var nextCell = null;
			var nextGrpCell = null;
			if (key == Sys.UI.Key.tab && evnt.shiftKey || key == Sys.UI.Key.left)
			{
				var allowRowMove = true;
				if (evnt.shiftKey && key == Sys.UI.Key.left)
					allowRowMove = false;

				if (cell)
				{
					if (this._hierarchical && allowRowMove && cell.get_column().get_visibleIndex() == util._getVisibleIndexOfFirstVisibleColumn())
					{
						var prevGroupedRow = util._getGroupRowIfPrev(cell._row);
						if (prevGroupedRow)
							nextGrpCell = prevGroupedRow._get_valueCell();
						else
						{
							var prevGridInfo = util._getPrevRowForPrevGrid(cell._row);
							
							if (prevGridInfo != null && prevGridInfo.prevRow != null)
							{
								if (this.__processPrevGridInfo(prevGridInfo, evnt, null))
									return;
							}
						}
					}

					if (!nextGrpCell)
						nextCell = util.getPrevCell(cell);
				}
				else
				{
					var prevGrpRowKeyInfo = this.__processPrevKeyForGroupRow(grpRow, evnt);
					if (prevGrpRowKeyInfo.exit)
						return;
					nextGrpCell = prevGrpRowKeyInfo.nextGrpCell;
					nextCell = prevGrpRowKeyInfo.nextCell;
				}
				if (!allowRowMove && nextCell && nextCell._row.get_index() != cell._row.get_index())
					nextCell = null;
			}
			else if (key == Sys.UI.Key.up || (key == Sys.UI.Key.enter && evnt.shiftKey))
			{
				upDown = 1;
				if (cell)
				{
					if (this._hierarchical)
					{
						var prevGroupedRow = util._getGroupRowIfPrev(cell._row);
						if (prevGroupedRow)
							nextGrpCell = prevGroupedRow._get_valueCell();
						else
						{
							var prevGridInfo = util._getPrevRowForPrevGrid(cell._row);
							if (this.__processPrevGridInfo(prevGridInfo, evnt, cell.get_index()))
								return;
						}
					}
					if (!nextGrpCell)
						nextCell = util.getPrevCellVert(cell);
				}
				else
				{
					var prevGrpRowKeyInfo = this.__processPrevKeyForGroupRow(grpRow, evnt);
					if (prevGrpRowKeyInfo.exit)
						return;
					nextGrpCell = prevGrpRowKeyInfo.nextGrpCell;
					nextCell = prevGrpRowKeyInfo.nextCell;
				}
			}
			else if (key == Sys.UI.Key.right || (key == Sys.UI.Key.tab && !evnt.shiftKey))
			{
				var allowRowMove = true;
				if (evnt.shiftKey && key == Sys.UI.Key.right)
					allowRowMove = false;
				if (cell)
				{
					if (this._hierarchical)
					{
						if (cell && allowRowMove && cell.get_column().get_visibleIndex() == util._getVisibleIndexOfLastVisibleColumn())
						{
							var nextGroupedRow = util._getGroupRowIfNext(cell._row);
							if (nextGroupedRow)
								nextGrpCell = nextGroupedRow._get_valueCell();
							else
							{
								var nextGridInfo = util._getNextRowForNextGrid(cell._row);
								if (this.__processNextGridInfo(nextGridInfo, evnt))
									return;
							}
						}

					}
					if (!nextGrpCell)
						nextCell = util.getNextCell(cell);
				}
				else // must have the grpCell not being null then
				{
					var nextGrpRowKeyInfo = this.__processNextKeyForGroupRow(grpRow, evnt);
					if (nextGrpRowKeyInfo.exit)
						return;
					nextGrpCell = nextGrpRowKeyInfo.nextGrpCell;
					nextCell = nextGrpRowKeyInfo.nextCell;
				}
				if (!allowRowMove && nextCell && nextCell._row.get_index() != cell._row.get_index())
					nextCell = null;
			}
			else if (key == Sys.UI.Key.down || key == Sys.UI.Key.enter)
			{
				upDown = 2;
				if (cell)
				{
					if (this._hierarchical)
					{
						var nextGroupedRow = util._getGroupRowIfNext(cell._row);
						if (nextGroupedRow)
							nextGrpCell = nextGroupedRow._get_valueCell();
						else
						{
							var nextGridInfo = util._getNextRowForNextGrid(cell._row);
							if (nextGridInfo != null)
							{
								var nextGrid = nextGridInfo.nextGrid;
								var nextRow = nextGridInfo.nextRow;
								if (nextRow != null)
								{
									var nextActivation = nextGrid.get_behaviors().get_activation();

									if (nextRow._get_rowType && nextRow._get_rowType() == "GroupedRow")
									{
										this._operaCancelKeyPress = true;
										nextActivation._set_activeElement(nextRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown");
										$util.cancelEvent(evnt);
									}
									else
									{
										var cellCount = nextRow.get_cellCount() - 1;
										var cellIndex = cell.get_index();
										var visibleIndex = this._grid.get_columns().get_column(cellIndex).get_visibleIndex();
										visibleIndex = (visibleIndex > cellCount ? cellCount : visibleIndex);

										var nextGridCellIndex = nextActivation.__get_prevVisibleCellIndex(visibleIndex);
										if (nextGridCellIndex == -1)
											nextGridCellIndex = nextActivation.__get_nextVisibleCellIndex(visibleIndex);

										this._operaCancelKeyPress = true;
										nextActivation._set_activeCell(nextRow.get_cell(nextGridCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
										$util.cancelEvent(evnt);
									}
									return;
								}
							}
						}
					}
					if (!nextGrpCell)
						nextCell = util.getNextCellVert(cell);
				}
				else
				{
					var nextGrpRowKeyInfo = this.__processNextKeyForGroupRow(grpRow, evnt);
					if (nextGrpRowKeyInfo.exit)
						return;
					nextGrpCell = nextGrpRowKeyInfo.nextGrpCell;
					nextCell = nextGrpRowKeyInfo.nextCell;
				}
			}
			if (nextCell != null || nextGrpCell != null)
			{
				
				var shiftKey = evnt.shiftKey;
				if (key == Sys.UI.Key.tab || key == Sys.UI.Key.enter)
					shiftKey = false;

				this._operaCancelKeyPress = true;
				if (nextCell != null)
					this._set_activeCell(nextCell, true, shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
				else
					this._set_activeElement(nextGrpCell, true, shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown");
				$util.cancelEvent(evnt);
			}
			
			else if (upDown != 0)
			{
				var vs = this._grid.get_behaviors().getBehaviorByName('VirtualScrolling');
				if (vs && vs._doScroll(upDown))
					$util.cancelEvent(evnt);
			}
		}
		else if (evnt.target == this._gridElement && key == Sys.UI.Key.tab && !evnt.shiftKey)
		{
			var setFirstCell = true;
			if (this._hierarchical)
			{
				var lastActiveGridId = this._grid._get_mainGrid()._get_lastActiveGridId();
				if (lastActiveGridId != null)
				{
					var lastActiveGrid = ig_controls[lastActiveGridId];
					if (lastActiveGrid)
					{
						var activation = lastActiveGrid.get_behaviors().get_activation();
						if (activation.get_activeCell() != null)
						{
							setFirstCell = this.__restoreFocusToActiveCell(activation, activation.get_activeCell(), evnt);
						}
						else if (activation.get_activeGroupedRow() != null)
							setFirstCell = this.__restoreFocusToActiveCell(activation, activation.get_activeGroupedRow()._get_valueCell(), evnt);
					}
				}
			}

			if (this.get_activeCell() == null && setFirstCell && !this._headerBtnBehavior)
			{
				// If focus is on the Grid Element, and there is no ActiveCell, and tab is pressed, then resolve the first row
				// in the Grid (note it might be an aux row) and set it's first cell as active.				
				var row = (this._hierarchical ? this._grid._gridUtil._getFirstVisualRowObject() : this._grid._gridUtil.getFirstVisualRow());
				if (row)
				{
					if (row._get_rowType && row._get_rowType() == "GroupedRow")
					{

						var nextCell = row._get_valueCell(); //row.cells[1];
						this._set_activeElement(nextCell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown");
						this._operaCancelKeyPress = true;
						$util.cancelEvent(evnt);
					}
					else
					{
						
						var i = 0;
						var column = this._grid._gridUtil._getColumnFromVisibleIndex(i);
						while (column && column.get_hidden())
							column = this._grid._gridUtil._getColumnFromVisibleIndex(++i);
						if (column)
						{
							var cellAdr = column.get_index();
							var nextCell = row.get_cell(cellAdr);
							this._set_activeCell(nextCell, true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
							this._operaCancelKeyPress = true;
							$util.cancelEvent(evnt);
						}
					}
				}
			}
		}
	},
	__restoreFocusToActiveCell: function (activation, cell, evnt)
	{
		var setFirstCell = true;
		var cellElement = cell.get_element();
		if (cellElement.offsetWidth > 0)
		{
			try
			{
				setFirstCell = false;
				activation.__focusCell(cell);
				$util.cancelEvent(evnt);

			}
			catch (e)
			{
				setFirstCell = true;
			}
		}
		return setFirstCell;
	},
	__processPrevKeyForGroupRow: function (grpRow, evnt)
	{
		var nextGrpCell = null;
		var nextCell = null;
		var exit = false;
		var goToFirstCell = (evnt.keyCode == Sys.UI.Key.up || (evnt.keyCode == Sys.UI.Key.enter && evnt.shiftKey));

		var rowIndex = grpRow.get_index() - 1;
		var rowCollection = grpRow._get_collectionOwner();
		if (rowIndex < 0)
		{
			if (rowCollection.get_grid() != rowCollection._get_owner())
			{
				
				nextGrpCell = rowCollection._get_owner()._get_valueCell();
			}
			else
			{
				var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Top);
				if (auxRows && auxRows.length)
				{
					var lastCellIndex = (goToFirstCell ? this.__get_firstVisibleCellIndex() : this._grid._gridUtil._findLastVisibleColumn().get_index());
					nextCell = auxRows[auxRows.length - 1].get_cell(lastCellIndex);
				}
				else
				{
					var prevGridInfo = this._grid._gridUtil._getPrevRowForPrevGrid(grpRow.__getFirstDataRow());
					if (this.__processPrevGridInfo(prevGridInfo, evnt, (goToFirstCell ? 0 : null)))
						exit = true;
				}
			}

		}
		else
		{
			var previousGrpRow = rowCollection.get_row(rowIndex);
			if (previousGrpRow)
			{
				if (!previousGrpRow.get_expanded())
					nextGrpCell = previousGrpRow._get_valueCell();
				else
				{
					var childGrpRows = previousGrpRow.get_childGroupRows();
					var lastChildRow = (childGrpRows && childGrpRows.get_length() > 0) ? childGrpRows.get_row(childGrpRows.get_length() - 1) : null;
					while (lastChildRow && lastChildRow.get_expanded())
					{
						previousGrpRow = lastChildRow;
						childGrpRows = previousGrpRow.get_childGroupRows();
						lastChildRow = (childGrpRows && childGrpRows.get_length() > 0) ? childGrpRows.get_row(childGrpRows.get_length() - 1) : null;
					}
					if (lastChildRow)
						previousGrpRow = lastChildRow;
					if (previousGrpRow.get_expanded())
					{
						var dataRows = previousGrpRow.get_rows();
						var row = dataRows[dataRows.length - 1];

						
						var prevGridInfo = this._grid._gridUtil._getPrevRowForPrevGrid(grpRow.__getFirstDataRow());
						if (this.__processPrevGridInfo(prevGridInfo, evnt, (goToFirstCell ? 0 : null)))
							exit = true;
						else
						{
							var lastCellIndex = (goToFirstCell ? this.__get_firstVisibleCellIndex() : this._grid._gridUtil._findLastVisibleColumn().get_index());
							nextCell = row.get_cell(lastCellIndex);
						}
					}
					else
						nextGrpCell = previousGrpRow._get_valueCell();
				}
			}
		}


		return { "nextGrpCell": nextGrpCell, "nextCell": nextCell, "exit": exit };
	},
	__processPrevGridInfo: function (prevGridInfo, evnt, neededIndex)
	{
		if (prevGridInfo != null)
		{
			var prevGrid = prevGridInfo.prevGrid;
			var prevRow = prevGridInfo.prevRow;
			if (prevRow != null)
			{
				var prevActivation = prevGrid.get_behaviors().get_activation();
				var prevRowElem = prevRow.get_element();
				if (prevRowElem.style.display == "") 
				{
					var cellCount = prevRow.get_cellCount() - 1;
					var visibleIndex = cellCount;
					if (neededIndex != null)
					{
						visibleIndex = this._grid.get_columns().get_column(neededIndex).get_visibleIndex();
						visibleIndex = (visibleIndex > cellCount ? cellCount : visibleIndex);
					}

					var previousGridCellIndex = prevActivation.__get_prevVisibleCellIndex(visibleIndex);
					if (previousGridCellIndex == -1)
						previousGridCellIndex = prevActivation.__get_nextVisibleCellIndex(visibleIndex);
					prevActivation._set_activeCell(prevRow.get_cell(previousGridCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
				}
				else 
				{
					var rows = $util.getRows(prevGrid._elements["rows"]);
					var index = prevRowElem.rowIndex;
					var grpRow = null;
					while (!grpRow && index > -1)
					{
						grpRow = prevGrid._gridUtil._getGroupRowIfPrevFromElem(rows[index]);
						index--;
					}
					if (grpRow)
					{
						var grpRowElem = grpRow.get_element();
						while (grpRowElem && grpRowElem.style.display == "none")
						{
							grpRow = grpRow._get_collectionOwner()._get_owner();
							grpRowElem = grpRow.get_element();
						}
						prevActivation._set_activeElement(grpRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown");
					}
				}
				$util.cancelEvent(evnt);
				return true;
			}
		}
		return false;
	},
	__processNextKeyForGroupRow: function (grpRow, evnt)
	{
		var nextGrpCell = null;
		var nextCell = null;
		var exit = false;
		if (grpRow.get_expanded())
		{
			var childGrpRows = grpRow.get_childGroupRows();
			if (childGrpRows && childGrpRows.get_length() > 0)
				nextGrpCell = childGrpRows.get_row(0)._get_valueCell();
			else
			{
				var index = this.__get_firstVisibleCellIndex();
				if (index > -1)
					nextCell = grpRow.get_rows()[0].get_cell(index);
			}
		}
		else
		{
			var rowIndex = grpRow.get_index() + 1;
			var rowCollection = grpRow._get_collectionOwner();
			while (rowCollection)
			{
				if (rowIndex < rowCollection.get_length())
				{
					nextGrpCell = rowCollection.get_row(rowIndex)._get_valueCell();
					break;
				}
				if (rowCollection.get_grid() == rowCollection._get_owner())
				{
					
					var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
					if (auxRows && auxRows.length)
					{
						var index = this.__get_firstVisibleCellIndex();
						nextCell = auxRows[auxRows.length - 1].get_cell(index);
					}
					break;
				}
				rowIndex = rowCollection._get_owner().get_index() + 1;
				rowCollection = rowCollection._get_owner()._get_collectionOwner();
			}
			
			if (nextGrpCell == null && nextCell == null)
			{
				var nextGridInfo = this._grid._gridUtil._getNextRowForNextGridFromGrpRow(grpRow);
				exit = this.__processNextGridInfo(nextGridInfo, evnt);
			}
		}
		return { "nextGrpCell": nextGrpCell, "nextCell": nextCell, "exit": exit };
	},
	__processNextGridInfo: function (nextGridInfo, evnt)
	{
		if (nextGridInfo != null)
		{
			var nextGrid = nextGridInfo.nextGrid;
			var nextRow = nextGridInfo.nextRow;
			if (nextRow != null)
			{
				var nextActivation = nextGrid.get_behaviors().get_activation();

				if (nextRow._get_rowType && nextRow._get_rowType() == "GroupedRow")
				{
					this._operaCancelKeyPress = true;
					nextActivation._set_activeElement(nextRow._get_valueCell(), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown");
					$util.cancelEvent(evnt);
				}
				else
				{
					var visCol = nextGrid._gridUtil._findFirstVisibleColumn();
					if (visCol)
					{
						var firstCellIndex = visCol.get_index();

						this._operaCancelKeyPress = true;
						nextActivation._set_activeCell(nextRow.get_cell(firstCellIndex), true, evnt.shiftKey, evnt.ctrlKey, evnt.keyCode, "keydown", null, $util.IsMac && evnt.rawEvent && evnt.rawEvent.metaKey);
						$util.cancelEvent(evnt);
					}
				}
				return true;
			}
		}
		return false;
	},
	__get_firstVisibleCellIndex: function ()
	{
		var i = 0;
		var column = this._grid._gridUtil._getColumnFromVisibleIndex(i);
		while (column && column.get_hidden())
			column = this._grid._gridUtil._getColumnFromVisibleIndex(++i);
		if (column)
			return column.get_index();
		return -1;
	},

	__get_prevVisibleCellIndex: function (index)
	{
		var i = index;
		var column = this._grid._gridUtil._getColumnFromVisibleIndex(i);
		while (column && column.get_hidden())
			column = this._grid._gridUtil._getColumnFromVisibleIndex(--i);
		if (column)
			return column.get_index();

		

		return -1;
	},

	__get_nextVisibleCellIndex: function (index)
	{
		var i = index;
		var column = this._grid._gridUtil._getColumnFromVisibleIndex(i);
		while (column && column.get_hidden())
			column = this._grid._gridUtil._getColumnFromVisibleIndex(++i);
		if (column)
			return column.get_index();
		

		return -1;
	},

	_onKeypressHandler: function (evnt)
	{
		
		if (this._operaCancelKeyPress)
			$util.cancelEvent(evnt);
		this._operaCancelKeyPress = false;
	},

	_rowSelectorClicked: function (args)
	{
		var column = this._grid._gridUtil._findFirstVisibleColumn();
		if (!column)
			return;
		var firstCellIndex = column.get_index();
		this._set_activeCell(args.row.get_cell(firstCellIndex), true, false, false, null, "rowSelector", null, false);
	},

	_onHideColumn: function (args)
	{
		var activeCell = this.get_activeCell();
		if (activeCell && activeCell.get_column() == args.column && args.column.get_hidden())
		{
			var util = this._grid._gridUtil;
			var nextCell = util.getPrevCell(activeCell);
			if (!nextCell)
				nextCell = util.getNextCell(activeCell);
			this.set_activeCell(nextCell);
		}
	},

	_onRowCollapsing: function (args)
	{
		var row = args.row;
		var lastActiveGridId = this._grid._get_mainGrid()._get_lastActiveGridId();
		var lastActiveGrid = (lastActiveGridId ? ig_controls[lastActiveGridId] : null);

		if (row._get_rowType && row._get_rowType() == "GroupedRow")
		{
			var activation = this._grid.get_behaviors().get_activation();
			var activeCell = activation.get_activeCell();
			var activeRow = null;
			if (activeCell)
				activeRow = activeCell.get_row();
			else
				activeRow = activation.get_activeGroupedRow();
			var parentActiveRow = null;
			if (!activeRow && lastActiveGrid)
			{
				parentActiveRow = this._grid._gridUtil._getParentRowOfDescendent(lastActiveGrid);
			}

			if (activeRow || parentActiveRow)
			{
				var startIdx = row.get_element().rowIndex;
				var rowCollection = row._get_collectionOwner();
				var endIdx;
				if (row.get_index() < rowCollection.get_length() - 1)
					endIdx = rowCollection.get_row(row.get_index() + 1).get_element().rowIndex;
				else
				{
					var rows = $util.getRows(this._grid._elements["rows"]);
					endIdx = (rows && rows.length ? rows.length : 0);
				}
				var activeRowIdx = (activeRow ? activeRow.get_element().rowIndex : parentActiveRow.get_element().rowIndex);
				if (startIdx < activeRowIdx && activeRowIdx < endIdx)
				{
					activation.__rowCollapsing = true;
					activation.set_activeGroupedRow(row, true);
				}
			}
		}
		else
		{
			if (lastActiveGrid && this._grid._gridUtil.isGridADescendent(row, lastActiveGrid))
			{
				var activation = this._grid.get_behaviors().get_activation();
				var firstCellIndex = this._grid._gridUtil._findFirstVisibleColumn().get_index();
				activation.__rowCollapsing = true;
				activation.set_activeCell(row.get_cell(firstCellIndex), true);
			}
		}
	},
	_onDataBound: function (args)
	{
		this._rows = this._grid.get_rows();
		if (this.get_activeCell())
		{
			var activeCellIDPair = this._get_value($IG.GridActivationProps.ActiveCell);
			if (activeCellIDPair != null)
			{
				this.set_activeCell(null, false);
				if (args.init || this._grid._get_dataKeyFieldsSet())
				{
					var activeCell = this._rows.get_cellFromIDPair(activeCellIDPair);
					this.set_activeCell(activeCell, false);
				}
			}
		}

	},
	

	
	__focusCell: function (cell, noFocus)
	{
		var elem = cell ? cell.get_element() : null;
		if (!elem || elem.offsetWidth == 0)
			return;
		var args = { cell: cell, cancel: false };
		this._grid._gridUtil._fireEvent(this, "ScrolledCellIntoView", args);
		if (args.cancel)
			return;
		this._grid._gridUtil.scrollCellIntoViewIE(cell, noFocus);
		
		var cont = cell.get_row();
		if (cont)
			if ((cont = cont._container) == this._container)
				cont = null;
		


		if ($util.IsFireFox && this._grid._notifyBehaviorTData && !cont)
			this._grid._notifyBehaviorTData._onTick();
	},
	__addCssClass: function (cell)
	{		
		$util.addCompoundClass(cell.get_element(), this._activeCellCssClass);
		var colElem = (cell.get_column ? cell.get_column()._headerElement : null);
		if (colElem)
			$util.addCompoundClass(colElem, this._activeColCssClass);

		var row = cell.get_row();
		if (this._rowSelectors)
		{
			

			if (this._grid._get_auxRowIndex(row, null) == -1 && !(this._hierarchical && this._grid._gridUtil._isGroupRow(row.get_element())))
			{
				this._rowSelectors.addSelectorImage(row, this._activeRowSelectorImgCssClass);
				this._rowSelectors.addSelectorClass(row, this._activeRowSelectorCssClass);
			}
		}
		this._grid._gridUtil._fireEvent(this, "AddingActiveRowCssClass", { "row": row, "cssClass": this._activeRowCssClass });
		$util.addCompoundClass(row.get_element(), this._activeRowCssClass);
	},

	__removeCssClass: function (cell, isActiveElem)
	{
		if (!cell)
			return;
		var cellId = cell.get_idPair();
		var tempCell = cell.get_element() ? cell : this._grid._rows.get_cellFromIDPair(cellId);
		var cellEl = tempCell ? tempCell.get_element() : null;
		$util.removeCompoundClass(cellEl, this._activeCellCssClass);
		var col = cell.get_column ? cell.get_column() : null;
		if (!col && cell.get_idPair && !isActiveElem)
			col = this._grid.get_columns().get_columnFromIDPair(cell.get_idPair().columnIDPair);
		var colElem = (col ? col._headerElement : null);
		if (colElem)
			$util.removeCompoundClass(colElem, this._activeColCssClass);

		var row = cell.get_row() ? cell.get_row() : this._grid._rows.get_rowFromIDPair(cellId.rowIDPair);
		if (row)
		{
			if (this._rowSelectors)
			{
				this._rowSelectors.removeSelectorImage(row, this._activeRowSelectorImgCssClass);
				this._rowSelectors.removeSelectorClass(row, this._activeRowSelectorCssClass);
			}

			this._grid._gridUtil._fireEvent(this, "RemovingActiveRowCssClass", { "row": row, "cssClass": this._activeRowCssClass });
			$util.removeCompoundClass(row.get_element(), this._activeRowCssClass);
		}
	},

	_addActiveCellChangedEventHandler: function (handler, priority)
	{
		/// <summary>
		/// Adds a listener to the active cell changed event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
		/// <param name="priority" type="Boolean">
		/// Indicates if the handler should have higher priority.
		/// </param>
		this._grid._gridUtil._registerEventListener(this, "ActiveCellChanged", handler, priority);
	},

	_addActiveCellChangingEventHandler: function (handler)
	{
		/// <summary>
		/// Adds a listener to the active cell changing event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
		this._grid._gridUtil._registerEventListener(this, "ActiveCellChanging", handler);
	},

	_addScrolledCellIntoViewEventHandler: function (handler)
	{
		/// <summary>
		/// Adds a listener to the ScrolledCellIntoView event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
		this._grid._gridUtil._registerEventListener(this, "ScrolledCellIntoView", handler);
	},
	

	



	

	

	_initializeComplete: function ()
	{
		this._rowSelectors = this._parentCollection.getBehaviorFromInterface($IG.IRowSelectorsBehavior);
		if (this._rowSelectors)
			this._rowSelectors.addRowSelectorClickedEventHandler(Function.createDelegate(this, this._rowSelectorClicked));

		var activeCell = this.get_activeCell();
		if (activeCell != null)
			this.__setTabIndexOnInit(activeCell.get_element());

		var activeGroupedRow = this.get_activeGroupedRow();
		if (activeGroupedRow)
			this.__setTabIndexOnInit(activeGroupedRow._get_valueCell().get_element());

		var headerBtnBhvr = this._parentCollection.getBehaviorFromInterface($IG.IHeaderButton);
		if (headerBtnBhvr)
			this._headerBtnBehavior = headerBtnBhvr;

		this._selection = this._parentCollection.getBehaviorFromInterface($IG.ISelectionBehavior);
	},

	__setTabIndexOnInit: function (elem)
	{
		if (this._grid.tabIndex != -1)
			elem.tabIndex = this._grid.tabIndex;
		else
			elem.tabIndex = 0;
		if (this._hierarchical)
			this._set_activeGrid();
	},
	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Activation.dispose">Called by the framework whe the object is being disposed of.</summary>

		if (!this._grid)
			return;
		this._grid._removeElementEventHandler(this._container, "mousedown", this._gridElementMouseDownHandler);
		this._grid._removeElementEventHandler(this._gridElement, "keydown", this._gridElementKeyDownHandler);
		this._grid._gridUtil._unregisterEventListener(this._grid, "HideColumn", this._onHideColumnHandler);
		delete this._onHideColumnHandler;

		if (this._hierarchical)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "RowCollapsing", this._onRowCollapsingHandler);
			delete this._onRowCollapsingHandler;
		}

		if (this._grid.get_enableClientRendering())
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
			delete this._onDataBoundHandler;
		}

		$IG.Activation.callBaseMethod(this, "dispose");
	}
	

}
$IG.Activation.registerClass('Infragistics.Web.UI.Activation', $IG.GridBehavior, $IG.IActivationBehavior);



$IG.GridActivationProps = new function()
{
	this.ActiveCell = [$IG.GridBehaviorProps.Count, null];
	this.ActiveGroupedRow = [$IG.GridBehaviorProps.Count + 1, null];
	this.Count = $IG.GridBehaviorProps.Count + 2;
};





$IG.ActiveCellChangingEventArgs = function(params)
{
	///<summary locid="T:J#Infragistics.Web.UI.ActiveCellChangingEventArgs">
	///Event arguments object passed into the active cell changing event handler.
	///</summary>
	$IG.ActiveCellChangingEventArgs.initializeBase(this);
	this._currentActiveCell = params[0];
	this._newActiveCell = params[1];
	this._currentActiveGroupedRow = params[2];
	this._newActiveGroupedRow = params[3];
}
$IG.ActiveCellChangingEventArgs.prototype =
{
	getCurrentActiveCell: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangingEventArgs.getCurrentActiveCell">
		/// Returns the current Active Cell.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell" mayBeNull="true" />
		return this._currentActiveCell;
	},

	getNewActiveCell: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangingEventArgs.getNewActiveCell">
		/// Returns the Cell that is going to be active.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell" mayBeNull="true" />
		return this._newActiveCell;
	},

	getCurrentActiveGroupedRow: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangingEventArgs.getCurrentActiveGroupedRow">
		/// Returns the current Active GroupedRow.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GroupedRow" mayBeNull="true" />
		return this._currentActiveGroupedRow;
	},

	getNewActiveGroupedRow: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangingEventArgs.getNewActiveGroupedRow">
		/// Returns the GroupedRow that is going to be active.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GroupedRow" mayBeNull="true" />
		return this._newActiveGroupedRow;
	}
}
$IG.ActiveCellChangingEventArgs.registerClass('Infragistics.Web.UI.ActiveCellChangingEventArgs', $IG.CancelEventArgs);


$IG.ActiveCellChangedEventArgs = function(params)
{
	///<summary locid="T:J#Infragistics.Web.UI.ActiveCellChangedEventArgs">
	///Event arguments object passed into the active cell changed event handler.
	///</summary>
	$IG.ActiveCellChangedEventArgs.initializeBase(this);
	this._context = {};
	this._context["behavior"] = params[0].get_name();
	this._activeCell = params[1];
	this._noIndicator = params[2];
	this._activeGroupedRow = params[3];
}
$IG.ActiveCellChangedEventArgs.prototype =
{

	getActiveCell: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangedEventArgs.getActiveCell">
		/// Returns the Active Cell.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell" mayBeNull="true" />
		return this._activeCell;
	},
	getActiveGroupedRow: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ActiveCellChangedEventArgs.getActiveGroupedRow">
		/// Returns the Active GroupedRow.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GroupedRow" mayBeNull="true" />
		return this._activeGroupedRow;
	}
}
$IG.ActiveCellChangedEventArgs.registerClass('Infragistics.Web.UI.ActiveCellChangedEventArgs', $IG.EventArgs);

﻿namespace Restaurant {
    
    
    public partial class PublicDataSet {
        partial class OrdersList_SellReportDataTable
        {
        }
    }
}
namespace Restaurant.PublicDataSetTableAdapters
{
    
    
    public partial class PublicDataSet {
    }
}

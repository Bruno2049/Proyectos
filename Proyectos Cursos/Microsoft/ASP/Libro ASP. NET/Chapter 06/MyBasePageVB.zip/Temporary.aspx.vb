﻿Partial Class $relurlnamespace$_$safeitemname$
  Inherits BasePage

End Class
